# Deployment Guide — Avina CRM

## 1. Prerequisites

| Requirement | Minimum | Why |
|---|---|---|
| PHP | **8.1** | The plugin refuses to load below this and shows a Persian admin notice instead of fataling — see §5.1 if you hit it |
| WordPress | 6.0+ | REST API, capabilities API, Settings API features the plugin relies on |
| MySQL / MariaDB | MySQL 5.7+ / MariaDB 10.2+ | `DECIMAL` columns for financial data, `dbDelta()`-compatible DDL |
| Web server | Any (Apache/LiteSpeed via cPanel, Nginx) | No special rewrite rules beyond WordPress's own |
| Outbound HTTPS from the server | Required only if using Webhooks | `wp_remote_post()` needs outbound connectivity to your webhook receiver's domain |

No Composer, no Node build step, no external services required for core functionality.

## 2. cPanel Installation — step by step

1. **Check your PHP version first.** In cPanel → **Select PHP Version** (under Software), confirm PHP 8.1 or higher is selected for the domain. If your host only offers 7.4, upgrade the PHP version here before proceeding — the plugin will not activate otherwise.
2. **Upload the plugin.** Either:
   - cPanel → **File Manager** → navigate to `wp-content/plugins/` → **Upload** the `avina-crm.zip` file → **Extract** it in place, or
   - via **FTP/SFTP**, upload the extracted `avina-crm/` folder directly into `wp-content/plugins/`.
3. Confirm the resulting path is exactly `wp-content/plugins/avina-crm/avina-crm.php` (not nested one level deeper — a common zip-extraction mistake).
4. **File permissions:** directories `755`, files `644` is the standard safe default for shared hosting; the plugin writes nothing to its own directory at runtime (all persistent state lives in the database), so no writable-directory exception is needed.
5. Log into **wp-admin → Plugins**, find **Avina CRM**, click **Activate**.
   - Activation runs `dbDelta()` to create ~30 tables, seeds the module registry, grants capabilities to the Administrator role, and creates the `avina_operator` role. This is safe to run multiple times (idempotent) — reactivating never duplicates data or drops existing rows.
6. Go to **wp-admin → آوینا CRM** (top-level menu, appears immediately after activation) to confirm the plugin loaded.

## 3. Shortcode / page setup

### 3.1 Administrator dashboard
1. Create a new WordPress Page (any title, e.g. "پنل مدیریت CRM").
2. In the content, add the shortcode block: `[avina_crm_admin]`.
3. Publish. Any user with Administrator capabilities who visits this page while logged in sees the full admin dashboard; anyone else sees a Persian "دسترسی غیرمجاز" (access denied) screen — this is enforced server-side, not by hiding the page.

### 3.2 Operator dashboards
These are created **automatically** — you do not need to manually place the `[avina_crm_user]` shortcode:
1. Go to **wp-admin → آوینا CRM → اپراتورها**.
2. Fill in the new-operator form (name, username, email) and leave "ایجاد صفحه اختصاصی" checked.
3. Submit. This creates a WordPress user with the `avina_operator` role **and** a dedicated private Page containing `[avina_crm_user user_id="<their id>"]`, linked in the operator list.
4. WordPress automatically emails the new operator a password-setup link (via core's own `wp_new_user_notification()` — the plugin never handles or displays passwords itself).

## 4. Post-activation health check

Go to **wp-admin → آوینا CRM → تشخیص سامانه** (Diagnostics). Confirm every row shows a green checkmark:

- **نسخه PHP** — should read your server's PHP version and confirm it meets the 8.1+ requirement.
- **نسخه ساختار پایگاه‌داده** — should read `4 / 4` (current schema version fully applied).
- **جدول `wp_avina_...`** (one row per foundation table) — each should say "موجود است" (exists). If any say "یافت نشد" (not found), see §5.2.
- **نقش اپراتور** — should say "ثبت شده" (registered).

If every row is green, the installation is healthy and ready to use.

## 5. Troubleshooting

### 5.1 "PHP incompatible" admin notice, plugin won't activate
Your host's PHP version is below 8.1. In cPanel → Select PHP Version, choose 8.1 or higher, then retry activation. The plugin deliberately refuses to run on an unsupported PHP version rather than risk a partial/fatal load.

### 5.2 A Diagnostics table row shows "یافت نشد" (not found)
This means `dbDelta()` didn't create that table, usually due to a database user lacking `CREATE TABLE` privilege, or a genuinely low-resource host timing out mid-migration. Fix: deactivate and reactivate the plugin (safe — activation is idempotent and will retry table creation without touching any data that already exists), or check your database user's privileges in cPanel → MySQL Databases.

### 5.3 Access-denied screen on a shortcode page you know you should see
This is the server-side authorization working as designed — check: (a) you're logged in as the right WordPress user, (b) for an operator page, that you're viewing *your own* dedicated page (not someone else's), (c) for the admin shortcode, that your account actually holds `platform.admin_dashboard.view` (Administrators have this automatically; a custom role would need it granted explicitly).

### 5.4 Webhook not firing
Confirm: (a) the webhook is marked "فعال" (active) in **وب‌هوک‌ها**, (b) the target URL is reachable via outbound HTTPS from your server (test with `wp_remote_post()` behavior in mind — some hosts block outbound connections by default; check with your host if a webhook consistently fails with no response status), (c) check the webhook's own dispatch log ("تاریخچه ارسال") for the actual HTTP response code received.

## 6. Uninstalling

Deactivating the plugin never deletes any data — it only flushes rewrite rules. Fully **deleting** the plugin from the Plugins screen also does not delete any data by default (Stage 1/Stage 2 requirement: no destructive uninstall). If you need to remove all CRM tables and options, that must currently be done manually via phpMyAdmin/cPanel MySQL tools — there is intentionally no "delete everything" button in this release.

## 7. What was NOT runtime-verified

This plugin was built and statically verified (PHP brace/namespace/import consistency, JS syntax, capability cross-checks) in a sandboxed environment without a live PHP interpreter or MySQL server available. The following can only be confirmed on your actual cPanel/WordPress environment:

- `dbDelta()` successfully creating every table against your specific MySQL/MariaDB version
- `php -l` syntax validation (static analysis was performed instead; a syntax error, while checked for extensively, cannot be 100% ruled out without a live PHP parser)
- Outbound webhook HTTP dispatch and HMAC verification against a real receiving endpoint
- Browser-side ES module loading and the Kanban drag-and-drop interaction in your actual browser/theme environment

Run the Diagnostics screen (§4) immediately after activation as your first real-environment confirmation.
