# آوینا CRM — Avina CRM for WordPress

A native WordPress plugin implementing a full-featured, Persian-first, RTL customer relationship management system, built entirely on WordPress core mechanisms (users, roles/capabilities, REST API, nonces, `$wpdb`, Settings/Options API) — no separate authentication system, no external framework, no Composer dependency.

- **Minimum PHP:** 8.1+
- **Minimum WordPress:** 6.0+
- **Text domain:** `avina-crm`
- **Current schema version:** 4 (`avina_crm_db_version` option)

---

## 1. Architecture

### 1.1 Bootstrap flow

```
avina-crm.php                     PHP-7.4-safe guard: checks PHP ≥ 8.1 before
                                   loading anything else. Registers activation/
                                   deactivation hooks and plugins_loaded → init.
  └─ includes/Kernel/Autoloader.php   PSR-4-style, no Composer: AvinaCRM\ → includes/
  └─ includes/Kernel/Plugin.php       Singleton orchestrator:
       ├─ activate()   Idempotent: dbDelta() + capability grants + role creation
       ├─ deactivate()  Non-destructive: flush_rewrite_rules() only
       └─ init()        Wires Admin menu, REST routes, shortcodes, template
                         override, and the webhook event listener
```

### 1.2 Layered design (per module)

Every business module (Contacts, Deals, Invoices, Tickets, etc.) follows the same three-layer shape:

```
includes/<Module>/<Module>Service.php   Domain logic: validation, $wpdb
                                         queries (always via ->prepare()),
                                         object-level/team scoping, calls
                                         into AuditLogger.
includes/Rest/Controllers/<Module>Controller.php
                                         Thin REST wrapper: parses the
                                         WP_REST_Request, calls the Service,
                                         wraps the result in ApiResponse.
includes/Rest/RestRegistrar.php         One register<Module>Routes() method
                                         per module; every route declares an
                                         explicit permission_callback.
```

Frontend mirrors this 1:1 — one `assets/js/views/<module>.js` per backend module, registered in `assets/js/app.js`'s router and nav.

### 1.3 Directory structure

```
avina-crm/
├── avina-crm.php                  Main plugin file
├── uninstall.php                  Non-destructive by default
├── README.md / DEPLOYMENT.md
├── includes/
│   ├── Kernel/                    Autoloader, Plugin orchestrator
│   ├── Database/                  Schema.php (all CREATE TABLE), Migrator.php
│   ├── Modules/                   ModuleDefinitions.php — module registry seed
│   ├── Capabilities/              CapabilityDefinitions, CapabilityRegistrar, RoleProvisioner
│   ├── Audit/                     AuditLogger (secret-redacting write layer)
│   ├── AuditLog/                  AuditLogService (read/filter layer for the viewer)
│   ├── Support/                   Scope (object-level authorization), Csv (formula-injection-safe export)
│   ├── Admin/                     wp-admin menu + all admin screens (Operators, Modules, Settings, Diagnostics)
│   ├── Rest/                      RestRegistrar, ApiResponse, Controllers/
│   ├── Frontend/                  ShortcodeRegistrar, AppShellRenderer, TemplateController
│   ├── Operators/                 OperatorService (shared by wp-admin form + REST)
│   ├── Teams/, Contacts/, Customers/, Phonebook/, Reception/,
│   │   Activities/, Tasks/, Reminders/, Notifications/, Tickets/
│   │                              Stage 3 business modules
│   ├── Pipelines/, Deals/, Invoices/, Payments/
│   │                              Stage 4 sales modules
│   ├── Analytics/, Webhooks/, Backup/
│   │                              Stage 5 modules
│   └── Uninstall/                 UninstallHandler (intentionally empty)
├── assets/
│   ├── css/                       theme-light.css, theme-dark.css, app-shell.css (glassmorphism, RTL)
│   └── js/                        router.js, ui.js, modal.js, api-client.js, app.js, views/*.js
└── languages/
    └── avina-crm.pot
```

---

## 2. Module map

| Slug | Persian name | Status | Core? |
|---|---|---|---|
| `platform` | زیرساخت سامانه | Active | Yes |
| `module-manager` | مدیریت ماژول‌ها | Active | Yes |
| `settings` | تنظیمات | Active | Yes |
| `theme-customization` | تم و شخصی‌سازی | Registered, not yet built | No |
| `teams` | تیم‌ها | **Active** | No |
| `contacts` | مخاطبین | **Active** | No |
| `customers` | مشتریان | **Active** | No |
| `phonebook` | دفترچه تلفن | **Active** | No |
| `reception` | پذیرش | **Active** | No |
| `kanban` | کانبان | **Active** | No |
| `activities` | فعالیت‌ها و پیگیری‌ها | **Active** | No |
| `tasks` | وظایف | **Active** | No |
| `reminders` | یادآورها و پیگیری‌ها | **Active** | No |
| `reports` | گزارشات | **Active** (via Analytics) | No |
| `deals` | معاملات | **Active** | No |
| `invoices` | فاکتورها | **Active** | No |
| `payments` | پرداخت‌ها | **Active** | No |
| `notifications` | اطلاع‌رسانی | **Active** | No |
| `messaging` | پیامک | Registered, not yet built | No |
| `tickets` | درخواست‌های داخلی | **Active** | No |
| `backup-restore` | پشتیبان‌گیری و بازیابی | **Active** | No |
| `webhooks` | وب‌هوک‌ها و یکپارچه‌سازی | **Active** | No |
| `audit` | ثبت رویداد | Active | Yes |
| `security` | امنیت | Registered, not yet built | Yes |

`social-connectors`, `recruitment`, `avina`, and `form-builder` are deliberately **not** in the registry at all — they had no real implementation in the source application this plugin was migrated from, and Stage 1/Stage 2 explicitly excluded them rather than seed a placeholder.

The live list (with `is_active` state) is always visible in wp-admin → **آوینا CRM → ماژول‌ها**.

---

## 3. Roles & capabilities

- **WordPress Administrator** automatically holds every plugin capability (~74, granted on activation and resynced on any schema-version bump).
- **`avina_operator`** — a minimal custom role (base `read` + `platform.operator_dashboard.view`). An administrator grants individual module capabilities to a specific operator user as needed; capabilities are never assumed from the role name alone.
- Every capability follows `{module-slug}.{resource}.{action}`, e.g. `contacts.contact.view`, `deals.deal.change_stage`, `invoices.invoice.void`. The full list is `includes/Capabilities/CapabilityDefinitions.php`.
- Object-level authorization (row-level, not just the capability check) is enforced by `AvinaCRM\Support\Scope` in every list/find query — a non-manager sees only records they own, created, or that belong to a team they're a member of.

---

## 4. Configuration options

All under wp-admin → **آوینا CRM → تنظیمات**:

| Setting | Type | Default | Notes |
|---|---|---|---|
| `avina_crm_app_name` | text | `آوینا CRM` | Shown in the app-shell header |
| `avina_crm_default_theme` | select (light/dark) | `light` | |
| `avina_crm_debug_mode` | checkbox | off | No secrets are ever written to any log regardless of this setting |
| `avina_crm_webhook_secret` | password (masked) | empty | Example/reserved advanced field; real per-webhook secrets are generated individually — see §5 |

---

## 5. Shortcodes

- `[avina_crm_admin]` — full administrator dashboard. Renders only if the current logged-in user has `platform.admin_dashboard.view`.
- `[avina_crm_user user_id="123"]` — one operator's dashboard. The `user_id` attribute is **routing metadata only**; real authorization always comes from the current session (`get_current_user_id()`) matched against `{prefix}avina_operator_pages`. An administrator may view another operator's dashboard only via a separately-checked monitor mode.

Both are placed automatically on a dedicated WP page when an operator is created via wp-admin → **آوینا CRM → اپراتورها**.

---

## 6. Webhooks

Each webhook has its own generated HMAC secret (`X-Avina-Signature: hash_hmac('sha256', body, secret)`), shown **once** at creation time and never retrievable again. Available events: `deal.stage_changed`, `deal.won`, `deal.lost`, `invoice.paid`, `ticket.created`. Manage under wp-admin/app-shell → **وب‌هوک‌ها**.

## 7. Backup & export

`backup.export.download` capability gates two REST endpoints: a full structured JSON export and a per-table CSV export, both drawing from a hardcoded table allowlist (13 business tables — never `wp_users`, `wp_options`, or the webhooks table). CSV output is formula-injection-safe via `AvinaCRM\Support\Csv`.

## 8. Audit log

Every state-changing action across every module writes to `{prefix}avina_audit_log` via `AuditLogger`, which redacts any field whose key matches a sensitive-name pattern (`password`, `secret`, `api_key`, `token`, `credential`, `private_key`) before storage. View/filter it at wp-admin/app-shell → **رویدادهای سامانه** (`audit.log.view` capability).
