<?php

declare(strict_types=1);

namespace AvinaCRM\Frontend;

/**
 * Stage 2 decision #4: a controlled fullscreen app shell with CSS
 * isolation, applied ONLY on pages that actually contain one of the two
 * CRM shortcodes — never a global theme change, never applied to normal
 * pages, posts, Elementor content, admin screens, or any other plugin's
 * output.
 */
final class TemplateController
{
    public function bootstrap(): void
    {
        add_filter('template_include', [$this, 'maybeOverrideTemplate']);
    }

    public function maybeOverrideTemplate(string $template): string
    {
        if (!is_singular('page')) {
            return $template;
        }

        $post = get_post();

        if ($post === null) {
            return $template;
        }

        $hasAdminShortcode = has_shortcode((string) $post->post_content, 'avina_crm_admin');
        $hasUserShortcode = has_shortcode((string) $post->post_content, 'avina_crm_user');

        if (!$hasAdminShortcode && !$hasUserShortcode) {
            return $template;
        }

        $override = AVINA_CRM_DIR . 'includes/Frontend/templates/app-shell.php';

        if (!is_file($override)) {
            return $template;
        }

        // The app-shell page is deliberately chrome-free (no theme
        // header/footer — see the template's own docblock). The
        // WordPress admin toolbar is theme chrome too: for a
        // logged-in administrator it prints ~32px of markup plus its
        // own CSS/dashicons on top of every front-end page, which is
        // exactly the kind of unstyled/overlapping mess this template
        // was built to avoid. Suppress it only for this one page,
        // never site-wide.
        add_filter('show_admin_bar', '__return_false');

        return $override;
    }
}
