<?php

declare(strict_types=1);

namespace AvinaCRM\Frontend;

/**
 * Stage 1 §8 / Stage 2 decision #7, implemented exactly as approved:
 *
 *  - [avina_crm_admin] renders only if the CURRENT logged-in user has
 *    platform.admin_dashboard.view. The shortcode's mere presence on a
 *    page never grants access by itself.
 *
 *  - [avina_crm_user user_id="123"] treats the `user_id` attribute as
 *    ROUTING METADATA ONLY, never as an authorization input. The real
 *    decision always comes from get_current_user_id(): either the
 *    logged-in user owns this page (per {prefix}avina_operator_pages),
 *    or the logged-in user is an administrator using the separately
 *    authorized monitor/view-as capability. Every other case is denied
 *    server-side with the Persian RTL access-denied state — never a
 *    silent redirect, never a partial render.
 */
final class ShortcodeRegistrar
{
    private AppShellRenderer $renderer;

    public function __construct()
    {
        $this->renderer = new AppShellRenderer();
    }

    public function bootstrap(): void
    {
        add_shortcode('avina_crm_login', [$this, 'renderLoginShortcode']);
        add_shortcode('avina_crm_admin', [$this, 'renderAdminShortcode']);
        add_shortcode('avina_crm_user', [$this, 'renderUserShortcode']);
        add_shortcode('avina_crm_app', [$this, 'renderAdminShortcode']);
        add_shortcode('avina_crm_lead', [$this, 'renderLeadFormShortcode']);
        add_shortcode('avina_crm_customer', [$this, 'renderCustomerFormShortcode']);
        add_shortcode('avina_crm_reception', [$this, 'renderReceptionShortcode']);
        add_shortcode('avina_crm_recruitment', [$this, 'renderRecruitmentShortcode']);
        add_shortcode('avina_crm_invoice', [$this, 'renderInvoiceShortcode']);
        add_shortcode('avina_crm_sms', [$this, 'renderSmsShortcode']);

        add_action('wp_ajax_nopriv_avina_ajax_login', [$this, 'handleAjaxLogin']);
        add_action('wp_ajax_avina_ajax_login', [$this, 'handleAjaxLogin']);
        add_action('wp_ajax_nopriv_avina_public_invoice_pay', [$this, 'handlePublicInvoicePayAjax']);
        add_action('wp_ajax_avina_public_invoice_pay', [$this, 'handlePublicInvoicePayAjax']);
        add_action('wp_ajax_nopriv_avina_save_app_data', [\AvinaCRM\Rest\Controllers\AppDataController::class, 'handleAjaxSave']);
        add_action('wp_ajax_avina_save_app_data', [\AvinaCRM\Rest\Controllers\AppDataController::class, 'handleAjaxSave']);
        add_action('wp_ajax_nopriv_avina_get_app_data', [\AvinaCRM\Rest\Controllers\AppDataController::class, 'handleAjaxGet']);
        add_action('wp_ajax_avina_get_app_data', [\AvinaCRM\Rest\Controllers\AppDataController::class, 'handleAjaxGet']);

        add_filter('authenticate', static function ($user, $username, $password) {
            if (!empty($username) && !empty($password)) {
                $cleanUsername = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim((string) $username));
                $cleanPassword = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim((string) $password));

                if ($cleanUsername !== $username || $cleanPassword !== $password) {
                    $check = wp_authenticate_username_password(null, $cleanUsername, $cleanPassword);
                    if ($check instanceof \WP_User) {
                        return $check;
                    }
                }

                // Check by mobile meta if normal auth failed
                if (is_wp_error($user) || $user === null) {
                    $mobileUsers = get_users([
                        'meta_key' => 'avina_crm_operator_mobile',
                        'meta_value' => $cleanUsername,
                        'number' => 1
                    ]);
                    if (!empty($mobileUsers)) {
                        $checkMobile = wp_authenticate_username_password(null, $mobileUsers[0]->user_login, $cleanPassword);
                        if ($checkMobile instanceof \WP_User) {
                            return $checkMobile;
                        }
                    }
                }
            }
            return $user;
        }, 20, 3);

        // Guard: Prevent operators from ever getting stuck in wp-admin
        add_action('admin_init', function () {
            if (wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
                return;
            }
            if (is_user_logged_in() && !current_user_can('manage_options')) {
                wp_redirect(site_url('/crm-operator/'));
                exit;
            }
        });

        // Filter: Guarantee proper landing page on login without wp-login redirect issues
        add_filter('login_redirect', function ($redirect_to, $requested_redirect_to, $user) {
            if ($user instanceof \WP_User) {
                $isAdmin = in_array('administrator', (array) $user->roles, true) || user_can($user, 'manage_options');
                return $isAdmin ? site_url('/crm-admin/') : site_url('/crm-operator/');
            }
            return $redirect_to;
        }, 100, 3);

        add_action('template_redirect', function () {
            try {
                $reqUri = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');

                // 1. Standalone Public Invoice View (Accessible without login, 24h validity, no access to CRM app)
                if (isset($_GET['avina_public_invoice']) || isset($_GET['avina_invoice_pay']) || $reqUri === 'crm-invoice' || strpos($reqUri, 'crm-invoice') !== false) {
                    $invoiceId = sanitize_text_field($_GET['avina_public_invoice'] ?? $_GET['avina_invoice_pay'] ?? $_GET['id'] ?? '');
                    if (!$invoiceId && preg_match('#crm-invoice/([^/?]+)#', $reqUri, $m)) {
                        $invoiceId = sanitize_text_field($m[1]);
                    }
                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderPublicInvoiceStandalonePage($invoiceId);
                    exit;
                }

                // 2. Direct Landing for CRM Admin (/crm-admin/) - STRICTLY FOR SUPER ADMIN ONLY
                $isCrmAdmin = ($reqUri === 'crm-admin' || str_ends_with($reqUri, '/crm-admin') || str_ends_with($reqUri, 'crm-admin') || isset($_GET['crm_admin_page']) || (strpos($reqUri, 'crm-admin') !== false));
                if ($isCrmAdmin) {
                    if (!is_user_logged_in()) {
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }

                    $isAdmin = \AvinaCRM\Support\Scope::isAdmin();
                    // Non-admin operators are STRICTLY blocked from /crm-admin/ and routed to their own desk
                    if (!$isAdmin) {
                        wp_redirect(site_url('/crm-operator/'));
                        exit;
                    }

                    // If super-admin is inspecting an operator panel in monitoring mode
                    if (isset($_GET['avina_crm_user_id']) || isset($_GET['crm_user_id']) || isset($_GET['inspect_user_id'])) {
                        $rawId = sanitize_text_field($_GET['avina_crm_user_id'] ?? $_GET['crm_user_id'] ?? $_GET['inspect_user_id'] ?? '');
                        $targetUserId = (int) preg_replace('/\D/', '', $rawId);
                        if ($targetUserId > 0) {
                            header('Content-Type: text/html; charset=UTF-8');
                            header('X-UA-Compatible: IE=edge');
                            status_header(200);
                            echo $this->renderStandaloneOperatorPage($targetUserId);
                            exit;
                        }
                    }

                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderStandaloneAdminPage();
                    exit;
                }

                // 3. Direct Landing for CRM Operator (/crm-operator/ or /crm-user/)
                $isCrmOperator = ($reqUri === 'crm-operator' || str_ends_with($reqUri, '/crm-operator') || str_ends_with($reqUri, 'crm-operator') || isset($_GET['crm_operator_page']) || (strpos($reqUri, 'crm-operator') !== false));
                if ($isCrmOperator) {
                    if (!is_user_logged_in()) {
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }

                    $isAdmin = \AvinaCRM\Support\Scope::isAdmin();
                    if ($isAdmin) {
                        // Admin inspecting an operator via /crm-operator/?inspect_user_id=X
                        $rawId = sanitize_text_field($_GET['avina_crm_user_id'] ?? $_GET['crm_user_id'] ?? $_GET['inspect_user_id'] ?? '');
                        $targetUserId = (int) preg_replace('/\D/', '', $rawId);
                        if ($targetUserId > 0) {
                            header('Content-Type: text/html; charset=UTF-8');
                            header('X-UA-Compatible: IE=edge');
                            status_header(200);
                            echo $this->renderStandaloneOperatorPage($targetUserId);
                            exit;
                        }
                        // Admin visiting /crm-operator/ directly -> send back to admin panel
                        wp_redirect(site_url('/crm-admin/'));
                        exit;
                    }

                    // Normal operator workspace
                    $userId = get_current_user_id();
                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderStandaloneOperatorPage($userId);
                    exit;
                }

                // 4. Standalone CRM Login Page (/crm-login/)
                $isCrmLogin = ($reqUri === 'crm-login' || str_ends_with($reqUri, '/crm-login') || str_ends_with($reqUri, 'crm-login') || isset($_GET['crm_login_page']) || (strpos($reqUri, 'crm-login') !== false));
                if ($isCrmLogin) {
                    if ((isset($_GET['action']) && $_GET['action'] === 'logout') || isset($_GET['logout'])) {
                        wp_clear_auth_cookie();
                        wp_logout();
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }

                    if (is_user_logged_in()) {
                        $isAdmin = \AvinaCRM\Support\Scope::isAdmin();
                        wp_redirect($isAdmin ? site_url('/crm-admin/') : site_url('/crm-operator/'));
                        exit;
                    }

                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderLoginStandalonePage();
                    exit;
                }

                // 5. Clean redirect any orphaned ?avina_crm_user_id or ?inspect_user_id
                if (isset($_GET['avina_crm_user_id']) || isset($_GET['crm_user_id']) || isset($_GET['inspect_user_id'])) {
                    if (!is_user_logged_in()) {
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }
                    $rawId = sanitize_text_field($_GET['avina_crm_user_id'] ?? $_GET['crm_user_id'] ?? $_GET['inspect_user_id'] ?? '');
                    $targetUserId = (int) preg_replace('/\D/', '', $rawId);
                    if ($targetUserId > 0 && \AvinaCRM\Support\Scope::isAdmin()) {
                        header('Content-Type: text/html; charset=UTF-8');
                        header('X-UA-Compatible: IE=edge');
                        status_header(200);
                        echo $this->renderStandaloneOperatorPage($targetUserId);
                        exit;
                    }
                    wp_redirect(site_url('/crm-operator/'));
                    exit;
                }
            } catch (\Throwable $e) {
                error_log('Avina CRM template_redirect fatal prevented: ' . $e->getMessage());
            }
        });

        add_filter('template_include', function ($template) {

            $post = get_post();
            if ($post instanceof \WP_Post && is_singular()) {
                if (has_shortcode($post->post_content, 'avina_crm_login')) {
                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderLoginStandalonePage();
                    exit;
                }
                if (has_shortcode($post->post_content, 'avina_crm_user')) {
                    if (!is_user_logged_in()) {
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }
                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderStandaloneUserPage($post);
                    exit;
                }
                if (has_shortcode($post->post_content, 'avina_crm_admin') || has_shortcode($post->post_content, 'avina_crm_app')) {
                    if (!is_user_logged_in()) {
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }
                    header('Content-Type: text/html; charset=UTF-8');
                    header('X-UA-Compatible: IE=edge');
                    status_header(200);
                    echo $this->renderStandaloneAdminPage();
                    exit;
                }
            }
            return $template;
        });

        add_filter('body_class', static function (array $classes): array {
            $post = get_post();
            if ($post instanceof \WP_Post && is_singular() && (has_shortcode($post->post_content, 'avina_crm_user') || has_shortcode($post->post_content, 'avina_crm_admin') || has_shortcode($post->post_content, 'avina_crm_app'))) {
                $classes[] = 'avina-crm-active-page';
            }
            return $classes;
        });
    }

    public function renderLeadFormShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/form/lead";</script>';
    }

    public function renderCustomerFormShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/customers";</script>';
    }

    public function renderReceptionShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/reception";</script>';
    }

    public function renderRecruitmentShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/form/recruitment";</script>';
    }

    public function renderInvoiceShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/invoices";</script>';
    }

    public function renderSmsShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/sms-keypad";</script>';
    }

    public function renderAdminShortcode(): string
    {
        if (!is_user_logged_in()) {
            $login_url = site_url('/crm-login/');
            return '<script>window.location.href="' . esc_url($login_url) . '";</script>';
        }

        $isAdmin = \AvinaCRM\Support\Scope::isAdmin();
        if (!$isAdmin) {
            $userId = get_current_user_id();
            if ($userId > 0) {
                return $this->renderer->renderAppShell('operator', $userId);
            }
            return '<script>window.location.href="' . esc_url(site_url('/crm-login/')) . '";</script>';
        }

        return $this->renderer->renderAppShell('admin');
    }

    /**
     * @param array<string, mixed>|string $atts
     */
    public function renderUserShortcode($atts): string
    {
        if (!is_user_logged_in()) {
            return $this->renderer->renderAccessDenied();
        }

        $currentUserId = get_current_user_id();
        $isAdmin = \AvinaCRM\Support\Scope::isAdmin();

        $atts = shortcode_atts(['user_id' => 0], is_array($atts) ? $atts : []);
        $requestedUserId = (int) $atts['user_id'];

        if ($requestedUserId <= 0) {
            $requestedUserId = $currentUserId;
        }

        if ($isAdmin || $currentUserId === $requestedUserId || $this->isOwnPage($currentUserId)) {
            $mode = ($isAdmin && $currentUserId !== $requestedUserId) ? 'monitor' : 'operator';
            return $this->renderer->renderAppShell($mode, $requestedUserId);
        }

        return $this->renderer->renderAccessDenied();
    }

    private function isOwnPage(int $currentUserId): bool
    {
        global $wpdb;

        $postId = get_the_ID();

        if (!$postId) {
            return false;
        }

        $table = $wpdb->prefix . 'avina_operator_pages';

        $ownerId = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE page_id = %d AND is_active = 1",
                $postId
            )
        );

        return $ownerId !== null && (int) $ownerId === $currentUserId;
    }

    private function userOwnsAPage(int $userId): bool
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_operator_pages';

        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_active = 1",
                $userId
            )
        );

        return (int) $exists > 0;
    }

    public function renderLoginShortcode(): string
    {
        if (is_user_logged_in()) {
            return '<script>window.location.href="' . esc_url(site_url('/crm-admin/')) . '";</script>';
        }

        $isHttps = is_ssl()
            || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
            || (isset($_SERVER['HTTPS']) && (strtolower((string) $_SERVER['HTTPS']) === 'on' || $_SERVER['HTTPS'] === '1'))
            || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443);

        $scheme = $isHttps ? 'https' : 'admin';
        $rest_login_url = esc_url_raw(set_url_scheme(rest_url(\AvinaCRM\Rest\RestRegistrar::NAMESPACE_V1 . '/login'), $scheme));
        $ajax_login_url = esc_url_raw(set_url_scheme(admin_url('admin-ajax.php'), $scheme));
        $rest_nonce = wp_create_nonce('wp_rest');
        $crm_admin_url = esc_url(set_url_scheme(site_url('/crm-admin/'), $scheme));

        ob_start();
        ?>
        <div id="avina-crm-fullscreen-login" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; width: 100vw; height: 100vh; z-index: 9999999; background: #020617; display: flex; align-items: center; justify-content: center; overflow-y: auto; font-family: Tahoma, 'Vazirmatn', sans-serif; direction: rtl;" lang="fa">
            
            <!-- Ambient Background Glow Orbs -->
            <div style="position: absolute; top: -10%; right: -10%; width: 400px; height: 400px; background: radial-gradient(circle, rgba(6,182,212,0.25) 0%, rgba(6,182,212,0) 70%); filter: blur(60px); pointer-events: none;"></div>
            <div style="position: absolute; bottom: -10%; left: -10%; width: 450px; height: 450px; background: radial-gradient(circle, rgba(168,85,247,0.25) 0%, rgba(168,85,247,0) 70%); filter: blur(70px); pointer-events: none;"></div>
            <div style="position: absolute; top: 40%; left: 10%; width: 300px; height: 300px; background: radial-gradient(circle, rgba(16,185,129,0.2) 0%, rgba(16,185,129,0) 70%); filter: blur(50px); pointer-events: none;"></div>

            <!-- Floating Neon Particles (Moving Bottom to Top) -->
            <div class="avina-login-particles">
                <div class="avina-particle p1"></div>
                <div class="avina-particle p2"></div>
                <div class="avina-particle p3"></div>
                <div class="avina-particle p4"></div>
                <div class="avina-particle p5"></div>
                <div class="avina-particle p6"></div>
                <div class="avina-particle p7"></div>
                <div class="avina-particle p8"></div>
            </div>

            <!-- Glassmorphic Login Card with Neon Gradient Border -->
            <div style="position: relative; z-index: 10; width: 100%; max-width: 440px; padding: 2px; border-radius: 28px; background: linear-gradient(135deg, rgba(6,182,212,0.6), rgba(16,185,129,0.4), rgba(168,85,247,0.6)); box-shadow: 0 0 50px rgba(6,182,212,0.3); margin: 16px;">
                <div style="background: rgba(15, 23, 42, 0.94); backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px); border-radius: 26px; padding: 40px 32px; color: #f8fafc; text-align: right; box-shadow: inset 0 0 20px rgba(255,255,255,0.03);">
                    
                    <!-- Header & Logo -->
                    <div style="text-align: center; margin-bottom: 24px;">
                        <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 20px; background: linear-gradient(135deg, rgba(6,182,212,0.2), rgba(16,185,129,0.2)); border: 1px solid rgba(6,182,212,0.4); display: flex; align-items: center; justify-content: center; box-shadow: 0 0 25px rgba(6,182,212,0.3);">
                            <svg style="width: 32px; height: 32px; color: #38bdf8;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                        </div>
                        <h1 style="font-size: 22px; font-weight: 800; color: #ffffff; margin: 0 0 6px 0; letter-spacing: -0.5px;">ورود به سامانه آوینا CRM</h1>
                        <p style="font-size: 12px; color: #94a3b8; margin: 0;">پرتال مدیریت ارتباط با مشتریان و حسابداری هوشمند</p>
                    </div>

                    <!-- Dynamic Notification Alert Box -->
                    <div id="avina-login-alert" style="display: none; padding: 12px 16px; border-radius: 14px; font-size: 13px; font-weight: 700; margin-bottom: 20px; text-align: center; line-height: 1.5; transition: all 0.3s;"></div>

                    <!-- Interactive Login Form -->
                    <form id="avina-ajax-login-form" method="post" action="javascript:void(0);" style="display: flex; flex-direction: column; gap: 18px;">
                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 700; color: #cbd5e1; margin-bottom: 8px;">نام کاربری، نشانی ایمیل یا شماره موبایل</label>
                            <div style="position: relative;">
                                <input type="text" name="log" id="avina_user_login" required autocomplete="username" placeholder="مثال: admin یا 09123456789" style="width: 100%; padding: 14px 16px; background: rgba(2, 6, 23, 0.7); border: 1px solid rgba(51, 65, 85, 0.8); border-radius: 14px; color: #f8fafc; font-size: 13px; outline: none; transition: all 0.3s; box-sizing: border-box;" onfocus="this.style.borderColor='#38bdf8'; this.style.boxShadow='0 0 15px rgba(56,189,248,0.3)';" onblur="this.style.borderColor='rgba(51, 65, 85, 0.8)'; this.style.boxShadow='none';" />
                            </div>
                        </div>

                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 700; color: #cbd5e1; margin-bottom: 8px;">رمز عبور</label>
                            <div style="position: relative;">
                                <input type="password" name="pwd" id="avina_user_pass" required autocomplete="current-password" placeholder="••••••••" style="width: 100%; padding: 14px 16px; background: rgba(2, 6, 23, 0.7); border: 1px solid rgba(51, 65, 85, 0.8); border-radius: 14px; color: #f8fafc; font-size: 13px; outline: none; transition: all 0.3s; box-sizing: border-box;" onfocus="this.style.borderColor='#38bdf8'; this.style.boxShadow='0 0 15px rgba(56,189,248,0.3)';" onblur="this.style.borderColor='rgba(51, 65, 85, 0.8)'; this.style.boxShadow='none';" />
                            </div>
                        </div>

                        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 12px; margin-top: 2px;">
                            <label style="display: flex; align-items: center; gap: 8px; color: #94a3b8; cursor: pointer; user-select: none;">
                                <input type="checkbox" id="avina_rememberme" name="rememberme" value="forever" checked style="accent-color: #06b6d4; width: 16px; height: 16px; cursor: pointer;" />
                                مرا به خاطر بسپار
                            </label>
                        </div>

                        <button type="submit" id="avina-login-submit" style="width: 100%; margin-top: 10px; padding: 15px; background: linear-gradient(135deg, #06b6d4 0%, #10b981 100%); border: none; border-radius: 14px; color: #020617; font-size: 14px; font-weight: 800; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 25px rgba(6,182,212,0.4);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 0 35px rgba(6,182,212,0.6)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 0 25px rgba(6,182,212,0.4)';">
                            <span id="avina-login-btn-text">ورود به سامانه آوینا CRM ➔</span>
                        </button>
                    </form>

                    <div style="margin-top: 24px; text-align: center; font-size: 11px; color: #64748b;">
                        سامانه هوشمند آوینا CRM • طراحی شده با نیون شیشه‌ای
                    </div>
                </div>
            </div>

            <!-- Client-Side AJAX Authenticator Script -->
            <script>
            (function() {
                var form = document.getElementById('avina-ajax-login-form');
                var userInput = document.getElementById('avina_user_login');
                var passInput = document.getElementById('avina_user_pass');
                var rememberInput = document.getElementById('avina_rememberme');
                var submitBtn = document.getElementById('avina-login-submit');
                var btnText = document.getElementById('avina-login-btn-text');
                var alertBox = document.getElementById('avina-login-alert');

                function toEnglishDigits(str) {
                    if (!str) return '';
                    var persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
                    var arabic  = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
                    var english = ['0','1','2','3','4','5','6','7','8','9'];
                    for (var i = 0; i < 10; i++) {
                        str = str.replace(new RegExp(persian[i], 'g'), english[i]);
                        str = str.replace(new RegExp(arabic[i], 'g'), english[i]);
                    }
                    return str.trim();
                }

                function showAlert(msg, isSuccess) {
                    alertBox.style.display = 'block';
                    alertBox.textContent = msg;
                    if (isSuccess) {
                        alertBox.style.background = 'rgba(16, 185, 129, 0.2)';
                        alertBox.style.border = '1px solid rgba(16, 185, 129, 0.5)';
                        alertBox.style.color = '#6ee7b7';
                    } else {
                        alertBox.style.background = 'rgba(239, 68, 68, 0.2)';
                        alertBox.style.border = '1px solid rgba(239, 68, 68, 0.5)';
                        alertBox.style.color = '#fca5a5';
                    }
                }

                if (form) {
                    form.addEventListener('submit', async function(e) {
                        e.preventDefault();
                        alertBox.style.display = 'none';

                        var rawUser = userInput.value || '';
                        var rawPass = passInput.value || '';
                        var username = toEnglishDigits(rawUser);
                        var password = toEnglishDigits(rawPass);
                        var remember = rememberInput ? rememberInput.checked : true;

                        if (!username || !password) {
                            showAlert('لطفاً نام کاربری و کلمه عبور را وارد کنید.', false);
                            return;
                        }

                        submitBtn.disabled = true;
                        btnText.textContent = 'در حال اعتبارسنجی و اتصال امن... ⏳';

                        var userInfo = null;
                        var errorMsg = '';

                        try {
                            var restUrl = <?php echo json_encode($rest_login_url); ?>;
                            if (window.location.protocol === 'https:' && restUrl.indexOf('http:') === 0) {
                                restUrl = restUrl.replace(/^http:/, 'https:');
                            }
                            var resp = null;
                            try {
                                resp = await fetch(restUrl, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'X-WP-Nonce': <?php echo json_encode($rest_nonce); ?>
                                    },
                                    credentials: 'same-origin',
                                    body: JSON.stringify({
                                        username: username,
                                        password: password,
                                        remember: remember
                                    })
                                });
                            } catch (fetchErr) {
                                // Try relative URL fallback on network error
                                try {
                                    var parsedRest = new URL(restUrl);
                                    resp = await fetch(parsedRest.pathname + parsedRest.search, {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json',
                                            'X-WP-Nonce': <?php echo json_encode($rest_nonce); ?>
                                        },
                                        credentials: 'same-origin',
                                        body: JSON.stringify({
                                            username: username,
                                            password: password,
                                            remember: remember
                                        })
                                    });
                                } catch (relErr) {
                                    resp = null;
                                }
                            }

                            var data = null;
                            if (resp) {
                                try {
                                    data = await resp.json();
                                } catch(jsonErr) {
                                    data = null;
                                }
                            }

                            if (resp && resp.ok && data && (data.ok || data.success || (data.data && data.data.id))) {
                                userInfo = data.data || data;
                            } else {
                                if (data && data.error && data.error.message) {
                                    errorMsg = data.error.message;
                                } else if (data && data.data && data.data.message) {
                                    errorMsg = data.data.message;
                                } else if (data && data.message && typeof data.message === 'string' && !data.message.includes('<p>') && !data.message.includes('internal_server_error')) {
                                    errorMsg = data.message;
                                }
                            }
                        } catch(restErr) {
                            console.warn('REST login failed, attempting AJAX fallback...', restErr);
                        }

                        // Fallback to admin-ajax if REST failed or wasn't authorized
                        if (!userInfo) {
                            try {
                                var ajaxUrl = <?php echo json_encode($ajax_login_url); ?>;
                                if (window.location.protocol === 'https:' && ajaxUrl.indexOf('http:') === 0) {
                                    ajaxUrl = ajaxUrl.replace(/^http:/, 'https:');
                                }
                                var formData = new FormData();
                                formData.append('action', 'avina_ajax_login');
                                formData.append('username', username);
                                formData.append('password', password);
                                formData.append('remember', remember ? '1' : '0');

                                var ajaxResp = null;
                                try {
                                    ajaxResp = await fetch(ajaxUrl, {
                                        method: 'POST',
                                        credentials: 'same-origin',
                                        body: formData
                                    });
                                } catch (ajaxNetErr) {
                                    try {
                                        var parsedAjax = new URL(ajaxUrl);
                                        ajaxResp = await fetch(parsedAjax.pathname + parsedAjax.search, {
                                            method: 'POST',
                                            credentials: 'same-origin',
                                            body: formData
                                        });
                                    } catch (ajaxRelErr) {
                                        ajaxResp = null;
                                    }
                                }

                                var ajaxData = ajaxResp ? await ajaxResp.json().catch(function() { return null; }) : null;
                                if (ajaxResp && ajaxResp.ok && ajaxData && ajaxData.success) {
                                    userInfo = ajaxData.data;
                                    errorMsg = '';
                                } else if (ajaxData && ajaxData.data && ajaxData.data.message) {
                                    errorMsg = ajaxData.data.message;
                                }
                            } catch(ajaxErr) {
                                console.error('AJAX fallback error:', ajaxErr);
                            }
                        }

                        if (userInfo && (userInfo.id || userInfo.username)) {
                            submitBtn.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
                            btnText.textContent = 'ورود موفقیت‌آمیز! در حال انتقال... ✔';
                            showAlert('خوش آمدید! در حال انتقال به پیشخوان شما...', true);

                            try {
                                localStorage.setItem('avina_crm_current_user', JSON.stringify(userInfo));
                                if (userInfo.crm_token) {
                                    localStorage.setItem('avina_crm_token', userInfo.crm_token);
                                }
                            } catch(e) {}

                            var dest = userInfo.redirect_url || userInfo.page_url || <?php echo json_encode($crm_admin_url); ?>;
                            setTimeout(function() {
                                window.location.replace(dest);
                            }, 300);
                            return;
                        } else {
                            submitBtn.disabled = false;
                            btnText.textContent = 'ورود به سامانه آوینا CRM ➔';
                            if (!errorMsg || errorMsg.includes('<p>') || errorMsg.includes('internal_server_error') || errorMsg.includes('خطای مهم')) {
                                errorMsg = 'نام کاربری یا رمز عبور اشتباه است.';
                            }
                            showAlert(errorMsg, false);
                        }
                    });
                }
            })();
            </script>

            <!-- Styles & Particle Keyframe Animations -->
            <style>
                .avina-login-particles {
                    position: absolute;
                    inset: 0;
                    pointer-events: none;
                    overflow: hidden;
                    z-index: 1;
                }
                .avina-particle {
                    position: absolute;
                    bottom: -150px;
                    border-radius: 50%;
                    animation: avinaFloatUpParticle 18s infinite linear;
                    pointer-events: none;
                }
                .avina-particle.p1 { left: 8%; width: 180px; height: 180px; background: radial-gradient(circle, rgba(6,182,212,0.3) 0%, rgba(6,182,212,0) 70%); filter: blur(30px); animation-duration: 22s; animation-delay: 0s; }
                .avina-particle.p2 { left: 25%; width: 90px; height: 90px; background: radial-gradient(circle, rgba(168,85,247,0.35) 0%, rgba(168,85,247,0) 70%); filter: blur(20px); animation-duration: 15s; animation-delay: 2s; }
                .avina-particle.p3 { left: 45%; width: 220px; height: 220px; background: radial-gradient(circle, rgba(16,185,129,0.3) 0%, rgba(16,185,129,0) 70%); filter: blur(40px); animation-duration: 28s; animation-delay: 4s; }
                .avina-particle.p4 { left: 65%; width: 130px; height: 130px; background: radial-gradient(circle, rgba(236,72,153,0.35) 0%, rgba(236,72,153,0) 70%); filter: blur(25px); animation-duration: 19s; animation-delay: 1s; }
                .avina-particle.p5 { left: 82%; width: 200px; height: 200px; background: radial-gradient(circle, rgba(56,189,248,0.3) 0%, rgba(56,189,248,0) 70%); filter: blur(35px); animation-duration: 25s; animation-delay: 6s; }
                .avina-particle.p6 { left: 38%; width: 70px; height: 70px; background: radial-gradient(circle, rgba(251,191,36,0.4) 0%, rgba(251,191,36,0) 70%); filter: blur(15px); animation-duration: 14s; animation-delay: 5s; }
                .avina-particle.p7 { left: 58%; width: 140px; height: 140px; background: radial-gradient(circle, rgba(99,102,241,0.35) 0%, rgba(99,102,241,0) 70%); filter: blur(25px); animation-duration: 21s; animation-delay: 3s; }
                .avina-particle.p8 { left: 92%; width: 110px; height: 110px; background: radial-gradient(circle, rgba(16,185,129,0.35) 0%, rgba(16,185,129,0) 70%); filter: blur(20px); animation-duration: 17s; animation-delay: 7s; }

                @keyframes avinaFloatUpParticle {
                    0% {
                        transform: translateY(105vh) scale(0.6) rotate(0deg);
                        opacity: 0;
                    }
                    15% {
                        opacity: 0.9;
                    }
                    85% {
                        opacity: 0.9;
                    }
                    100% {
                        transform: translateY(-20vh) scale(1.3) rotate(360deg);
                        opacity: 0;
                    }
                }
            </style>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    public function renderLoginStandalonePage(): string
    {
        $loginContent = $this->renderLoginShortcode();

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <title>ورود به سامانه آوینا CRM</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                html, body {
                    width: 100% !important;
                    height: 100% !important;
                    min-height: 100vh !important;
                    background-color: #020617 !important;
                    font-family: Tahoma, 'Vazirmatn', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
                    overflow-x: hidden !important;
                    color: #f8fafc;
                    direction: rtl;
                }
                #wpadminbar { display: none !important; }
            </style>
        </head>
        <body class="avina-crm-login-standalone">
            <?php echo $loginContent; ?>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }

    public function renderStandaloneUserPage(\WP_Post $post): string
    {
        $userId = $this->extractUserIdFromShortcode($post->post_content);
        $contentHtml = $this->renderUserShortcode(['user_id' => $userId]);

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo esc_html($post->post_title); ?></title>
            <?php wp_head(); ?>
            <style>
                html, body {
                    margin: 0 !important;
                    padding: 0 !important;
                    width: 100vw !important;
                    height: 100vh !important;
                    background-color: #0f172a !important;
                    overflow: hidden !important;
                }
                #wpadminbar { display: none !important; }
            </style>
        </head>
        <body class="avina-crm-standalone-page">
            <?php echo $contentHtml; ?>
            <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }

    public function renderStandaloneAdminPage(): string
    {
        try {
            $contentHtml = $this->renderAdminShortcode();
        } catch (\Throwable $e) {
            error_log('Avina CRM renderAdminShortcode error: ' . $e->getMessage());
            $contentHtml = '<div id="avina-crm-root" class="avina-crm-fullscreen" dir="rtl" lang="fa" data-mode="admin"></div>';
        }

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <title>پیشخوان مدیریت - آوینا CRM</title>
            <?php
            try {
                wp_head();
            } catch (\Throwable $e) {
                error_log('Avina CRM wp_head error in admin page: ' . $e->getMessage());
            }
            ?>
            <style>
                html, body {
                    margin: 0 !important;
                    padding: 0 !important;
                    width: 100vw !important;
                    height: 100vh !important;
                    background-color: #020617 !important;
                    overflow: hidden !important;
                }
                #wpadminbar { display: none !important; }
            </style>
        </head>
        <body class="avina-crm-standalone-page avina-crm-active-page">
            <?php echo $contentHtml; ?>
            <?php
            try {
                wp_footer();
            } catch (\Throwable $e) {
                error_log('Avina CRM wp_footer error in admin page: ' . $e->getMessage());
            }
            ?>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }

    public function renderStandaloneOperatorPage(int $userId): string
    {
        try {
            $contentHtml = $this->renderUserShortcode(['user_id' => $userId]);
        } catch (\Throwable $e) {
            error_log('Avina CRM renderUserShortcode error: ' . $e->getMessage());
            $contentHtml = '<div id="avina-crm-root" class="avina-crm-fullscreen" dir="rtl" lang="fa" data-mode="operator"></div>';
        }

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <title>میز کار اپراتور - آوینا CRM</title>
            <?php
            try {
                wp_head();
            } catch (\Throwable $e) {
                error_log('Avina CRM wp_head error in operator page: ' . $e->getMessage());
            }
            ?>
            <style>
                html, body {
                    margin: 0 !important;
                    padding: 0 !important;
                    width: 100vw !important;
                    height: 100vh !important;
                    background-color: #020617 !important;
                    overflow: hidden !important;
                }
                #wpadminbar { display: none !important; }
            </style>
        </head>
        <body class="avina-crm-standalone-page avina-crm-active-page">
            <?php echo $contentHtml; ?>
            <?php
            try {
                wp_footer();
            } catch (\Throwable $e) {
                error_log('Avina CRM wp_footer error in operator page: ' . $e->getMessage());
            }
            ?>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }

    private function extractUserIdFromShortcode(string $content): int
    {
        if (preg_match('/\[avina_crm_user\s+user_id=["\']?(\d+)["\']?\]/i', $content, $m)) {
            return (int) $m[1];
        }
        return 0;
    }

    public function handleAjaxLogin(): void
    {
        $rawUsername = (string) ($_POST['username'] ?? '');
        $rawPassword = (string) ($_POST['password'] ?? '');

        $username = sanitize_text_field(\AvinaCRM\Operators\OperatorService::toEnglishDigits(trim($rawUsername)));
        $password = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim($rawPassword));

        if (empty($username) || empty($password)) {
            wp_send_json_error(['message' => 'لطفاً نام کاربری و رمز عبور را وارد کنید.'], 400);
        }

        if (!defined('TEST_COOKIE')) {
            define('TEST_COOKIE', 'testcookie');
        }
        $_COOKIE[TEST_COOKIE] = 'WP Cookie check';

        $user = null;
        $foundUser = get_user_by('login', $username);
        if (!$foundUser && is_email($username)) {
            $foundUser = get_user_by('email', $username);
        }
        if (!$foundUser) {
            $mobileUsers = get_users([
                'meta_key' => 'avina_crm_operator_mobile',
                'meta_value' => $username,
                'number' => 1
            ]);
            if (!empty($mobileUsers)) {
                $foundUser = $mobileUsers[0];
            }
        }

        if ($foundUser instanceof \WP_User) {
            if (wp_check_password($password, $foundUser->user_pass, $foundUser->ID)) {
                $user = $foundUser;
            } else {
                $checkAuth = wp_authenticate_username_password(null, $foundUser->user_login, $password);
                if ($checkAuth instanceof \WP_User) {
                    $user = $checkAuth;
                }
            }
        }

        if (!$user instanceof \WP_User) {
            $fallbackAuth = wp_authenticate($username, $password);
            if ($fallbackAuth instanceof \WP_User) {
                $user = $fallbackAuth;
            }
        }

        if (!$user instanceof \WP_User) {
            wp_send_json_error(['message' => 'نام کاربری یا رمز عبور اشتباه است.'], 401);
        }

        wp_clear_auth_cookie();
        wp_set_current_user($user->ID, $user->user_login);
        $isHttps = is_ssl()
            || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
            || (isset($_SERVER['HTTPS']) && (strtolower((string) $_SERVER['HTTPS']) === 'on' || $_SERVER['HTTPS'] === '1'))
            || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443);
        $remember = !empty($_POST['remember']);
        wp_set_auth_cookie($user->ID, $remember, $isHttps);
        do_action('wp_login', $user->user_login, $user);

        $crmToken = \AvinaCRM\Support\TokenService::generateToken($user->ID);
        $isAdmin = in_array('administrator', (array) $user->roles, true) || user_can($user, 'manage_options');
        $redirectUrl = $isAdmin ? site_url('/crm-admin/') : site_url('/crm-operator/');

        wp_send_json_success([
            'id' => $user->ID,
            'name' => $user->display_name ?: $user->user_login,
            'username' => $user->user_login,
            'role' => $isAdmin ? 'admin' : 'editor',
            'crm_token' => $crmToken,
            'nonce' => wp_create_nonce('wp_rest'),
            'redirect_url' => $redirectUrl
        ]);
    }

    /**
     * Standalone Public Invoice Page with 24-hour Expiration & Card-to-Card Payment
     */
    public function renderPublicInvoiceStandalonePage(string $invoiceId): string
    {
        $allInvoices = get_option('avina_public_invoices', []);
        $invoice = null;

        if (!empty($allInvoices) && is_array($allInvoices)) {
            foreach ($allInvoices as $inv) {
                if (($inv['id'] ?? '') === $invoiceId || (string)($inv['invoiceNumber'] ?? '') === $invoiceId) {
                    $invoice = $inv;
                    break;
                }
            }
        }

        // Also check wpdb avina_invoices table if not found in option
        if (!$invoice && !empty($invoiceId)) {
            global $wpdb;
            $table = $wpdb->prefix . 'avina_invoices';
            $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table;
            if ($tableExists) {
                $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d OR invoice_number = %s LIMIT 1", (int)$invoiceId, $invoiceId), ARRAY_A);
                if ($row) {
                    $itemsTable = $wpdb->prefix . 'avina_invoice_items';
                    $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$itemsTable} WHERE invoice_id = %d", (int)$row['id']), ARRAY_A) ?: [];
                    $invoice = [
                        'id' => (string)$row['id'],
                        'invoiceNumber' => $row['invoice_number'] ?? ('INV-' . $row['id']),
                        'invoiceType' => $row['type'] === 'quote' ? 'proforma' : 'sale',
                        'customerName' => $row['customer_name'] ?? 'مشتری گرامی',
                        'customerPhone' => $row['customer_phone'] ?? '',
                        'total' => (float)($row['total'] ?? 0),
                        'discount' => (float)($row['discount'] ?? 0),
                        'tax' => (float)($row['tax'] ?? 0),
                        'status' => $row['status'] ?? 'issued',
                        'createdAt' => $row['created_at'] ?? current_time('mysql'),
                        'createdAtTimestamp' => strtotime($row['created_at'] ?? 'now'),
                        'items' => array_map(function($it) {
                            return [
                                'description' => $it['description'] ?? '',
                                'code' => $it['sku'] ?? $it['code'] ?? '',
                                'quantity' => (float)($it['quantity'] ?? 1),
                                'unitPrice' => (float)($it['unit_price'] ?? 0),
                                'total' => (float)($it['total'] ?? 0)
                            ];
                        }, $items)
                    ];
                }
            }
        }

        $appData = get_option('avina_crm_app_data', []);
        $settings = $appData['settings'] ?? [];
        $sellerName = $invoice['sellerInfo']['name'] ?? ($settings['businessName'] ?? 'مجموعه مهندسی و نرم‌افزاری آوینا');
        $sellerPhone = $invoice['sellerInfo']['phone'] ?? ($settings['phone'] ?? '021-88990011');
        $sellerAddress = $invoice['sellerInfo']['address'] ?? ($settings['address'] ?? 'تهران، میدان ونک');
        $sellerEco = $invoice['sellerInfo']['economicCode'] ?? '14008923411';

        $cardInfo = $invoice['cardInfo'] ?? [
            'bankName' => 'بانک سامان / ملی',
            'cardNumber' => '۶۲۱۹-۸۶۱۰-۴۵۸۹-۷۲۳۱',
            'cardHolder' => 'شرکت آوینا پردازش هوشمند',
            'shabaNumber' => 'IR680560086180004589723101'
        ];

        // 24-Hour Expiration Check
        $createdTimestamp = !empty($invoice['createdAtTimestamp'])
            ? (int)$invoice['createdAtTimestamp']
            : (!empty($invoice['createdAt']) ? strtotime($invoice['createdAt']) : time());
        
        $isExpired = false;
        $remainingHours = 24;
        if ($createdTimestamp > 0) {
            $ageSeconds = time() - $createdTimestamp;
            if ($ageSeconds > 86400) {
                $isExpired = true;
            } else {
                $remainingHours = max(1, round((86400 - $ageSeconds) / 3600));
            }
        }

        $ajaxUrl = admin_url('admin-ajax.php');

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <title><?php echo esc_html(($invoice['invoiceType'] ?? '') === 'proforma' ? 'پیش‌فاکتور فروش' : 'فاکتور رسمی'); ?> - <?php echo esc_html($invoice['invoiceNumber'] ?? 'آوینا CRM'); ?></title>
            <script src="https://cdn.tailwindcss.com"></script>
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700;900&display=swap');
                body {
                    font-family: 'Vazirmatn', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background-color: #030712;
                    color: #f3f4f6;
                }
            </style>
        </head>
        <body class="min-h-screen py-6 px-3 sm:px-6 flex flex-col items-center justify-start antialiased">
            <div class="w-full max-w-3xl space-y-6">

                <?php if (!$invoice): ?>
                    <!-- INVOICE NOT FOUND -->
                    <div class="p-8 rounded-3xl bg-slate-900 border border-slate-800 text-center space-y-4 shadow-2xl">
                        <span class="text-5xl block">📄</span>
                        <h2 class="text-xl font-black text-rose-400">فاکتور یا پیش‌فاکتور یافت نشد</h2>
                        <p class="text-xs text-slate-400">شناسه وارد شده نامعتبر است یا این فاکتور از سیستم حذف شده است.</p>
                        <p class="text-[11px] text-slate-500">جهت دریافت لینک جدید با واحد پشتیبانی تماس بگیرید.</p>
                    </div>
                <?php elseif ($isExpired): ?>
                    <!-- EXPIRED NOTICE (24h validity exceeded) -->
                    <div class="p-8 rounded-3xl bg-slate-900 border border-rose-500/40 text-center space-y-4 shadow-2xl">
                        <span class="text-5xl block animate-bounce">⏳</span>
                        <h2 class="text-xl font-black text-rose-400">مهلت پرداخت این فاکتور به پایان رسیده است</h2>
                        <p class="text-xs text-slate-300">اعتبار لینک‌های پرداخت و پیش‌فاکتور ۲۴ ساعت از زمان صدور می‌باشد.</p>
                        <div class="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-200">
                            شماره فاکتور: <strong><?php echo esc_html($invoice['invoiceNumber'] ?? '-'); ?></strong> • تاریخ صدور: <?php echo esc_html(substr($invoice['createdAt'] ?? '', 0, 10)); ?>
                        </div>
                        <p class="text-[11px] text-slate-400">جهت تمدید پیش‌فاکتور و صدور لینک جدید، لطفاً با کارشناس فروش تماس حاصل فرمایید.</p>
                    </div>
                <?php else: ?>
                    <!-- VALID INVOICE VIEW -->
                    <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-amber-500/40 shadow-2xl space-y-6 backdrop-blur-xl">
                        
                        <!-- Header Bar -->
                        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-slate-800">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-700 flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-amber-500/30">
                                    آوینا
                                </div>
                                <div>
                                    <h1 class="text-lg font-black text-amber-400">
                                        <?php echo ($invoice['invoiceType'] ?? '') === 'proforma' ? '📑 پیش‌فاکتور رسمی فروش' : '🧾 فاکتور فروش کالا و خدمات'; ?>
                                    </h1>
                                    <p class="text-xs text-slate-400"><?php echo esc_html($sellerName); ?></p>
                                </div>
                            </div>
                            <div class="text-left font-mono text-xs space-y-1">
                                <div class="text-amber-400">شماره: <span class="font-bold text-white"><?php echo esc_html($invoice['invoiceNumber'] ?? '-'); ?></span></div>
                                <div class="text-slate-400">تاریخ: <span class="text-slate-200"><?php echo esc_html(substr($invoice['createdAt'] ?? '', 0, 10)); ?></span></div>
                                <div class="text-emerald-400 text-[10px]">اعتبار لینک: <span class="font-bold"><?php echo esc_html($remainingHours); ?> ساعت مانده</span></div>
                            </div>
                        </div>

                        <!-- Parties Grid -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs">
                            <div class="space-y-1">
                                <span class="text-amber-400 font-bold block">مشخصات خریدار / متقاضی:</span>
                                <div class="text-sm font-black text-white"><?php echo esc_html($invoice['customerName'] ?? 'مشتری محترم'); ?></div>
                                <?php if (!empty($invoice['customerPhone'])): ?>
                                    <div class="text-slate-400 font-mono">تلفن همراه: <?php echo esc_html($invoice['customerPhone']); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="space-y-1">
                                <span class="text-amber-400 font-bold block">مشخصات فروشنده:</span>
                                <div class="font-bold text-slate-200"><?php echo esc_html($sellerName); ?></div>
                                <div class="text-slate-400">تلفن: <?php echo esc_html($sellerPhone); ?></div>
                                <div class="text-slate-400">کد اقتصادی: <?php echo esc_html($sellerEco); ?></div>
                            </div>
                        </div>

                        <!-- Line Items Table -->
                        <div class="overflow-x-auto rounded-2xl border border-slate-800">
                            <table class="w-full text-xs text-right">
                                <thead class="bg-slate-950 text-slate-400 font-bold border-b border-slate-800">
                                    <tr>
                                        <th class="p-3">ردیف</th>
                                        <th class="p-3">شرح کالا یا خدمت</th>
                                        <th class="p-3">کد شناسه (SKU)</th>
                                        <th class="p-3 text-center">تعداد</th>
                                        <th class="p-3">مبلغ واحد (تومان)</th>
                                        <th class="p-3">جمع کل (تومان)</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-800/60">
                                    <?php 
                                    $items = $invoice['items'] ?? [];
                                    $idx = 1;
                                    foreach ($items as $item): 
                                    ?>
                                        <tr class="hover:bg-slate-800/30 transition">
                                            <td class="p-3 font-mono text-slate-500"><?php echo $idx++; ?></td>
                                            <td class="p-3 font-bold text-white"><?php echo esc_html($item['description'] ?? '-'); ?></td>
                                            <td class="p-3 font-mono text-amber-300"><?php echo esc_html($item['code'] ?? $item['sku'] ?? '-'); ?></td>
                                            <td class="p-3 font-mono text-center font-bold"><?php echo esc_html($item['quantity'] ?? 1); ?></td>
                                            <td class="p-3 font-mono"><?php echo number_format((float)($item['unitPrice'] ?? 0)); ?></td>
                                            <td class="p-3 font-mono font-bold text-emerald-400"><?php echo number_format((float)($item['total'] ?? 0)); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Total Summary -->
                        <div class="p-4 rounded-2xl bg-gradient-to-l from-emerald-950/40 to-slate-950 border border-emerald-500/30 flex flex-col sm:flex-row justify-between items-center gap-3">
                            <span class="text-xs text-slate-300">مبلغ نهایی قابل پرداخت:</span>
                            <div class="text-right">
                                <span class="text-2xl font-black font-mono text-emerald-400"><?php echo number_format((float)($invoice['total'] ?? 0)); ?></span>
                                <span class="text-xs text-slate-300 mr-1.5 font-bold">تومان</span>
                            </div>
                        </div>

                        <?php if (($invoice['status'] ?? '') === 'paid'): ?>
                            <!-- ALREADY PAID BADGE -->
                            <div class="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-500 text-center space-y-2">
                                <span class="text-4xl block">✅</span>
                                <h3 class="text-lg font-black text-emerald-400">این فاکتور با موفقیت تسویه و پرداخت شده است</h3>
                                <p class="text-xs text-slate-300">رسید واریزی شما تایید و به واحد مالی ثبت گردیده است.</p>
                            </div>
                        <?php else: ?>
                            <!-- CARD-TO-CARD PAYMENT BOX -->
                            <div class="p-5 sm:p-6 rounded-3xl bg-slate-950 border border-cyan-500/40 space-y-4 shadow-xl">
                                <div class="flex items-center gap-2 text-cyan-400 font-bold text-sm">
                                    <span>💳</span>
                                    <span>اطلاعات واریز کارت به کارت</span>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                                    <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 flex justify-between items-center">
                                        <div>
                                            <span class="text-[10px] text-slate-400 block">شماره کارت:</span>
                                            <span class="font-mono text-sm font-bold text-amber-300"><?php echo esc_html($cardInfo['cardNumber'] ?? ''); ?></span>
                                        </div>
                                        <button type="button" onclick="navigator.clipboard.writeText('<?php echo esc_js(str_replace('-', '', $cardInfo['cardNumber'] ?? '')); ?>'); alert('شماره کارت کپی شد');" class="px-2.5 py-1 text-[11px] bg-amber-500/20 text-amber-300 rounded-lg font-bold hover:bg-amber-500/30 cursor-pointer">کپی</button>
                                    </div>
                                    <div class="p-3 rounded-xl bg-slate-900 border border-slate-800">
                                        <span class="text-[10px] text-slate-400 block">بانک و صاحب حساب:</span>
                                        <span class="font-bold text-slate-200"><?php echo esc_html($cardInfo['bankName'] ?? ''); ?> - <?php echo esc_html($cardInfo['cardHolder'] ?? ''); ?></span>
                                    </div>
                                    <div class="sm:col-span-2 p-3 rounded-xl bg-slate-900 border border-slate-800 flex justify-between items-center">
                                        <div>
                                            <span class="text-[10px] text-slate-400 block">شماره شبا (IBAN):</span>
                                            <span class="font-mono text-xs text-cyan-300"><?php echo esc_html($cardInfo['shabaNumber'] ?? ''); ?></span>
                                        </div>
                                        <button type="button" onclick="navigator.clipboard.writeText('<?php echo esc_js($cardInfo['shabaNumber'] ?? ''); ?>'); alert('شماره شبا کپی شد');" class="px-2.5 py-1 text-[11px] bg-cyan-500/20 text-cyan-300 rounded-lg font-bold hover:bg-cyan-500/30 cursor-pointer">کپی</button>
                                    </div>
                                </div>

                                <!-- RECEIPT SUBMISSION FORM -->
                                <form id="receiptForm" class="pt-4 border-t border-slate-800 space-y-3">
                                    <input type="hidden" name="invoice_id" value="<?php echo esc_attr($invoice['id'] ?? ''); ?>">
                                    <input type="hidden" name="invoice_number" value="<?php echo esc_attr($invoice['invoiceNumber'] ?? ''); ?>">
                                    <input type="hidden" name="customer_name" value="<?php echo esc_attr($invoice['customerName'] ?? ''); ?>">
                                    <input type="hidden" name="total_amount" value="<?php echo esc_attr($invoice['total'] ?? 0); ?>">

                                    <div class="text-xs font-bold text-slate-300">ثبت اطلاعات فیش واریزی توسط خریدار:</div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                                        <div class="space-y-1">
                                            <label class="text-slate-400 font-medium">شماره پیگیری / ارجاع بانکی *</label>
                                            <input type="text" name="tracking_code" required placeholder="مثلاً: 98452104" class="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-left outline-none focus:border-cyan-400">
                                        </div>
                                        <div class="space-y-1">
                                            <label class="text-slate-400 font-medium">۴ رقم آخر کارت واریزکننده *</label>
                                            <input type="text" name="card_last_4" required maxlength="4" placeholder="مثلاً: 4589" class="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-center outline-none focus:border-cyan-400">
                                        </div>
                                        <div class="space-y-1">
                                            <label class="text-slate-400 font-medium">نام بانک مبدأ</label>
                                            <input type="text" name="sender_bank" placeholder="ملت، ملی، سامان..." class="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white outline-none focus:border-cyan-400">
                                        </div>
                                        <div class="space-y-1">
                                            <label class="text-slate-400 font-medium">تاریخ و زمان واریز</label>
                                            <input type="text" name="payment_date" value="<?php echo esc_attr(current_time('mysql')); ?>" class="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-300 font-mono text-left outline-none">
                                        </div>
                                    </div>

                                    <button type="submit" id="submitReceiptBtn" class="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/20 transition cursor-pointer flex items-center justify-center gap-2">
                                        <span>✓</span>
                                        <span id="btnText">ثبت و ارسال رسید پرداخت برای واحد مالی</span>
                                    </button>
                                </form>

                                <div id="paySuccessBox" style="display:none;" class="p-6 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-center space-y-2">
                                    <span class="text-4xl block">🎉</span>
                                    <h4 class="text-base font-black text-emerald-400">رسید واریز شما با موفقیت ثبت شد</h4>
                                    <p class="text-xs text-slate-300">پیامک تایید پرداخت برای واحد مدیریت مالی ارسال گردید. از اعتماد شما سپاسگزاریم.</p>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                <?php endif; ?>

                <div class="text-center text-[10px] text-slate-600">
                    سامانه هوشمند صدور و پرداخت آنلاین فاکتور • طراحی شده با آوینا CRM
                </div>
            </div>

            <script>
            (function(){
                var form = document.getElementById('receiptForm');
                if (form) {
                    form.addEventListener('submit', async function(e){
                        e.preventDefault();
                        var btn = document.getElementById('submitReceiptBtn');
                        var btnText = document.getElementById('btnText');
                        var successBox = document.getElementById('paySuccessBox');

                        btn.disabled = true;
                        btnText.textContent = 'در حال ثبت رسید و ارسال پیامک به مدیریت... ⏳';

                        var fd = new FormData(form);
                        fd.append('action', 'avina_public_invoice_pay');

                        try {
                            var resp = await fetch('<?php echo esc_js($ajaxUrl); ?>', {
                                method: 'POST',
                                body: fd
                            });
                            var res = await resp.json();
                            if (res && res.success) {
                                form.style.display = 'none';
                                successBox.style.display = 'block';
                            } else {
                                alert((res && res.data && res.data.message) || 'خطا در ثبت رسید.');
                                btn.disabled = false;
                                btnText.textContent = 'ثبت و ارسال رسید پرداخت برای واحد مالی';
                            }
                        } catch(err) {
                            alert('خطای اتصال به سرور: ' + err.message);
                            btn.disabled = false;
                            btnText.textContent = 'ثبت و ارسال رسید پرداخت برای واحد مالی';
                        }
                    });
                }
            })();
            </script>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * AJAX handler for public invoice card-to-card receipt submission & Admin SMS notification
     */
    public function handlePublicInvoicePayAjax(): void
    {
        $invoiceId = sanitize_text_field($_POST['invoice_id'] ?? '');
        $invoiceNumber = sanitize_text_field($_POST['invoice_number'] ?? '');
        $customerName = sanitize_text_field($_POST['customer_name'] ?? '');
        $totalAmount = (float)($_POST['total_amount'] ?? 0);
        $trackingCode = sanitize_text_field($_POST['tracking_code'] ?? '');
        $cardLast4 = sanitize_text_field($_POST['card_last_4'] ?? '');
        $senderBank = sanitize_text_field($_POST['sender_bank'] ?? '');
        $paymentDate = sanitize_text_field($_POST['payment_date'] ?? current_time('mysql'));

        if (empty($invoiceId) || empty($trackingCode) || empty($cardLast4)) {
            wp_send_json_error(['message' => 'شماره پیگیری و ۴ رقم کارت الزامی است.'], 400);
        }

        // Update in avina_public_invoices option
        $allInvoices = get_option('avina_public_invoices', []);
        $foundIndex = -1;
        $itemsDesc = 'کالا و خدمات';

        if (is_array($allInvoices)) {
            foreach ($allInvoices as $idx => $inv) {
                if (($inv['id'] ?? '') === $invoiceId || (string)($inv['invoiceNumber'] ?? '') === $invoiceNumber) {
                    $foundIndex = $idx;
                    $allInvoices[$idx]['status'] = 'paid';
                    $allInvoices[$idx]['receipt'] = [
                        'trackingCode' => $trackingCode,
                        'cardLast4' => $cardLast4,
                        'senderBank' => $senderBank,
                        'date' => $paymentDate,
                        'amount' => $totalAmount
                    ];
                    if (!empty($inv['items']) && is_array($inv['items'])) {
                        $names = array_filter(array_map(function($i){ return $i['description'] ?? ''; }, $inv['items']));
                        if (!empty($names)) {
                            $itemsDesc = implode('، ', array_slice($names, 0, 3));
                        }
                    }
                    break;
                }
            }
            if ($foundIndex >= 0) {
                update_option('avina_public_invoices', $allInvoices);
            }
        }

        // Update in avina_invoices table if table exists
        global $wpdb;
        $tableInvoices = $wpdb->prefix . 'avina_invoices';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$tableInvoices}'") === $tableInvoices) {
            $wpdb->update($tableInvoices, ['status' => 'paid'], ['id' => (int)$invoiceId]);
            $tablePayments = $wpdb->prefix . 'avina_payments';
            if ($wpdb->get_var("SHOW TABLES LIKE '{$tablePayments}'") === $tablePayments) {
                $wpdb->insert($tablePayments, [
                    'invoice_id' => (int)$invoiceId,
                    'amount' => $totalAmount,
                    'method' => 'card',
                    'reference' => $trackingCode,
                    'created_at' => current_time('mysql')
                ]);
            }
        }

        // Send SMS to Super Admin Mobile
        $adminMobile = get_option('avina_crm_admin_notification_mobile') ?: (get_user_meta(1, 'avina_crm_operator_mobile', true) ?: '09138996197');

        $appData = get_option('avina_crm_app_data', []);
        $smsSettings = $appData['settings']['sms'] ?? [];
        $apiKey = sanitize_text_field((string)($smsSettings['apiKey'] ?? ''));
        $sender = sanitize_text_field((string)($smsSettings['senderNumber'] ?? ($smsSettings['sender'] ?? '')));

        $smsMessage = sprintf(
            "واریز فاکتور: %s\nمشتری: %s\nمبلغ: %s تومان\nکارت: %s\nپیگیری: %s\nخدمت: %s\nتاریخ: %s",
            $invoiceNumber,
            $customerName,
            number_format($totalAmount),
            $cardLast4,
            $trackingCode,
            $itemsDesc,
            $paymentDate
        );

        if (!empty($apiKey) && !empty($sender) && !empty($adminMobile)) {
            $smsService = new \AvinaCRM\SMS\SmsService();
            $smsService->sendIpPanelSms($apiKey, $sender, [$adminMobile], $smsMessage, 1);
        }

        wp_send_json_success([
            'message' => 'رسید پرداخت با موفقیت ثبت شد و پیامک برای مدیریت ارسال گردید.',
            'invoice_id' => $invoiceId
        ]);
    }

}
