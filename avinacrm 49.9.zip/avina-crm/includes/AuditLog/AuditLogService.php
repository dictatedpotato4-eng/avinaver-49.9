<?php

declare(strict_types=1);

namespace AvinaCRM\AuditLog;

/**
 * Read-only query layer over {prefix}avina_audit_log. Gated entirely by
 * the audit.log.view capability at the REST layer — this class itself
 * applies no additional scoping, since audit.log.view is intentionally
 * an administrator-level capability (seeing who did what across the
 * whole system is the point of an audit log; a self-scoped audit log
 * would defeat its purpose).
 */
final class AuditLogService
{
    /**
     * @param array{actor_user_id?: int, object_type?: string, action?: string, since?: string, until?: string, page?: int, per_page?: int} $filters
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_audit_log';

        $where = ['1=1'];

        if (!empty($filters['actor_user_id'])) {
            $where[] = $wpdb->prepare('actor_user_id = %d', (int) $filters['actor_user_id']);
        }

        if (!empty($filters['object_type'])) {
            $where[] = $wpdb->prepare('object_type = %s', sanitize_key($filters['object_type']));
        }

        if (!empty($filters['action'])) {
            $where[] = $wpdb->prepare('action LIKE %s', '%' . $wpdb->esc_like(sanitize_text_field($filters['action'])) . '%');
        }

        if (!empty($filters['since'])) {
            $where[] = $wpdb->prepare('created_at >= %s', $this->normalizeDatetime($filters['since']));
        }

        if (!empty($filters['until'])) {
            $where[] = $wpdb->prepare('created_at <= %s', $this->normalizeDatetime($filters['until']));
        }

        $whereSql = implode(' AND ', $where);

        $perPage = min(200, max(1, (int) ($filters['per_page'] ?? 50)));
        $page = max(1, (int) ($filters['page'] ?? 1));
        $offset = ($page - 1) * $perPage;

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$whereSql}");

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE {$whereSql} ORDER BY created_at DESC LIMIT %d OFFSET %d", $perPage, $offset),
            ARRAY_A
        );

        return ['items' => array_map([$this, 'decorate'], $rows ?: []), 'total' => $total];
    }

    private function normalizeDatetime(string $value): string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d H:i:s', $timestamp) : current_time('mysql');
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['actor_user_id'] = $row['actor_user_id'] !== null ? (int) $row['actor_user_id'] : null;

        if ($row['actor_user_id']) {
            $user = get_user_by('id', $row['actor_user_id']);
            $row['actor_display_name'] = $user ? $user->display_name : null;
        } else {
            $row['actor_display_name'] = null;
        }

        // before_state/after_state are stored as JSON text (already
        // redacted for secrets by AuditLogger at write time) — decode
        // for the API response rather than shipping a raw JSON string
        // inside a JSON string.
        $row['before_state'] = $row['before_state'] !== null ? json_decode($row['before_state'], true) : null;
        $row['after_state'] = $row['after_state'] !== null ? json_decode($row['after_state'], true) : null;

        return $row;
    }
}
