<?php

declare(strict_types=1);

namespace AvinaCRM\Notifications;

/**
 * Notifications are always self-scoped, same principle as Reminders:
 * every read/write here operates only on the current user's own rows.
 * There is no "list notifications for another user" path — even an
 * administrator uses this service only for themselves; broadcasting a
 * notification TO other users is a write performed by other services
 * (e.g. Tickets, Tasks) calling notifyUser() below, never a read across
 * users.
 */
final class NotificationService
{
    public function listForCurrentUser(bool $unreadOnly = false): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_notifications';
        $userId = get_current_user_id();

        $where = $wpdb->prepare('user_id = %d', $userId);

        if ($unreadOnly) {
            $where .= ' AND is_read = 0';
        }

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT 100",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    public function unreadCount(): int
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_notifications';
        $userId = get_current_user_id();

        return (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0", $userId)
        );
    }

    public function markRead(int $id, int $actorUserId): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_notifications';

        $updated = $wpdb->update(
            $table,
            ['is_read' => 1],
            ['id' => $id, 'user_id' => $actorUserId],
            ['%d'],
            ['%d', '%d']
        );

        return $updated !== false && $updated > 0;
    }

    public function markAllRead(int $actorUserId): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_notifications';

        $wpdb->update($table, ['is_read' => 1], ['user_id' => $actorUserId, 'is_read' => 0], ['%d'], ['%d', '%d']);
    }

    /**
     * Creates a notification FOR a given user. Called by other services
     * (Tickets, Tasks) — not exposed as a public REST-writable action, so
     * a user can never spoof a notification as coming from someone else
     * or spam another user's notification feed directly through this
     * module's own REST surface.
     */
    public function notifyUser(int $userId, string $type, string $title, string $body = '', string $relatedType = '', ?int $relatedId = null): void
    {
        if (get_user_by('id', $userId) === false) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_notifications';

        $wpdb->insert(
            $table,
            [
                'user_id' => $userId,
                'type' => sanitize_key($type),
                'title' => sanitize_text_field($title),
                'body' => sanitize_textarea_field($body),
                'related_type' => sanitize_key($relatedType),
                'related_id' => $relatedId,
                'is_read' => 0,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s']
        );
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['related_id'] = $row['related_id'] !== null ? (int) $row['related_id'] : null;
        $row['is_read'] = (bool) $row['is_read'];

        return $row;
    }
}
