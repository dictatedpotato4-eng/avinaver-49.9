<?php

declare(strict_types=1);

namespace AvinaCRM\Teams;

use AvinaCRM\Audit\AuditLogger;
use WP_Error;

final class TeamService
{
    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function list(bool $includeArchived = false): array
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_teams';
        $where = $includeArchived ? '1=1' : 'is_archived = 0';

        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE {$where} ORDER BY name ASC", ARRAY_A);

        foreach ($rows as &$row) {
            $row['members'] = $this->membersOf((int) $row['id']);
        }
        unset($row);

        return $rows ?: [];
    }

    /**
     * @return array<int, array{user_id: int, display_name: string, role_in_team: string}>
     */
    public function membersOf(int $teamId): array
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_team_members';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT user_id, role_in_team FROM {$table} WHERE team_id = %d", $teamId),
            ARRAY_A
        );

        $result = [];
        foreach ((array) $rows as $row) {
            $user = get_user_by('id', (int) $row['user_id']);
            $result[] = [
                'user_id' => (int) $row['user_id'],
                'display_name' => $user ? $user->display_name : __('کاربر حذف شده', 'avina-crm'),
                'role_in_team' => $row['role_in_team'],
            ];
        }

        return $result;
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(string $name, string $description, int $actorUserId)
    {
        $name = sanitize_text_field($name);

        if ($name === '') {
            return new WP_Error('avina_crm_invalid_team', __('نام تیم الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_teams';

        $wpdb->insert(
            $table,
            [
                'name' => $name,
                'description' => sanitize_textarea_field($description),
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'teams.team.create', 'team', (string) $id, null, ['name' => $name]);

        return ['id' => $id];
    }

    /**
     * @return true|WP_Error
     */
    public function addMember(int $teamId, int $userId, string $roleInTeam, int $actorUserId)
    {
        if (!$this->exists($teamId)) {
            return new WP_Error('avina_crm_team_not_found', __('تیم موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (get_user_by('id', $userId) === false) {
            return new WP_Error('avina_crm_user_not_found', __('کاربر موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_team_members';

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$table} (team_id, user_id, role_in_team, created_at)
                 VALUES (%d, %d, %s, NOW())
                 ON DUPLICATE KEY UPDATE role_in_team = VALUES(role_in_team)",
                $teamId,
                $userId,
                sanitize_text_field($roleInTeam) ?: 'member'
            )
        );

        $this->audit->record($actorUserId, 'teams.member.add', 'team', (string) $teamId, null, ['user_id' => $userId]);

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function removeMember(int $teamId, int $userId, int $actorUserId)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_team_members';

        $wpdb->delete($table, ['team_id' => $teamId, 'user_id' => $userId], ['%d', '%d']);

        $this->audit->record($actorUserId, 'teams.member.remove', 'team', (string) $teamId, null, ['user_id' => $userId]);

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function update(int $teamId, array $data, int $actorUserId)
    {
        if (!$this->exists($teamId)) {
            return new WP_Error('avina_crm_team_not_found', __('تیم موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $fields = [];
        $formats = [];

        if (isset($data['name'])) {
            $name = sanitize_text_field($data['name']);
            if ($name === '') {
                return new WP_Error('avina_crm_invalid_team', __('نام تیم نمی‌تواند خالی باشد.', 'avina-crm'), ['status' => 400]);
            }
            $fields['name'] = $name;
            $formats[] = '%s';
        }

        if (isset($data['description'])) {
            $fields['description'] = sanitize_textarea_field($data['description']);
            $formats[] = '%s';
        }

        if (empty($fields)) {
            return true;
        }

        $fields['updated_at'] = current_time('mysql');
        $formats[] = '%s';

        global $wpdb;
        $wpdb->update($wpdb->prefix . 'avina_teams', $fields, ['id' => $teamId], $formats, ['%d']);

        $this->audit->record($actorUserId, 'teams.team.update', 'team', (string) $teamId, null, $fields);

        return true;
    }

    public function exists(int $teamId): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_teams';

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE id = %d", $teamId)) > 0;
    }
}
