<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Customers\CustomerService;
use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Support\Csv;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class CustomersController
{
    private CustomerService $service;

    public function __construct()
    {
        $this->service = new CustomerService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'search' => (string) $request->get_param('search'),
            'status' => (string) $request->get_param('status'),
            'page' => $request->get_param('page'),
            'per_page' => $request->get_param('per_page'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function get(WP_REST_Request $request)
    {
        $item = $this->service->find((int) $request->get_param('id'));

        if ($item === null) {
            return ApiResponse::error('avina_crm_customer_not_found', __('مشتری موردنظر یافت نشد.', 'avina-crm'), 404);
        }

        return ApiResponse::success($item);
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('customers') || current_user_can('customers.customer.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('customers') || current_user_can('customers.customer.create');
    }

    public function update(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->update((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('customers') || current_user_can('customers.customer.update');
    }

    public function archive(WP_REST_Request $request)
    {
        $result = $this->service->archive((int) $request->get_param('id'), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function archivePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('customers') || current_user_can('customers.customer.archive');
    }

    public function addNote(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->addNote((int) $request->get_param('id'), (string) ($params['body'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function addPurchase(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $product = (string) ($params['product'] ?? '');
        $amount = (float) ($params['amount'] ?? 0.0);
        $result = $this->service->addPurchase((int) $request->get_param('id'), $product, $amount, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function export(WP_REST_Request $request)
    {
        $filters = [
            'search' => (string) $request->get_param('search'),
            'lifecycle_stage' => (string) $request->get_param('lifecycle_stage'),
            'team_id' => $request->get_param('team_id'),
        ];

        $export = $this->service->exportRows($filters);

        Csv::streamDownload('avina-crm-customers.csv', $export['headers'], $export['rows']);
        exit;
    }

    public function exportPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('customers') || current_user_can('customers.customer.export');
    }
}
