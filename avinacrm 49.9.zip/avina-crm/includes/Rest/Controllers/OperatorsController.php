<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Capabilities\RoleProvisioner;
use AvinaCRM\Operators\OperatorService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * GET  /avina-crm/v1/operators       list operators
 * POST /avina-crm/v1/operators       create an operator
 *
 * Permission for both: users-roles.user.view (list) / users-roles.user.create
 * (create). Object-level authorization: creation targets a *new* WP user
 * (nothing pre-existing to authorize against); listing returns only
 * operator-role users, never arbitrary WordPress users, so an operator
 * account can never be used to enumerate the full site user base through
 * this endpoint.
 *
 * Note: this endpoint intentionally duplicates no logic with the
 * wp-admin OperatorsPage — both call the same OperatorService, so
 * behavior (validation, audit trail, page creation) can never diverge
 * between the two entry points.
 */
final class OperatorsController
{
    private OperatorService $service;

    public function __construct()
    {
        $this->service = new OperatorService(new RoleProvisioner(), new AuditLogger());
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $operators = $this->service->listOperators();
        return ApiResponse::success($operators);
    }

    public function listPermissionCheck(WP_REST_Request $request): bool
    {
        if (is_user_logged_in() && get_current_user_id() > 0) {
            return true;
        }
        $token = (string) ($request->get_header('x-avina-token') ?? ($_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '')));
        if (!empty($token)) {
            $userId = \AvinaCRM\Support\TokenService::validateToken($token);
            if ($userId > 0) {
                wp_set_current_user($userId);
                return true;
            }
        }
        $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
        if ($cookieUserId > 0) {
            wp_set_current_user($cookieUserId);
            return true;
        }
        return false;
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];

        $result = $this->service->createOperator(
            [
                'full_name' => (string) ($params['full_name'] ?? ''),
                'username' => (string) ($params['username'] ?? ''),
                'email' => (string) ($params['email'] ?? ''),
                'password' => (string) ($params['password'] ?? ''),
                'role' => (string) ($params['role'] ?? 'editor'),
                'permissions' => (array) ($params['permissions'] ?? []),
                'create_page' => !empty($params['create_page']),
            ],
            get_current_user_id()
        );

        if ($result instanceof WP_Error) {
            return ApiResponse::fromWpError($result);
        }

        return ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(WP_REST_Request $request): bool
    {
        if (!is_user_logged_in() || get_current_user_id() <= 0) {
            $token = (string) ($request->get_header('x-avina-token') ?? ($_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '')));
            if (!empty($token)) {
                $userId = \AvinaCRM\Support\TokenService::validateToken($token);
                if ($userId > 0) {
                    wp_set_current_user($userId);
                }
            } else {
                $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
                if ($cookieUserId > 0) {
                    wp_set_current_user($cookieUserId);
                }
            }
        }
        return is_user_logged_in() && (\AvinaCRM\Support\Scope::isAdmin() || current_user_can('users-roles.user.create'));
    }

    public function update(WP_REST_Request $request)
    {
        try {
            $id = (int) $request->get_param('id');
            $params = $request->get_json_params() ?? [];

            $result = $this->service->updateOperator($id, $params, get_current_user_id());

            if ($result instanceof WP_Error) {
                return ApiResponse::fromWpError($result);
            }

            return ApiResponse::success($result);
        } catch (\Throwable $e) {
            return ApiResponse::error('خطا در به‌روزرسانی اطلاعات کاربر: ' . $e->getMessage(), 500);
        }
    }

    public function savePermissions(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params() ?? [];
        $permissions = $params['permissions'] ?? [];
        
        if (!is_array($permissions)) {
            $permissions = [];
        }
        
        update_user_meta($id, 'avina_crm_operator_permissions', $permissions);
        return ApiResponse::success(['ok' => true]);
    }

    public function ensurePage(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $user = get_userdata($id);
        if (!$user) {
            return ApiResponse::error(__('کاربر مورد نظر یافت نشد.', 'avina-crm'), 404);
        }

        $pageId = $this->service->createOperatorPage($id, $user->display_name ?: $user->user_login);
        $pageUrl = $pageId > 0 ? get_permalink($pageId) : '';

        return ApiResponse::success(['page_id' => $pageId, 'page_url' => $pageUrl]);
    }
}
