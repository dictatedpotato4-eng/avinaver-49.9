<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Phonebook\PhonebookService;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class PhonebookController
{
    private PhonebookService $service;

    public function __construct()
    {
        $this->service = new PhonebookService();
    }

    public function search(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'search' => (string) $request->get_param('search'),
            'team_id' => $request->get_param('team_id'),
        ];

        return ApiResponse::success($this->service->search($filters));
    }

    public function permissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('phonebook') || current_user_can('phonebook.entry.view');
    }
}
