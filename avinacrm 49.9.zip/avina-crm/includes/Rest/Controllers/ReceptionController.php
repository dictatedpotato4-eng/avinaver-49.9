<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Reception\ReceptionService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class ReceptionController
{
    private ReceptionService $service;

    public function __construct()
    {
        $this->service = new ReceptionService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'status' => (string) $request->get_param('status'),
            'search' => (string) $request->get_param('search'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function get(WP_REST_Request $request)
    {
        $item = $this->service->find((int) $request->get_param('id'));

        if ($item === null) {
            return ApiResponse::error('avina_crm_reception_not_found', __('رکورد پذیرش یافت نشد.', 'avina-crm'), 404);
        }

        return ApiResponse::success($item);
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('reception') || current_user_can('reception.reception.view');
    }

    public function checkIn(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('reception') || current_user_can('reception.reception.create');
    }

    public function update(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->update((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function changeStatus(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->changeStatus((int) $request->get_param('id'), (string) ($params['status'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('reception') || current_user_can('reception.reception.update') || current_user_can('reception.reception.checkout');
    }
}
