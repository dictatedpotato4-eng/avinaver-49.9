<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Capabilities\CapabilityDefinitions;
use AvinaCRM\Capabilities\RoleProvisioner;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

/**
 * GET /avina-crm/v1/me
 *
 * Permission: must be logged in (is_user_logged_in). No specific
 * capability required beyond that — every authenticated WordPress user
 * is allowed to know who they are; the *content* of the response is
 * self-scoped (current_user only) so there is no object-level
 * authorization concern here.
 */
final class MeController
{
    public function handle(WP_REST_Request $request): WP_REST_Response
    {
        $user = wp_get_current_user();
        $targetId = (int) $request->get_param('user_id');
        $currentUserIsAdmin = \AvinaCRM\Support\Scope::isAdmin();

        if ($targetId > 0 && $currentUserIsAdmin) {
            $targetUser = get_userdata($targetId);
            if ($targetUser) {
                $user = $targetUser;
            }
        }

        $targetIsAdmin = \AvinaCRM\Support\Scope::isAdmin($user->ID);

        if ($targetIsAdmin) {
            $permissions = ['dashboard', 'settings', 'users', 'recruitment', 'inventory', 'customers', 'invoices', 'leads', 'expenses', 'cheques', 'reports', 'phonebook', 'ai-assistant', 'reception', 'tickets', 'tasks'];
        } else {
            $permissions = get_user_meta($user->ID, 'avina_crm_operator_permissions', true);
            if (!is_array($permissions)) {
                $permissions = ['dashboard', 'leads'];
            }
        }

        $messengerSettings = get_user_meta($user->ID, 'avina_crm_messenger_settings', true);
        if (empty($messengerSettings) || !is_array($messengerSettings)) {
            $messengerSettings = get_option('avina_crm_messenger_settings_' . $user->ID, []);
        }

        $avatarUrl = get_user_meta($user->ID, 'avina_crm_avatar_url', true) ?: '';
        $theme = get_user_meta($user->ID, 'avina_crm_theme', true) ?: 'light';
        $operatorThemeConfig = get_user_meta($user->ID, 'avina_crm_operator_theme_config', true) ?: null;

        $hasBirthCert = !empty(get_user_meta($user->ID, 'avina_crm_birth_cert_image', true));
        $hasNationalCard = !empty(get_user_meta($user->ID, 'avina_crm_national_card_image', true));
        $birthCertImage = ($currentUserIsAdmin || $targetIsAdmin) ? (get_user_meta($user->ID, 'avina_crm_birth_cert_image', true) ?: '') : '';
        $nationalCardImage = ($currentUserIsAdmin || $targetIsAdmin) ? (get_user_meta($user->ID, 'avina_crm_national_card_image', true) ?: '') : '';

        return ApiResponse::success([
            'id' => (string) $user->ID,
            'display_name' => $user->display_name,
            'name' => $user->display_name ?: $user->user_login,
            'username' => $user->user_login,
            'mobile' => (string) (get_user_meta($user->ID, 'avina_crm_operator_mobile', true) ?: ''),
            'landline' => (string) (get_user_meta($user->ID, 'avina_crm_landline', true) ?: ''),
            'address' => (string) (get_user_meta($user->ID, 'avina_crm_address', true) ?: ''),
            'locationLat' => get_user_meta($user->ID, 'avina_crm_location_lat', true) ?: '35.6892',
            'locationLng' => get_user_meta($user->ID, 'avina_crm_location_lng', true) ?: '51.3890',
            'hasBirthCert' => $hasBirthCert,
            'hasNationalCard' => $hasNationalCard,
            'birthCertImage' => $birthCertImage,
            'nationalCardImage' => $nationalCardImage,
            'is_operator' => in_array(RoleProvisioner::ROLE_SLUG, (array) $user->roles, true),
            'is_administrator' => $targetIsAdmin,
            'capabilities' => $permissions,
            'permissions' => $permissions,
            'messengerSettings' => is_array($messengerSettings) ? $messengerSettings : [],
            'avatarUrl' => $avatarUrl,
            'theme' => $theme,
            'operatorThemeConfig' => $operatorThemeConfig,
        ]);
    }

    public function saveProfile(WP_REST_Request $request): WP_REST_Response
    {
        $userId = get_current_user_id();
        if ($userId <= 0) {
            return ApiResponse::error('unauthorized', 'کاربر وارد نشده است.', 401);
        }

        $params = $request->get_json_params() ?? [];
        $targetId = (int) ($request->get_param('user_id') ?: ($params['user_id'] ?? 0));
        if ($targetId > 0 && \AvinaCRM\Support\Scope::isAdmin()) {
            $targetUser = get_userdata($targetId);
            if ($targetUser) {
                $userId = $targetUser->ID;
            }
        }

        $user = get_userdata($userId);
        if (!$user) {
            return ApiResponse::error('not_found', 'کاربر یافت نشد.', 404);
        }

        $name = isset($params['name']) ? sanitize_text_field((string)$params['name']) : null;
        $avatarUrl = isset($params['avatarUrl']) ? (string)$params['avatarUrl'] : (isset($params['avatar']) ? (string)$params['avatar'] : null);
        $theme = isset($params['theme']) ? sanitize_text_field((string)$params['theme']) : null;
        $operatorThemeConfig = isset($params['operatorThemeConfig']) ? $params['operatorThemeConfig'] : null;

        if ($name !== null && trim($name) !== '') {
            wp_update_user([
                'ID' => $userId,
                'display_name' => trim($name),
            ]);
            update_user_meta($userId, 'first_name', trim($name));
        }

        // Username update
        if (!empty($params['username'])) {
            $cleanUser = sanitize_user((string)$params['username'], true);
            if ($cleanUser !== '' && $cleanUser !== $user->user_login) {
                $exists = username_exists($cleanUser);
                if ($exists && (int)$exists !== $userId) {
                    return ApiResponse::error('username_exists', 'این نام کاربری قبلاً توسط کاربر دیگری ثبت شده است.', 409);
                }
                global $wpdb;
                $wpdb->update($wpdb->users, ['user_login' => $cleanUser, 'user_nicename' => $cleanUser], ['ID' => $userId]);
                clean_user_cache($userId);
                if ($userId === get_current_user_id()) {
                    wp_set_current_user($userId, $cleanUser);
                    wp_set_auth_cookie($userId, true);
                }
            }
        }

        // Password update
        if (!empty($params['password'])) {
            $cleanPass = trim((string)$params['password']);
            if ($cleanPass !== '') {
                wp_set_password($cleanPass, $userId);
                if ($userId === get_current_user_id()) {
                    wp_set_current_user($userId);
                    wp_set_auth_cookie($userId, true);
                }
            }
        }

        // Mobile
        if (isset($params['mobile'])) {
            update_user_meta($userId, 'avina_crm_operator_mobile', sanitize_text_field((string)$params['mobile']));
        }

        // Landline
        if (isset($params['landline'])) {
            update_user_meta($userId, 'avina_crm_landline', sanitize_text_field((string)$params['landline']));
        }

        // Address
        if (isset($params['address'])) {
            update_user_meta($userId, 'avina_crm_address', sanitize_textarea_field((string)$params['address']));
        }

        // Birth Certificate (Page 1)
        if (!empty($params['birthCertImage'])) {
            update_user_meta($userId, 'avina_crm_birth_cert_image', wp_strip_all_tags((string)$params['birthCertImage']));
        }

        // National ID Card (Page 1)
        if (!empty($params['nationalCardImage'])) {
            update_user_meta($userId, 'avina_crm_national_card_image', wp_strip_all_tags((string)$params['nationalCardImage']));
        }

        // Location Lat / Lng
        if (isset($params['locationLat'])) {
            update_user_meta($userId, 'avina_crm_location_lat', sanitize_text_field((string)$params['locationLat']));
        }
        if (isset($params['locationLng'])) {
            update_user_meta($userId, 'avina_crm_location_lng', sanitize_text_field((string)$params['locationLng']));
        }

        if ($avatarUrl !== null) {
            $cleanAvatar = wp_strip_all_tags($avatarUrl);
            update_user_meta($userId, 'avina_crm_avatar_url', $cleanAvatar);
        }

        if ($theme !== null && in_array($theme, ['light', 'dark', 'gold'], true)) {
            update_user_meta($userId, 'avina_crm_theme', $theme);
        }

        if ($operatorThemeConfig !== null && is_array($operatorThemeConfig)) {
            update_user_meta($userId, 'avina_crm_operator_theme_config', $operatorThemeConfig);
        }

        // Ensure session remains fresh
        if ($userId === get_current_user_id()) {
            wp_set_current_user($userId);
            wp_set_auth_cookie($userId, true);
        }

        $freshUser = get_userdata($userId);
        $hasBirthCert = !empty(get_user_meta($userId, 'avina_crm_birth_cert_image', true));
        $hasNationalCard = !empty(get_user_meta($userId, 'avina_crm_national_card_image', true));

        return ApiResponse::success([
            'saved' => true,
            'id' => (string) $userId,
            'name' => $freshUser ? ($freshUser->display_name ?: $freshUser->user_login) : '',
            'username' => $freshUser ? $freshUser->user_login : '',
            'mobile' => get_user_meta($userId, 'avina_crm_operator_mobile', true) ?: '',
            'landline' => get_user_meta($userId, 'avina_crm_landline', true) ?: '',
            'address' => get_user_meta($userId, 'avina_crm_address', true) ?: '',
            'hasBirthCert' => $hasBirthCert,
            'hasNationalCard' => $hasNationalCard,
            'locationLat' => get_user_meta($userId, 'avina_crm_location_lat', true) ?: '35.6892',
            'locationLng' => get_user_meta($userId, 'avina_crm_location_lng', true) ?: '51.3890',
            'avatarUrl' => get_user_meta($userId, 'avina_crm_avatar_url', true) ?: '',
            'theme' => get_user_meta($userId, 'avina_crm_theme', true) ?: 'light',
            'operatorThemeConfig' => get_user_meta($userId, 'avina_crm_operator_theme_config', true) ?: null,
        ]);
    }

    public function saveMessenger(WP_REST_Request $request): WP_REST_Response
    {
        $userId = get_current_user_id();
        if ($userId <= 0) {
            return ApiResponse::error('unauthorized', 'کاربر وارد نشده است.', 401);
        }

        $params = $request->get_json_params() ?? [];
        $targetId = (int) ($request->get_param('user_id') ?: ($params['user_id'] ?? 0));
        if ($targetId > 0 && \AvinaCRM\Support\Scope::isAdmin()) {
            $targetUser = get_userdata($targetId);
            if ($targetUser) {
                $userId = $targetUser->ID;
            }
        }

        $settings = is_array($params['messengerSettings'] ?? null) ? $params['messengerSettings'] : (is_array($params['messenger_settings'] ?? null) ? $params['messenger_settings'] : $params);

        $sanitized = [];
        if (is_array($settings)) {
            foreach ($settings as $k => $v) {
                $sanitized[sanitize_key((string)$k)] = sanitize_text_field((string)$v);
            }
        }

        update_user_meta($userId, 'avina_crm_messenger_settings', $sanitized);
        update_option('avina_crm_messenger_settings_' . $userId, $sanitized);

        return ApiResponse::success([
            'saved' => true,
            'id' => (string) $userId,
            'messengerSettings' => $sanitized
        ]);
    }

    public function permissionCheck(\WP_REST_Request $request): bool
    {
        if (is_user_logged_in() && get_current_user_id() > 0) {
            return true;
        }

        $token = (string) ($request->get_header('x-avina-token') ?? ($_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '')));
        if (!empty($token)) {
            $userId = \AvinaCRM\Support\TokenService::validateToken($token);
            if ($userId > 0) {
                wp_set_current_user($userId);
                return true;
            }
        }

        $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
        if ($cookieUserId > 0) {
            wp_set_current_user($cookieUserId);
            return true;
        }

        return false;
    }
}
