<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Reminders\ReminderService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class RemindersController
{
    private ReminderService $service;

    public function __construct()
    {
        $this->service = new ReminderService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $pendingOnly = $request->get_param('pending_only') !== '0';

        return ApiResponse::success($this->service->listForCurrentUser($pendingOnly));
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || \AvinaCRM\Support\Scope::hasModulePermission('dashboard') || current_user_can('reminders.reminder.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || \AvinaCRM\Support\Scope::hasModulePermission('dashboard') || current_user_can('reminders.reminder.create');
    }

    public function dismiss(WP_REST_Request $request)
    {
        $result = $this->service->dismiss((int) $request->get_param('id'), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function dismissPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || \AvinaCRM\Support\Scope::hasModulePermission('dashboard') || current_user_can('reminders.reminder.dismiss');
    }
}
