<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Notifications\NotificationService;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class NotificationsController
{
    private NotificationService $service;

    public function __construct()
    {
        $this->service = new NotificationService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $unreadOnly = (bool) $request->get_param('unread_only');

        return ApiResponse::success([
            'items' => $this->service->listForCurrentUser($unreadOnly),
            'unread_count' => $this->service->unreadCount(),
        ]);
    }

    public function viewPermissionCheck(): bool
    {
        return current_user_can('notifications.notification.view');
    }

    public function markRead(WP_REST_Request $request): WP_REST_Response
    {
        $ok = $this->service->markRead((int) $request->get_param('id'), get_current_user_id());

        return $ok
            ? ApiResponse::success(['ok' => true])
            : ApiResponse::error('avina_crm_notification_not_found', __('اعلان موردنظر یافت نشد.', 'avina-crm'), 404);
    }

    public function markAllRead(WP_REST_Request $request): WP_REST_Response
    {
        $this->service->markAllRead(get_current_user_id());

        return ApiResponse::success(['ok' => true]);
    }

    public function markReadPermissionCheck(): bool
    {
        return current_user_can('notifications.notification.markread');
    }
}
