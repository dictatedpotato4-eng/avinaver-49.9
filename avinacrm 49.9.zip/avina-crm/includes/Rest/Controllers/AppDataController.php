<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class AppDataController
{
    public static function getFreshData(): array
    {
        try {
            if (function_exists('do_action')) {
                do_action('litespeed_control_set_nocache', 'avina CRM live data');
            }

            global $wpdb;
            $contactsTable = $wpdb->prefix . 'avina_contacts';
            $customersTable = $wpdb->prefix . 'avina_customers';

            // Load persistent deleted items registry to guarantee deleted contacts/tasks never resurrect
            $registry = get_option('avina_crm_deleted_ids_registry', []);
            $deletedSet = is_array($registry) && !empty($registry) ? array_flip(array_map('strval', $registry)) : [];

            $raw = get_option('avina_crm_app_data', []);
            $data = [];
            if (is_array($raw)) {
                $data = $raw;
            } elseif (is_string($raw) && !empty($raw)) {
                $dec = json_decode($raw, true);
                if (is_array($dec)) {
                    $data = $dec;
                }
            } elseif (is_object($raw)) {
                $dec = json_decode(json_encode($raw), true);
                if (is_array($dec)) {
                    $data = $dec;
                }
            }
            // Ensure pure associative arrays throughout the entire structure
            $data = json_decode((string) json_encode($data), true) ?: [];

            // Sync and merge contacts from MySQL table wp_avina_contacts
            try {
                self::syncContactsFromDb($data);
            } catch (\Throwable $e) {
                error_log('Avina CRM syncContactsFromDb notice: ' . $e->getMessage());
            }

            // Sync and merge customers from MySQL table wp_avina_customers
            try {
                self::syncCustomersFromDb($data);
            } catch (\Throwable $e) {
                error_log('Avina CRM syncCustomersFromDb notice: ' . $e->getMessage());
            }

            // Strictly filter out any registered deleted IDs from all collections before returning
            if (!empty($deletedSet)) {
                $cols = ['leads', 'contacts', 'customers', 'tasks', 'receptions', 'tickets', 'invoices', 'products', 'expenses', 'cheques'];
                foreach ($cols as $c) {
                    if (!empty($data[$c]) && is_array($data[$c])) {
                        $data[$c] = array_values(array_filter($data[$c], function($item) use ($deletedSet) {
                            $item = (array)$item;
                            $id = (string)($item['id'] ?? '');
                            return $id === '' || !isset($deletedSet[$id]);
                        }));
                    }
                }
            }

            // Ensure settings are populated with all saved Gemini keys and theme from WordPress options
            if (!isset($data['settings']) || !is_array($data['settings'])) {
                $data['settings'] = [];
            }
            $geminiMaster = get_option('avina_crm_gemini_api_key', '');
            $geminiDashboard = get_option('avina_crm_gemini_api_key_dashboard', '') ?: $geminiMaster;
            $geminiFloating = get_option('avina_crm_gemini_api_key_floating', '') ?: $geminiMaster;
            $geminiTraining = get_option('avina_crm_gemini_api_key_training', '') ?: $geminiMaster;
            $geminiSmsWriter = get_option('avina_crm_gemini_api_key_sms_writer', '') ?: $geminiMaster;
            $geminiModel = get_option('avina_crm_gemini_model', 'gemini-1.5-flash');
            $geminiProxy = get_option('avina_crm_ai_proxy', '');
            $defaultTheme = get_option('avina_crm_default_theme', 'light');

            if (!empty($geminiMaster)) {
                $data['settings']['gemini_api_key'] = $geminiMaster;
                $data['settings']['aiApiKey'] = $geminiMaster;
            }
            if (!empty($geminiDashboard)) {
                $data['settings']['gemini_api_key_dashboard'] = $geminiDashboard;
            }
            if (!empty($geminiFloating)) {
                $data['settings']['gemini_api_key_floating'] = $geminiFloating;
            }
            if (!empty($geminiTraining)) {
                $data['settings']['gemini_api_key_training'] = $geminiTraining;
            }
            if (!empty($geminiSmsWriter)) {
                $data['settings']['gemini_api_key_sms_writer'] = $geminiSmsWriter;
            }
            if (!empty($geminiModel)) {
                $data['settings']['gemini_model'] = $geminiModel;
            }
            if (!empty($geminiProxy)) {
                $data['settings']['gemini_proxy'] = $geminiProxy;
            }
            if (empty($data['settings']['theme'])) {
                $data['settings']['theme'] = $defaultTheme;
            }
            if (!isset($data['settings']['documentScannerSettings']) || !is_array($data['settings']['documentScannerSettings'])) {
                $data['settings']['documentScannerSettings'] = [];
            }
            if (!empty($geminiMaster)) {
                $data['settings']['documentScannerSettings']['apiKey'] = $geminiMaster;
                $data['settings']['documentScannerSettings']['model'] = $geminiModel;
            }

            return $data;
        } catch (\Throwable $e) {
            error_log('Avina CRM getFreshData fatal prevented: ' . $e->getMessage());
            return [
                'leads' => [],
                'contacts' => [],
                'customers' => [],
                'tasks' => [],
                'receptions' => [],
                'invoices' => [],
                'products' => [],
                'tickets' => [],
                'settings' => [
                    'theme' => get_option('avina_crm_default_theme', 'light'),
                    'appName' => get_option('avina_crm_app_name', 'آوینا CRM'),
                ]
            ];
        }
    }

    public function get(WP_REST_Request $request): WP_REST_Response
    {
        if (!headers_sent()) {
            nocache_headers();
            header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }
        $data = self::getFreshData();
        return ApiResponse::success($data);
    }

    public static function saveDataDirect(array $params): array
    {
        try {
            // Unpack { key: 'tasks', data: [...] } or { key: 'leads', data: [...] } or { key: 'settings', data: [...] }
            if (isset($params['key']) && isset($params['data']) && is_string($params['key'])) {
                $singleKey = sanitize_key($params['key']);
                $singleData = $params['data'];
                $delIds = isset($params['deleted_ids']) && is_array($params['deleted_ids']) ? $params['deleted_ids'] : [];
                $params = [$singleKey => $singleData];
                if (!empty($delIds)) {
                    $params['deleted_ids'] = $delIds;
                }
            }

            // Handle explicit deleted_ids
            $newDeletedIds = [];
            if (!empty($params['deleted_ids']) && is_array($params['deleted_ids'])) {
                $newDeletedIds = array_values(array_filter(array_map('strval', $params['deleted_ids'])));
                self::archiveDeletedItemsInDb($newDeletedIds);
            }

            // Fast-path: dedicated deletion request (Elementor-style instant purge)
            $isExplicitDelete = (!empty($params['action']) && $params['action'] === 'delete') || (!empty($newDeletedIds) && !isset($params['leads']) && !isset($params['tasks']) && !isset($params['settings']));
            if ($isExplicitDelete && !empty($newDeletedIds)) {
                self::purgeDeletedIdsFromAppData($newDeletedIds);
                return ['ok' => true, 'deleted' => $newDeletedIds];
            }

            // Direct database persistence for settings, Gemini API keys and appearance
            if (isset($params['settings']) && is_array($params['settings'])) {
                $s = $params['settings'];
                $masterKey = trim((string)($s['gemini_api_key'] ?? ($s['aiApiKey'] ?? '')));
                if (!empty($masterKey)) {
                    update_option('avina_crm_gemini_api_key', sanitize_text_field($masterKey));
                }
                if (!empty($s['gemini_api_key_dashboard'])) {
                    update_option('avina_crm_gemini_api_key_dashboard', sanitize_text_field(trim((string)$s['gemini_api_key_dashboard'])));
                }
                if (!empty($s['gemini_api_key_floating'])) {
                    update_option('avina_crm_gemini_api_key_floating', sanitize_text_field(trim((string)$s['gemini_api_key_floating'])));
                }
                if (!empty($s['gemini_api_key_training'])) {
                    update_option('avina_crm_gemini_api_key_training', sanitize_text_field(trim((string)$s['gemini_api_key_training'])));
                }
                if (!empty($s['gemini_api_key_sms_writer'])) {
                    update_option('avina_crm_gemini_api_key_sms_writer', sanitize_text_field(trim((string)$s['gemini_api_key_sms_writer'])));
                }
                if (!empty($s['documentScannerSettings']['apiKey'])) {
                    update_option('avina_crm_gemini_api_key', sanitize_text_field(trim((string)$s['documentScannerSettings']['apiKey'])));
                }
                if (!empty($s['sms']['geminiVoiceApiKey'])) {
                    update_option('avina_crm_gemini_voice_key', sanitize_text_field(trim((string)$s['sms']['geminiVoiceApiKey'])));
                }
                if (!empty($s['gemini_model'])) {
                    update_option('avina_crm_gemini_model', sanitize_text_field((string)$s['gemini_model']));
                }
                if (isset($s['gemini_proxy'])) {
                    update_option('avina_crm_ai_proxy', sanitize_text_field((string)$s['gemini_proxy']));
                }
                if (!empty($s['theme']) && in_array($s['theme'], ['light', 'dark', 'gold'], true)) {
                    update_option('avina_crm_default_theme', $s['theme']);
                    $uId = get_current_user_id();
                    if ($uId > 0) {
                        update_user_meta($uId, 'avina_crm_theme', $s['theme']);
                    }
                }
            }

            // Convert any large base64 image strings to physical files on disk to prevent database bloating
            self::convertBase64ImagesToUrls($params);

            $old_data = get_option('avina_crm_app_data', []);
            if (!is_array($old_data)) {
                $old_data = [];
            }

            $isAdmin = current_user_can('manage_options') || current_user_can('administrator') || \AvinaCRM\Support\Scope::isAdmin();

            // Resilient merging: NEVER overwrite or delete other operators' records or cross-device records
            self::mergeCollectionsSafely($old_data, $params, $newDeletedIds, $isAdmin);

            // Upsert all leads/contacts directly into MySQL table wp_avina_contacts
            if (isset($params['leads']) && is_array($params['leads'])) {
                self::upsertContactsToDb($params['leads'], $newDeletedIds, $isAdmin);
            } elseif (isset($params['contacts']) && is_array($params['contacts'])) {
                self::upsertContactsToDb($params['contacts'], $newDeletedIds, $isAdmin);
            }

            // Upsert all customers directly into MySQL table wp_avina_customers
            if (isset($params['customers']) && is_array($params['customers'])) {
                self::upsertCustomersToDb($params['customers'], $newDeletedIds, $isAdmin);
            }

            // Send notifications non-blockingly on shutdown so HTTP response is instant (<10ms)
            add_action('shutdown', function() use ($old_data, $params) {
                try {
                    self::detectAndNotifyNewItems($old_data, $params);
                } catch (\Throwable $e) {}
            });

            unset($params['deleted_ids']);

            // Purge explicitly deleted IDs from params before updating option
            if (!empty($newDeletedIds)) {
                $deletedSet = array_flip($newDeletedIds);
                $collections = ['leads', 'customers', 'receptions', 'tasks', 'tickets', 'contacts', 'invoices', 'products', 'expenses', 'cheques'];
                foreach ($collections as $col) {
                    if (!empty($params[$col]) && is_array($params[$col])) {
                        $params[$col] = array_values(array_filter($params[$col], function($item) use ($deletedSet) {
                            $item = (array)$item;
                            $id = (string)($item['id'] ?? '');
                            return !isset($deletedSet[$id]);
                        }));
                    }
                }
            }

            update_option('avina_crm_app_data', $params, 'no');
            if (function_exists('do_action')) {
                do_action('litespeed_purge_all');
            }
            if (function_exists('wp_cache_flush')) {
                @wp_cache_flush();
            }
            return ['ok' => true];
        } catch (\Throwable $e) {
            error_log('Avina CRM saveDataDirect error: ' . $e->getMessage());
            return ['ok' => true, 'warning' => $e->getMessage()];
        }
    }

    public function save(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        if (!is_array($params)) {
            $params = [];
        }
        $result = self::saveDataDirect($params);
        return ApiResponse::success($result);
    }

    public static function handleAjaxSave(): void
    {
        $userId = get_current_user_id();
        $token = (string)($_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['crm_token'] ?? ($_REQUEST['avina_token'] ?? '')));
        if ($userId <= 0 && !empty($token)) {
            $tokenUserId = \AvinaCRM\Support\TokenService::validateToken($token);
            if ($tokenUserId > 0) {
                wp_set_current_user($tokenUserId);
                $userId = $tokenUserId;
            }
        }
        if ($userId <= 0) {
            $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
            if ($cookieUserId > 0) {
                wp_set_current_user($cookieUserId);
                $userId = $cookieUserId;
            }
        }

        if ($userId <= 0 && !current_user_can('read')) {
            wp_send_json_error(['message' => 'Unauthorized'], 401);
            return;
        }

        $rawPayload = $_POST['payload'] ?? '';
        $params = [];
        if (is_string($rawPayload) && !empty($rawPayload)) {
            $decoded = json_decode(wp_unslash($rawPayload), true);
            if (is_array($decoded)) {
                $params = $decoded;
            }
        } elseif (is_array($rawPayload)) {
            $params = $rawPayload;
        }

        $res = self::saveDataDirect($params);
        wp_send_json_success($res);
    }

    public static function handleAjaxGet(): void
    {
        $userId = get_current_user_id();
        $token = (string)($_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['crm_token'] ?? ($_REQUEST['avina_token'] ?? '')));
        if ($userId <= 0 && !empty($token)) {
            $tokenUserId = \AvinaCRM\Support\TokenService::validateToken($token);
            if ($tokenUserId > 0) {
                wp_set_current_user($tokenUserId);
                $userId = $tokenUserId;
            }
        }
        if ($userId <= 0) {
            $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
            if ($cookieUserId > 0) {
                wp_set_current_user($cookieUserId);
                $userId = $cookieUserId;
            }
        }

        if ($userId <= 0 && !current_user_can('read')) {
            wp_send_json_error(['message' => 'Unauthorized'], 401);
            return;
        }

        if (!headers_sent()) {
            nocache_headers();
            header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }

        $data = self::getFreshData();
        wp_send_json_success($data);
    }

    private static function convertBase64ImagesToUrls(array &$data): void
    {
        $upload_dir = wp_upload_dir();
        $target_dir = $upload_dir['basedir'] . '/avina-crm-docs';
        $target_url = $upload_dir['baseurl'] . '/avina-crm-docs';

        if (!file_exists($target_dir)) {
            wp_mkdir_p($target_dir);
        }

        array_walk_recursive($data, function (&$value) use ($target_dir, $target_url) {
            if (is_string($value) && strpos($value, 'data:image/') === 0 && strpos($value, ';base64,') !== false) {
                $parts = explode(';base64,', $value);
                $mime = str_replace('data:image/', '', $parts[0]);
                $ext = (strpos($mime, 'png') !== false) ? 'png' : 'jpg';
                $decoded = base64_decode($parts[1]);
                if ($decoded !== false && strlen($decoded) > 0) {
                    $filename = 'doc_' . time() . '_' . wp_generate_password(6, false) . '.' . $ext;
                    $filepath = $target_dir . '/' . $filename;
                    if (@file_put_contents($filepath, $decoded) !== false) {
                        $value = $target_url . '/' . $filename;
                    }
                }
            }
        });
    }

    private static function detectAndNotifyNewItems(array $oldData, array $newData): void
    {
        $admin_email = get_option('admin_email');
        if (empty($admin_email)) {
            return;
        }

        // Helper to check if a new item is added by comparing IDs
        $find_new = function(string $key, array $oldItems, array $newItems) use ($admin_email) {
            $old_ids = [];
            foreach ($oldItems as $oi) {
                if (is_object($oi)) $oi = (array)$oi;
                if (is_array($oi) && isset($oi['id'])) {
                    $old_ids[] = (string)$oi['id'];
                }
            }
            foreach ($newItems as $item) {
                if (is_object($item)) $item = (array)$item;
                if (!is_array($item) || !isset($item['id'])) {
                    continue;
                }
                if (!in_array((string)$item['id'], $old_ids, true)) {
                    self::sendNewItemNotificationEmail($admin_email, $key, $item);
                }
            }
        };

        $old_contacts = is_array($oldData['contacts'] ?? null) ? $oldData['contacts'] : [];
        $new_contacts = is_array($newData['contacts'] ?? null) ? $newData['contacts'] : [];
        $find_new('contact', $old_contacts, $new_contacts);

        $old_customers = is_array($oldData['customers'] ?? null) ? $oldData['customers'] : [];
        $new_customers = is_array($newData['customers'] ?? null) ? $newData['customers'] : [];
        $find_new('customer', $old_customers, $new_customers);

        $old_receptions = is_array($oldData['receptions'] ?? null) ? $oldData['receptions'] : [];
        $new_receptions = is_array($newData['receptions'] ?? null) ? $newData['receptions'] : [];
        $find_new('reception', $old_receptions, $new_receptions);

        $old_leads = is_array($oldData['leads'] ?? null) ? $oldData['leads'] : [];
        $new_leads = is_array($newData['leads'] ?? null) ? $newData['leads'] : [];
        $find_new('lead', $old_leads, $new_leads);

        // Task completion detection
        $old_tasks = is_array($oldData['tasks'] ?? null) ? $oldData['tasks'] : [];
        $new_tasks = is_array($newData['tasks'] ?? null) ? $newData['tasks'] : [];
        
        $old_tasks_by_id = [];
        foreach ($old_tasks as $t) {
            if (is_object($t)) $t = (array)$t;
            if (is_array($t) && isset($t['id'])) {
                $old_tasks_by_id[$t['id']] = $t;
            }
        }
        
        foreach ($new_tasks as $task) {
            if (is_object($task)) $task = (array)$task;
            if (!is_array($task) || !isset($task['id'])) {
                continue;
            }
            $old_task = $old_tasks_by_id[$task['id']] ?? null;
            if ($old_task) {
                $old_status = $old_task['statusId'] ?? '';
                $new_status = $task['statusId'] ?? '';
                
                $is_old_completed = ($old_status === 'col-3' || $old_status === 'col-4');
                $is_new_completed = ($new_status === 'col-3' || $new_status === 'col-4');
                
                if ($is_new_completed && !$is_old_completed) {
                    self::sendTaskCompletedNotificationEmail($admin_email, $task);
                }
            }
        }
    }

    private static function sendNewItemNotificationEmail(string $toEmail, string $type, array $item): void
    {
        $subject = '';
        $title = '';
        $details_html = '';

        if ($type === 'contact' || $type === 'lead') {
            $subject = '🔔 ثبت مخاطب جدید در سیستم آوینا CRM';
            $title = 'یک مخاطب جدید ثبت گردید';
            $name = $item['name'] ?? 'نامشخص';
            $phone = $item['phone'] ?? 'نامشخص';
            $email = $item['email'] ?? 'نامشخص';
            $source = $item['source'] ?? 'نامشخص';
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نام مخاطب:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$phone}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>ایمیل:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$email}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>منبع:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$source}</td></tr>
            ";
        } elseif ($type === 'customer') {
            $subject = '🔔 ثبت مشتری جدید در سیستم آوینا CRM';
            $title = 'یک مشتری جدید ثبت گردید';
            $name = $item['name'] ?? 'نامشخص';
            $phone = $item['phone'] ?? 'نامشخص';
            $national_id = $item['nationalCode'] ?? ($item['nationalId'] ?? 'نامشخص');
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نام مشتری:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$phone}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>کد ملی:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$national_id}</td></tr>
            ";
        } elseif ($type === 'reception') {
            $subject = '🔔 ثبت پذیرش جدید دستگاه در سیستم آوینا CRM';
            $title = 'یک پذیرش جدید دستگاه ثبت گردید';
            $customer_name = $item['customerName'] ?? ($item['name'] ?? 'نامشخص');
            $device_model = $item['deviceModel'] ?? ($item['model'] ?? 'نامشخص');
            $request = $item['requestType'] ?? ($item['request'] ?? 'نامشخص');
            $phone = $item['phone'] ?? 'نامشخص';
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>سفارش دهنده / مالک:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$customer_name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>دستگاه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$device_model}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نوع درخواست:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$request}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$phone}</td></tr>
            ";
        } elseif ($type === 'submission') {
            $subject = '📋 ثبت درخواست استخدام جدید در آوینا CRM';
            $title = 'یک درخواست استخدام جدید ثبت گردید';
            $name = $item['name'] ?? 'نامشخص';
            $position = $item['position'] ?? 'نامشخص';
            $mobile = $item['mobile'] ?? 'نامشخص';
            $resume = $item['resumeUrl'] ?? '#';
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نام و نام خانوادگی متقاضی:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>عنوان شغلی درخواستی:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$position}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$mobile}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>فایل رزومه / پیوست:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><a href='{$resume}' target='_blank' style='color: #4f46e5; font-weight: bold;'>مشاهده رزومه</a></td></tr>
            ";
        } else {
            return;
        }

        // Send to manager email m.fulafi@yahoo.com as primary target + admin_email
        $recipients = array_filter(array_unique([$toEmail, 'm.fulafi@yahoo.com']));
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Avina CRM <no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '>'
        ];

        // Beautiful RTL HTML Email template
        $body = "
        <div style='direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif; padding: 20px; background-color: #f6f9fc;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; border: 1px solid #e1e8ed;'>
                <div style='background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: #ffffff; padding: 24px; text-align: center;'>
                    <h2 style='margin: 0; font-size: 20px; font-weight: bold;'>سیستم هوشمند آوینا CRM</h2>
                    <p style='margin: 5px 0 0 0; font-size: 13px; opacity: 0.9;'>گزارش خودکار ثبت اطلاعات</p>
                </div>
                <div style='padding: 24px; color: #333333;'>
                    <h3 style='margin-top: 0; color: #4f46e5; font-size: 16px; border-bottom: 2px solid #f0f4f8; padding-bottom: 10px;'>{$title}</h3>
                    <table style='width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px;'>
                        {$details_html}
                    </table>
                    <div style='margin-top: 25px; padding: 15px; background-color: #f8fafc; border-right: 4px solid #6366f1; border-radius: 4px; font-size: 12px; color: #555555;'>
                        این ایمیل به صورت خودکار جهت اطلاع‌رسانی به مدیریت کل سیستم ارسال شده است. برای مشاهده جزئیات بیشتر به پیشخوان مدیریت آوینا CRM مراجعه کنید.
                    </div>
                </div>
                <div style='background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 11px; color: #64748b;'>
                    طراحی شده توسط دستیار هوشمند آوینا
                </div>
            </div>
        </div>
        ";

        foreach ($recipients as $recipient) {
            try {
                @wp_mail($recipient, $subject, $body, $headers);
            } catch (\Throwable $e) {}
        }
    }

    private static function sendTaskCompletedNotificationEmail(string $toEmail, array $task): void
    {
        $subject = '✅ تکمیل وظیفه ارجاع شده در آوینا CRM';
        $title = 'یک وظیفه ارجاع شده به وضعیت تکمیل‌ شده تغییر یافت';
        
        $customer_name = $task['customerName'] ?? 'نامشخص';
        $project = $task['project'] ?? 'نامشخص';
        $notes = $task['notes'] ?? 'توضیحی ثبت نشده است.';
        
        $details_html = "
            <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>عنوان کار / پروژه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$project}</td></tr>
            <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>مشتری مربوطه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$customer_name}</td></tr>
            <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>توضیحات / یادداشت:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$notes}</td></tr>
        ";

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Avina CRM <no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '>'
        ];

        $body = "
        <div style='direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif; padding: 20px; background-color: #f6f9fc;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; border: 1px solid #e1e8ed;'>
                <div style='background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #ffffff; padding: 24px; text-align: center;'>
                    <h2 style='margin: 0; font-size: 20px; font-weight: bold;'>سیستم هوشمند آوینا CRM</h2>
                    <p style='margin: 5px 0 0 0; font-size: 13px; opacity: 0.9;'>اطلاع‌رسانی اتمام وظیفه</p>
                </div>
                <div style='padding: 24px; color: #333333;'>
                    <h3 style='margin-top: 0; color: #059669; font-size: 16px; border-bottom: 2px solid #f0f4f8; padding-bottom: 10px;'>{$title}</h3>
                    <table style='width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px;'>
                        {$details_html}
                    </table>
                    <div style='margin-top: 25px; padding: 15px; background-color: #f8fafc; border-right: 4px solid #10b981; border-radius: 4px; font-size: 12px; color: #555555;'>
                        این کار توسط اپراتور به وضعیت نهایی تحویل/تسویه منتقل شده است. جهت بررسی گزارشات کامل به پنل مدیریت آوینا CRM مراجعه نمایید.
                    </div>
                </div>
                <div style='background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 11px; color: #64748b;'>
                    طراحی شده توسط دستیار هوشمند آوینا
                </div>
            </div>
        </div>
        ";

        try {
            @wp_mail($toEmail, $subject, $body, $headers);
        } catch (\Throwable $e) {}
    }

    public static function archiveDeletedItemsInDb(array $deletedIds): void
    {
        if (empty($deletedIds)) return;
        global $wpdb;
        $contactsTable = $wpdb->prefix . 'avina_contacts';
        $customersTable = $wpdb->prefix . 'avina_customers';
        $receptionsTable = $wpdb->prefix . 'avina_device_intakes';
        $tasksTable = $wpdb->prefix . 'avina_tasks';

        $cleanDeletedStrings = [];

        foreach ($deletedIds as $delId) {
            $strId = trim((string)$delId);
            if ($strId === '') continue;
            $cleanDeletedStrings[] = $strId;

            // Extract numeric ID if present
            $num = 0;
            if (is_numeric($strId)) {
                $num = (int)$strId;
            } else {
                $digits = preg_replace('/\D+/', '', $strId);
                if (is_numeric($digits) && (int)$digits > 0) {
                    $num = (int)$digits;
                }
            }

            if ($num > 0 && $num < 2147483647) {
                // Permanently delete from MySQL tables
                $wpdb->delete($contactsTable, ['id' => $num]);
                $wpdb->update($contactsTable, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $num]);

                $wpdb->delete($customersTable, ['id' => $num]);
                $wpdb->update($customersTable, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $num]);

                $wpdb->delete($tasksTable, ['id' => $num]);
                $wpdb->update($tasksTable, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $num]);

                $wpdb->delete($receptionsTable, ['id' => $num]);
                $wpdb->delete($wpdb->prefix . 'avina_contact_followups', ['contact_id' => $num]);
            }
        }

        // Store into persistent deleted registry option to prevent any device from resurrecting
        if (!empty($cleanDeletedStrings)) {
            $registry = get_option('avina_crm_deleted_ids_registry', []);
            if (!is_array($registry)) $registry = [];
            $registry = array_unique(array_merge($registry, $cleanDeletedStrings));
            if (count($registry) > 50000) {
                $registry = array_slice($registry, -50000);
            }
            update_option('avina_crm_deleted_ids_registry', $registry, 'no');
        }
    }

    public static function purgeDeletedIdsFromAppData(array $deletedIds): void
    {
        if (empty($deletedIds)) return;
        $deletedSet = array_flip(array_map('strval', $deletedIds));
        $old_data = get_option('avina_crm_app_data', []);
        if (is_array($old_data) && !empty($old_data)) {
            $collections = ['leads', 'customers', 'receptions', 'tasks', 'tickets', 'contacts', 'invoices', 'products', 'expenses', 'cheques'];
            foreach ($collections as $col) {
                if (!empty($old_data[$col]) && is_array($old_data[$col])) {
                    $old_data[$col] = array_values(array_filter($old_data[$col], function($item) use ($deletedSet) {
                        $item = (array)$item;
                        $id = (string)($item['id'] ?? '');
                        return !isset($deletedSet[$id]);
                    }));
                }
            }
            update_option('avina_crm_app_data', $old_data, 'no');
        }
        if (function_exists('do_action')) {
            do_action('litespeed_purge_all');
        }
        if (function_exists('wp_cache_flush')) {
            @wp_cache_flush();
        }
    }

    private static function syncContactsFromDb(array &$data): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';
        
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) {
            return;
        }

        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE is_archived = 0 ORDER BY id DESC LIMIT 50000", ARRAY_A);
        if (empty($rows) || !is_array($rows)) {
            return;
        }

        $existingLeads = is_array($data['leads'] ?? null) ? $data['leads'] : [];
        $leadMap = [];
        $phoneMap = [];

        foreach ($existingLeads as $lead) {
            if (is_object($lead)) {
                $lead = (array)$lead;
            }
            if (!is_array($lead)) {
                continue;
            }
            $idKey = (string)($lead['id'] ?? '');
            if ($idKey !== '') {
                $leadMap[$idKey] = $lead;
            }
            $cleanPhone = self::normalizePhone((string)($lead['mobile'] ?? ''));
            if ($cleanPhone !== '' && $idKey !== '') {
                $phoneMap[$cleanPhone] = $idKey;
            }
        }

        $registry = get_option('avina_crm_deleted_ids_registry', []);
        $delSet = is_array($registry) ? array_flip(array_map('strval', $registry)) : [];

        foreach ($rows as $row) {
            if (is_object($row)) {
                $row = (array)$row;
            }
            if (!is_array($row)) {
                continue;
            }
            $dbId = (string)($row['id'] ?? '');
            if ($dbId === '' || isset($delSet[$dbId]) || isset($delSet['lead-' . $dbId]) || isset($delSet['contact-' . $dbId])) {
                continue;
            }
            $cleanPhone = self::normalizePhone((string)($row['phone'] ?? ''));
            
            $matchedKey = null;
            if (isset($leadMap[$dbId])) {
                $matchedKey = $dbId;
            } elseif ($cleanPhone !== '' && isset($phoneMap[$cleanPhone])) {
                $matchedKey = $phoneMap[$cleanPhone];
            }

            $reqs = !empty($row['product_or_service']) ? array_map('trim', explode(',', (string)$row['product_or_service'])) : [];
            $history = [];
            if (!empty($row['last_call_result'])) {
                $history[] = [
                    'id' => 'fu-db-' . $dbId,
                    'date' => ($row['updated_at'] ?? '') ?: (($row['created_at'] ?? '') ?: current_time('mysql')),
                    'notes' => (string)$row['last_call_result'],
                    'title' => 'نتیجه آخرین تماس / پیگیری'
                ];
            }

            $creatorUserId = (int)(($row['created_by_user_id'] ?? 0) ?: (($row['owner_user_id'] ?? 0) ?: 0));
            $creatorUser = $creatorUserId > 0 ? (string)$creatorUserId : 'admin';
            $operatorUser = $creatorUserId > 0 ? get_userdata($creatorUserId) : null;
            $operatorUsername = $operatorUser ? $operatorUser->user_login : '';
            $operatorName = $operatorUser ? ($operatorUser->display_name ?: $operatorUser->user_login) : '';

            $dbLead = [
                'id' => $dbId,
                'name' => (string)($row['full_name'] ?? ''),
                'mobile' => (string)($row['phone'] ?? ''),
                'job' => (string)($row['job'] ?? ''),
                'purpose' => !empty($row['requirement_type']) ? (string)$row['requirement_type'] : 'purchase',
                'requests' => $reqs,
                'status' => (($row['lifecycle_stage'] ?? '') === 'customer') ? 'completed' : ((($row['lifecycle_stage'] ?? '') === 'cancelled') ? 'canceled' : 'follow-up'),
                'followUpDate' => (string)($row['followup_date'] ?? ''),
                'cancellationReason' => '',
                'mood' => 'neutral',
                'purchaseProbability' => (int)($row['buying_probability'] ?? 3),
                'history' => $history,
                'createdBy' => $creatorUser,
                'createdById' => $creatorUser,
                'owner_user_id' => $creatorUser,
                'operatorId' => $creatorUser,
                'operatorUsername' => $operatorUsername,
                'operatorName' => $operatorName,
                'isCompleted' => (($row['lifecycle_stage'] ?? '') === 'customer'),
                'createdAt' => ($row['created_at'] ?? '') ?: current_time('mysql'),
            ];

            if ($matchedKey !== null) {
                $existingLocal = (array)$leadMap[$matchedKey];
                $merged = array_merge($dbLead, $existingLocal);
                $merged['id'] = $dbId;
                // Preserve complete entered name - NEVER overwrite or truncate entered name!
                $enteredName = trim((string)($existingLocal['name'] ?? ''));
                $merged['name'] = $enteredName !== '' ? $enteredName : (string)($row['full_name'] ?? '');
                $merged['mobile'] = (string)($row['phone'] ?? '');
                
                // PRESERVE original operator creator/attribution so it is never stripped or reset to 'admin'
                $originalCreator = (string)($existingLocal['createdBy'] ?? ($existingLocal['createdById'] ?? ($existingLocal['owner_user_id'] ?? '')));
                if (!empty($originalCreator) && $originalCreator !== 'admin') {
                    $merged['createdBy'] = $originalCreator;
                    $merged['createdById'] = $originalCreator;
                    $merged['owner_user_id'] = $originalCreator;
                } elseif (empty($merged['createdBy'])) {
                    $merged['createdBy'] = $creatorUser;
                }
                
                // Preserve operator tags
                if (!empty($existingLocal['operatorId'])) {
                    $merged['operatorId'] = $existingLocal['operatorId'];
                }
                if (!empty($existingLocal['operatorName'])) {
                    $merged['operatorName'] = $existingLocal['operatorName'];
                }

                if ($matchedKey !== $dbId) {
                    unset($leadMap[$matchedKey]);
                }
                $leadMap[$dbId] = $merged;
            } else {
                $leadMap[$dbId] = $dbLead;
                if ($cleanPhone !== '') {
                    $phoneMap[$cleanPhone] = $dbId;
                }
            }
        }

        $data['leads'] = array_values($leadMap);
        $data['contacts'] = array_values($leadMap);
    }

    private static function syncCustomersFromDb(array &$data): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';
        
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) {
            return;
        }

        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE is_archived = 0 ORDER BY id DESC LIMIT 50000", ARRAY_A);
        if (empty($rows) || !is_array($rows)) {
            return;
        }

        $existingCusts = is_array($data['customers'] ?? null) ? $data['customers'] : [];
        $custMap = [];
        $phoneMap = [];

        foreach ($existingCusts as $c) {
            if (is_object($c)) {
                $c = (array)$c;
            }
            if (!is_array($c)) {
                continue;
            }
            $idKey = (string)($c['id'] ?? '');
            if ($idKey !== '') {
                $custMap[$idKey] = $c;
            }
            $cleanPhone = self::normalizePhone((string)($c['mobile'] ?? ($c['phone'] ?? '')));
            if ($cleanPhone !== '' && $idKey !== '') {
                $phoneMap[$cleanPhone] = $idKey;
            }
        }

        $registry = get_option('avina_crm_deleted_ids_registry', []);
        $delSet = is_array($registry) ? array_flip(array_map('strval', $registry)) : [];

        foreach ($rows as $row) {
            if (is_object($row)) {
                $row = (array)$row;
            }
            if (!is_array($row)) {
                continue;
            }
            $dbId = (string)($row['id'] ?? '');
            if ($dbId === '' || isset($delSet[$dbId]) || isset($delSet['cust-' . $dbId])) {
                continue;
            }
            $cleanPhone = self::normalizePhone((string)($row['phone'] ?? ''));
            
            $matchedKey = null;
            if (isset($custMap[$dbId])) {
                $matchedKey = $dbId;
            } elseif ($cleanPhone !== '' && isset($phoneMap[$cleanPhone])) {
                $matchedKey = $phoneMap[$cleanPhone];
            }

            $extra = [];
            if (!empty($row['custom_fields'])) {
                $decoded = json_decode((string)$row['custom_fields'], true);
                if (is_array($decoded)) {
                    $extra = $decoded;
                }
            }

            $isBlocked = !empty($extra['isBlocked']) || (($row['status'] ?? '') === 'blocked');
            $blockReason = (string)($extra['blockReason'] ?? '');

            $custCreatorId = (int)(($row['created_by_user_id'] ?? 0) ?: (($row['owner_user_id'] ?? 0) ?: 0));
            $custCreator = $custCreatorId > 0 ? (string)$custCreatorId : (string)($extra['createdBy'] ?? 'admin');
            $custOpUser = $custCreatorId > 0 ? get_userdata($custCreatorId) : null;
            $custOpUsername = $custOpUser ? $custOpUser->user_login : '';
            $custOpName = $custOpUser ? ($custOpUser->display_name ?: $custOpUser->user_login) : '';

            $dbCust = [
                'id' => $dbId,
                'name' => (string)($row['full_name'] ?? ''),
                'mobile' => (string)($row['phone'] ?? ''),
                'email' => (string)($row['email'] ?? ''),
                'nationalId' => (string)($extra['nationalId'] ?? ''),
                'nationalCode' => (string)($extra['nationalId'] ?? ''),
                'company' => (string)($extra['company'] ?? ''),
                'notes' => (string)($row['notes'] ?: ($extra['notes'] ?? '')),
                'status' => (string)($row['status'] ?: ($isBlocked ? 'blocked' : 'active')),
                'isBlocked' => $isBlocked,
                'blockReason' => $blockReason,
                'blockedBy' => (string)($extra['blockedBy'] ?? ''),
                'blockedByName' => (string)($extra['blockedByName'] ?? ''),
                'blockedAt' => (string)($extra['blockedAt'] ?? ''),
                'isCancelled' => !empty($extra['isCancelled']),
                'cancellationReason' => (string)($extra['cancellationReason'] ?? ''),
                'documentUrl' => (string)($extra['documentUrl'] ?? ''),
                'createdBy' => $custCreator,
                'createdById' => $custCreator,
                'owner_user_id' => $custCreator,
                'operatorId' => $custCreator,
                'operatorUsername' => $custOpUsername,
                'operatorName' => $custOpName,
                'lastContact' => ($row['created_at'] ?? '') ?: current_time('mysql'),
                'updatedAt' => (string)($extra['updatedAt'] ?? (($row['updated_at'] ?? '') ?: current_time('mysql'))),
            ];

            if ($matchedKey !== null) {
                $existingLocal = (array)$custMap[$matchedKey];
                $merged = array_merge($dbCust, $existingLocal);
                $merged['id'] = $dbId;
                if (!empty($existingLocal['isBlocked']) || $isBlocked) {
                    if (isset($existingLocal['isBlocked']) && $existingLocal['isBlocked'] === false) {
                        $merged['isBlocked'] = false;
                        $merged['status'] = 'active';
                        $merged['blockReason'] = '';
                    } else {
                        $merged['isBlocked'] = true;
                        $merged['status'] = 'blocked';
                        $merged['blockReason'] = !empty($existingLocal['blockReason']) ? $existingLocal['blockReason'] : $blockReason;
                    }
                }
                $enteredName = trim((string)($existingLocal['name'] ?? ''));
                $merged['name'] = $enteredName !== '' ? $enteredName : (string)($row['full_name'] ?? '');
                $merged['mobile'] = (string)($row['phone'] ?? '');

                $originalCreator = (string)($existingLocal['createdBy'] ?? ($existingLocal['createdById'] ?? ($existingLocal['owner_user_id'] ?? '')));
                if (!empty($originalCreator) && $originalCreator !== 'admin') {
                    $merged['createdBy'] = $originalCreator;
                    $merged['createdById'] = $originalCreator;
                    $merged['owner_user_id'] = $originalCreator;
                } elseif (empty($merged['createdBy'])) {
                    $merged['createdBy'] = $custCreator;
                }

                if (!empty($existingLocal['operatorId'])) {
                    $merged['operatorId'] = $existingLocal['operatorId'];
                }
                if (!empty($existingLocal['operatorName'])) {
                    $merged['operatorName'] = $existingLocal['operatorName'];
                }

                if ($matchedKey !== $dbId) {
                    unset($custMap[$matchedKey]);
                }
                $custMap[$dbId] = $merged;
            } else {
                $custMap[$dbId] = $dbCust;
                if ($cleanPhone !== '') {
                    $phoneMap[$cleanPhone] = $dbId;
                }
            }
        }

        $data['customers'] = array_values($custMap);
    }

    private static function normalizePhone(string $phone): string
    {
        $english = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim($phone));
        return (string) preg_replace('/\D+/', '', $english);
    }

    private static function mergeCollectionsSafely(array $oldData, array &$newData, array $deletedIds = [], bool $isAdmin = false): void
    {
        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];
        $registry = get_option('avina_crm_deleted_ids_registry', []);
        if (is_array($registry) && !empty($registry)) {
            $deletedSet = array_merge($deletedSet, array_flip(array_map('strval', $registry)));
        }
        $collectionsToMerge = [
            'leads', 'customers', 'contacts', 'receptions', 'tasks', 'invoices', 'products', 'tickets',
            'cheques', 'expenses', 'manualVouchers', 'chartOfAccounts', 'boms', 'fiscalYears', 'numberSourceList',
            'conversionRequests', 'avinaTrainingData'
        ];

        // Preserve any top-level key from oldData that was not passed in newData
        foreach ($oldData as $key => $val) {
            if (!isset($newData[$key]) && $key !== 'deleted_ids') {
                $newData[$key] = $val;
            }
        }

        $currentUserId = get_current_user_id();

        foreach ($collectionsToMerge as $key) {
            if (!isset($newData[$key])) {
                continue;
            }

            $oldItems = is_array($oldData[$key] ?? null) ? $oldData[$key] : [];
            $newItems = is_array($newData[$key] ?? null) ? $newData[$key] : [];

            // Build map of new items, filtering out deleted ones
            $itemMap = [];
            $phoneMap = [];
            foreach ($newItems as $item) {
                if (is_object($item)) {
                    $item = (array)$item;
                }
                if (!is_array($item)) continue;
                $idKey = (string)($item['id'] ?? '');
                if ($idKey !== '' && !isset($deletedSet[$idKey])) {
                    $itemMap[$idKey] = $item;
                }
                $cleanPhone = self::normalizePhone((string)($item['mobile'] ?? ($item['phone'] ?? ($item['customerMobile'] ?? ''))));
                if ($cleanPhone !== '' && $idKey !== '' && !isset($deletedSet[$idKey])) {
                    $phoneMap[$cleanPhone] = $idKey;
                }
            }

            // Resilient merge: preserve existing items from $oldItems that are not in incoming payload,
            // unless they are explicitly in $deletedSet. This guarantees cross-system / multi-device data integrity!
            foreach ($oldItems as $oldItem) {
                if (is_object($oldItem)) {
                    $oldItem = (array)$oldItem;
                }
                if (!is_array($oldItem)) continue;
                $idKey = (string)($oldItem['id'] ?? '');
                if ($idKey !== '' && isset($deletedSet[$idKey])) {
                    continue; // Intentionally deleted
                }
                $cleanPhone = self::normalizePhone((string)($oldItem['mobile'] ?? ($oldItem['phone'] ?? ($oldItem['customerMobile'] ?? ''))));
                $exists = ($idKey !== '' && isset($itemMap[$idKey])) || ($cleanPhone !== '' && isset($phoneMap[$cleanPhone]));
                if (!$exists && $idKey !== '') {
                    $itemMap[$idKey] = $oldItem;
                    if ($cleanPhone !== '') {
                        $phoneMap[$cleanPhone] = $idKey;
                    }
                }
            }
            $newData[$key] = array_values($itemMap);
        }
    }

    private static function upsertContactsToDb(array $leads, array $deletedIds = [], bool $isAdmin = false): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) return;

        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];
        $activePhones = [];
        $activeIds = [];

        foreach ($leads as $lead) {
            if (is_object($lead)) {
                $lead = (array)$lead;
            }
            if (!is_array($lead) || empty($lead['name']) || empty($lead['mobile'])) {
                continue;
            }

            $leadIdStr = (string)($lead['id'] ?? '');
            if ($leadIdStr !== '' && isset($deletedSet[$leadIdStr])) {
                continue;
            }

            $rawMobile = (string)$lead['mobile'];
            $phone = sanitize_text_field(\AvinaCRM\Operators\OperatorService::toEnglishDigits($rawMobile));
            $fullName = sanitize_text_field((string)$lead['name']);
            $cleanPhone = self::normalizePhone($phone);
            if ($cleanPhone !== '') $activePhones[$cleanPhone] = true;
            if (is_numeric($leadIdStr) && (int)$leadIdStr > 0) $activeIds[(int)$leadIdStr] = true;

            $job = sanitize_text_field((string)($lead['job'] ?? ''));
            $reqType = sanitize_key((string)($lead['purpose'] ?? 'purchase'));
            $reqs = is_array($lead['requests'] ?? null) ? implode(', ', $lead['requests']) : sanitize_text_field((string)($lead['requests'] ?? ''));
            $buyingProb = (int)($lead['purchaseProbability'] ?? 3);
            $followupDate = !empty($lead['followUpDate']) ? sanitize_text_field((string)$lead['followUpDate']) : null;
            
            // Extract numeric creator ID intelligently
            $rawCreator = (string)($lead['createdById'] ?? ($lead['createdBy'] ?? ($lead['owner_user_id'] ?? ($lead['operatorId'] ?? ''))));
            $creatorId = 0;
            if (!empty($rawCreator) && $rawCreator !== 'admin') {
                $u = get_user_by('login', $rawCreator);
                if (!$u) $u = get_user_by('email', $rawCreator);
                if ($u) {
                    $creatorId = (int)$u->ID;
                } elseif (is_numeric($rawCreator) && (int)$rawCreator > 0) {
                    $checkUser = get_userdata((int)$rawCreator);
                    if ($checkUser) {
                        $creatorId = (int)$rawCreator;
                    }
                }
            }
            if ($creatorId <= 0) {
                $currentWpUid = get_current_user_id();
                if ($currentWpUid > 0) {
                    $creatorId = $currentWpUid;
                }
            }
            $stage = ($lead['status'] ?? '') === 'completed' ? 'customer' : (($lead['status'] ?? '') === 'canceled' ? 'cancelled' : 'lead');

            $lastCallResult = '';
            if (!empty($lead['history']) && is_array($lead['history'])) {
                $lastNote = end($lead['history']);
                if (is_array($lastNote) && !empty($lastNote['notes'])) {
                    $lastCallResult = sanitize_textarea_field((string)$lastNote['notes']);
                }
            }

            $existingId = 0;
            if (!empty($lead['id']) && is_numeric($lead['id'])) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE id = %d", (int)$lead['id']));
            }
            if ($existingId === 0 && !empty($phone)) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE phone = %s OR phone = %s LIMIT 1", $phone, $cleanPhone));
            }

            $data = [
                'full_name' => $fullName,
                'phone' => $phone,
                'lifecycle_stage' => $stage,
                'job' => $job,
                'requirement_type' => $reqType,
                'product_or_service' => $reqs,
                'buying_probability' => $buyingProb,
                'followup_date' => $followupDate,
                'last_call_result' => $lastCallResult,
                'is_archived' => 0,
                'updated_at' => current_time('mysql'),
            ];

            if ($existingId > 0) {
                $existingRow = $wpdb->get_row($wpdb->prepare("SELECT created_by_user_id, owner_user_id FROM {$table} WHERE id = %d", $existingId), ARRAY_A);
                if ($existingRow && (empty($existingRow['created_by_user_id']) || (int)$existingRow['created_by_user_id'] === 0) && $creatorId > 0) {
                    $data['created_by_user_id'] = $creatorId;
                    $data['owner_user_id'] = $creatorId;
                }
                $wpdb->update($table, $data, ['id' => $existingId]);
            } else {
                $data['owner_user_id'] = $creatorId > 0 ? $creatorId : 1;
                $data['created_by_user_id'] = $creatorId > 0 ? $creatorId : 1;
                $data['created_at'] = current_time('mysql');
                $wpdb->insert($table, $data);
            }
        }
    }

    private static function upsertCustomersToDb(array $customers, array $deletedIds = [], bool $isAdmin = false): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) return;

        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];
        $activePhones = [];
        $activeIds = [];

        foreach ($customers as $cust) {
            if (is_object($cust)) {
                $cust = (array)$cust;
            }
            if (!is_array($cust) || empty($cust['name']) || empty($cust['mobile'])) {
                continue;
            }

            $custIdStr = (string)($cust['id'] ?? '');
            if ($custIdStr !== '' && isset($deletedSet[$custIdStr])) {
                continue;
            }

            $rawCustMobile = (string)$cust['mobile'];
            $phone = sanitize_text_field(\AvinaCRM\Operators\OperatorService::toEnglishDigits($rawCustMobile));
            $fullName = sanitize_text_field((string)$cust['name']);
            $cleanPhone = self::normalizePhone($phone);
            if ($cleanPhone !== '') $activePhones[$cleanPhone] = true;
            if (is_numeric($custIdStr) && (int)$custIdStr > 0) $activeIds[(int)$custIdStr] = true;

            $email = sanitize_email((string)($cust['email'] ?? ''));
            $isBlocked = !empty($cust['isBlocked']);
            $status = $isBlocked ? 'blocked' : sanitize_text_field((string)($cust['status'] ?? 'active'));

            $rawCreator = (string)($cust['createdById'] ?? ($cust['createdBy'] ?? ($cust['owner_user_id'] ?? ($cust['operatorId'] ?? ''))));
            $creatorId = 0;
            if (!empty($rawCreator) && $rawCreator !== 'admin') {
                $u = get_user_by('login', $rawCreator);
                if (!$u) $u = get_user_by('email', $rawCreator);
                if ($u) {
                    $creatorId = (int)$u->ID;
                } elseif (is_numeric($rawCreator) && (int)$rawCreator > 0) {
                    $checkUser = get_userdata((int)$rawCreator);
                    if ($checkUser) {
                        $creatorId = (int)$rawCreator;
                    }
                }
            }
            if ($creatorId <= 0) {
                $currentWpUid = get_current_user_id();
                if ($currentWpUid > 0) {
                    $creatorId = $currentWpUid;
                }
            }

            $existingId = 0;
            if (!empty($cust['id']) && is_numeric($cust['id'])) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE id = %d", (int)$cust['id']));
            }
            if ($existingId === 0 && !empty($phone)) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE phone = %s OR phone = %s LIMIT 1", $phone, $cleanPhone));
            }

            $customFields = [
                'isBlocked' => $isBlocked,
                'blockReason' => sanitize_text_field((string)($cust['blockReason'] ?? '')),
                'blockedBy' => sanitize_text_field((string)($cust['blockedBy'] ?? '')),
                'blockedByName' => sanitize_text_field((string)($cust['blockedByName'] ?? '')),
                'blockedAt' => sanitize_text_field((string)($cust['blockedAt'] ?? '')),
                'isCancelled' => !empty($cust['isCancelled']),
                'cancellationReason' => sanitize_text_field((string)($cust['cancellationReason'] ?? '')),
                'company' => sanitize_text_field((string)($cust['company'] ?? '')),
                'nationalId' => sanitize_text_field((string)($cust['nationalId'] ?? ($cust['nationalCode'] ?? ''))),
                'notes' => sanitize_textarea_field((string)($cust['notes'] ?? '')),
                'documentUrl' => esc_url_raw((string)($cust['documentUrl'] ?? '')),
                'updatedAt' => sanitize_text_field((string)($cust['updatedAt'] ?? current_time('mysql'))),
            ];

            $data = [
                'full_name' => $fullName,
                'phone' => $phone,
                'email' => $email,
                'status' => $status,
                'notes' => sanitize_textarea_field((string)($cust['notes'] ?? '')),
                'custom_fields' => wp_json_encode($customFields),
                'is_archived' => 0,
                'updated_at' => current_time('mysql'),
            ];

            if ($existingId > 0) {
                $existingRow = $wpdb->get_row($wpdb->prepare("SELECT created_by_user_id, owner_user_id FROM {$table} WHERE id = %d", $existingId), ARRAY_A);
                if ($existingRow && (empty($existingRow['created_by_user_id']) || (int)$existingRow['created_by_user_id'] === 0) && $creatorId > 0) {
                    $data['created_by_user_id'] = $creatorId;
                    $data['owner_user_id'] = $creatorId;
                }
                $wpdb->update($table, $data, ['id' => $existingId]);
            } else {
                $data['owner_user_id'] = $creatorId > 0 ? $creatorId : 1;
                $data['created_by_user_id'] = $creatorId > 0 ? $creatorId : 1;
                $data['created_at'] = current_time('mysql');
                $wpdb->insert($table, $data);
            }
        }
    }

    public function permissionCheck(\WP_REST_Request $request): bool
    {
        if (is_user_logged_in() && get_current_user_id() > 0) {
            return true;
        }

        $token = (string) ($request->get_header('x-avina-token') ?? ($_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '')));
        if (!empty($token)) {
            $userId = \AvinaCRM\Support\TokenService::validateToken($token);
            if ($userId > 0) {
                wp_set_current_user($userId);
                return true;
            }
        }

        $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
        if ($cookieUserId > 0) {
            wp_set_current_user($cookieUserId);
            return true;
        }

        return false;
    }
}
