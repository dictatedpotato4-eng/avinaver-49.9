<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Contacts\ContactService;
use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Support\Csv;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class ContactsController
{
    private ContactService $service;

    public function __construct()
    {
        $this->service = new ContactService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'search' => (string) $request->get_param('search'),
            'lifecycle_stage' => (string) $request->get_param('lifecycle_stage'),
            'team_id' => $request->get_param('team_id'),
            'page' => $request->get_param('page'),
            'per_page' => $request->get_param('per_page'),
            'followup_range' => (string) $request->get_param('followup_range'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function get(WP_REST_Request $request)
    {
        $item = $this->service->find((int) $request->get_param('id'));

        if ($item === null) {
            return ApiResponse::error('avina_crm_contact_not_found', __('مخاطب موردنظر یافت نشد.', 'avina-crm'), 404);
        }

        return ApiResponse::success($item);
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || current_user_can('contacts.contact.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || current_user_can('contacts.contact.create');
    }

    public function update(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->update((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || current_user_can('contacts.contact.update');
    }

    public function archive(WP_REST_Request $request)
    {
        $result = $this->service->archive((int) $request->get_param('id'), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function archivePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || current_user_can('contacts.contact.archive');
    }

    public function delete(WP_REST_Request $request)
    {
        $rawId = $request->get_param('id');
        if ($rawId === null || $rawId === '') {
            $params = $request->get_json_params() ?? [];
            $rawId = $params['id'] ?? $params['contact_id'] ?? 0;
        }

        $id = (int) $rawId;
        $rawIdStr = (string)$rawId;

        // Ensure database table deletion, app data purge, and registry persistence
        \AvinaCRM\Rest\Controllers\AppDataController::archiveDeletedItemsInDb([$rawIdStr, (string)$id, 'lead-' . $id, 'contact-' . $id]);
        \AvinaCRM\Rest\Controllers\AppDataController::purgeDeletedIdsFromAppData([$rawIdStr, (string)$id, 'lead-' . $id, 'contact-' . $id]);

        if ($id <= 0) {
            return ApiResponse::success(['id' => $rawId, 'success' => true]);
        }

        $result = $this->service->delete($id, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function deletePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || current_user_can('contacts.contact.archive') || \AvinaCRM\Support\Scope::isAdmin();
    }

    public function convert(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $purchased = (string) ($params['purchased_products'] ?? '');
        $notes = (string) ($params['notes'] ?? '');

        $result = $this->service->convertToCustomer(
            (int) $request->get_param('id'),
            get_current_user_id(),
            $purchased,
            $notes
        );

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function convertPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || \AvinaCRM\Support\Scope::hasModulePermission('customers') || current_user_can('customers.customer.convert');
    }

    public function getFollowups(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        return ApiResponse::success($this->service->getFollowups($id));
    }

    public function addFollowup(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params() ?? [];

        $date = (string) ($params['followup_date'] ?? current_time('Y-m-d'));
        $notes = (string) ($params['notes'] ?? '');
        $result = (string) ($params['result'] ?? '');

        if ($notes === '') {
            return ApiResponse::error('avina_crm_invalid_followup', __('متن صحبت پیگیری الزامی است.', 'avina-crm'), 400);
        }

        $res = $this->service->addFollowup($id, $date, $notes, $result, get_current_user_id());
        return $res instanceof WP_Error ? ApiResponse::fromWpError($res) : ApiResponse::success(['ok' => true]);
    }

    public function sendToKanban(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params() ?? [];

        $operatorId = (int) ($params['operator_id'] ?? 0);
        $stageId = (string) ($params['stage_id'] ?? 'lead');
        $desc = (string) ($params['description'] ?? '');

        if ($operatorId <= 0) {
            return ApiResponse::error('avina_crm_invalid_operator', __('کاربر مسئول الزامی است.', 'avina-crm'), 400);
        }

        $res = $this->service->sendToKanban($id, $operatorId, $stageId, $desc, get_current_user_id());
        return $res instanceof WP_Error ? ApiResponse::fromWpError($res) : ApiResponse::success($res);
    }

    public function sendMessage(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params() ?? [];

        $phone = (string) ($params['phone'] ?? '');
        $messageText = (string) ($params['message_text'] ?? '');
        $channel = (string) ($params['channel'] ?? 'sms');

        if ($phone === '' || $messageText === '') {
            return ApiResponse::error('avina_crm_invalid_message', __('شماره گیرنده و متن پیام الزامی است.', 'avina-crm'), 400);
        }

        $this->service->sendMessage($id, $phone, $messageText, $channel, get_current_user_id());
        return ApiResponse::success(['ok' => true]);
    }

    public function export(WP_REST_Request $request)
    {
        $filters = [
            'search' => (string) $request->get_param('search'),
            'lifecycle_stage' => (string) $request->get_param('lifecycle_stage'),
            'team_id' => $request->get_param('team_id'),
            'followup_range' => (string) $request->get_param('followup_range'),
        ];

        $export = $this->service->exportRows($filters);

        Csv::streamDownload('avina-crm-contacts.csv', $export['headers'], $export['rows']);
        exit;
    }

    public function exportPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('contacts') || current_user_can('contacts.contact.export');
    }
}
