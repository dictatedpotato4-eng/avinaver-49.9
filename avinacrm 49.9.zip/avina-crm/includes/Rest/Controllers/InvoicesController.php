<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Invoices\InvoiceService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class InvoicesController
{
    private InvoiceService $service;

    public function __construct()
    {
        $this->service = new InvoiceService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'status' => (string) $request->get_param('status'),
            'type' => (string) $request->get_param('type'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('invoices') || current_user_can('invoices.invoice.view');
    }

    public function get(WP_REST_Request $request)
    {
        $item = $this->service->find((int) $request->get_param('id'));

        if ($item === null) {
            return ApiResponse::error('avina_crm_invoice_not_found', __('فاکتور موردنظر یافت نشد.', 'avina-crm'), 404);
        }

        return ApiResponse::success($item);
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $items = is_array($params['items'] ?? null) ? $params['items'] : [];
        unset($params['items']);

        $result = $this->service->create($params, $items, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('invoices') || current_user_can('invoices.invoice.create');
    }

    public function changeStatus(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->changeStatus((int) $request->get_param('id'), (string) ($params['status'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('invoices') || current_user_can('invoices.invoice.update');
    }

    public function void(WP_REST_Request $request)
    {
        $result = $this->service->changeStatus((int) $request->get_param('id'), 'void', get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function voidPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('invoices') || current_user_can('invoices.invoice.void');
    }

    public function updateItems(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $items = is_array($params['items'] ?? null) ? $params['items'] : [];
        $result = $this->service->updateItems((int) $request->get_param('id'), $items, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }
}
