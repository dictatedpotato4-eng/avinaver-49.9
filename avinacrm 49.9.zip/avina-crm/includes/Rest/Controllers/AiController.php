<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class AiController
{
    public function chat(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        $message = sanitize_textarea_field($params['message'] ?? '');
        $extraContext = sanitize_textarea_field($params['extraContext'] ?? '');

        if ($message === '') {
            return ApiResponse::error('avina_crm_ai_empty_message', __('پیام نمی‌تواند خالی باشد.', 'avina-crm'), 400);
        }

        $serviceType = sanitize_key((string)($params['serviceType'] ?? ''));
        $apiKey = trim((string)($params['apiKey'] ?? ''));
        if (empty($apiKey)) {
            if ($serviceType === 'dashboard') {
                $apiKey = get_option('avina_crm_gemini_api_key_dashboard', '');
            } elseif ($serviceType === 'floating') {
                $apiKey = get_option('avina_crm_gemini_api_key_floating', '');
            } elseif ($serviceType === 'training') {
                $apiKey = get_option('avina_crm_gemini_api_key_training', '');
            } elseif ($serviceType === 'sms_writer') {
                $apiKey = get_option('avina_crm_gemini_api_key_sms_writer', '');
            }
            if (empty($apiKey)) {
                $apiKey = get_option('avina_crm_gemini_api_key', '');
            }
            // Universal fallback: check all options if still empty
            if (empty($apiKey)) {
                $apiKey = get_option('avina_crm_gemini_api_key_dashboard', '')
                    ?: get_option('avina_crm_gemini_api_key_floating', '')
                    ?: get_option('avina_crm_gemini_api_key_training', '')
                    ?: get_option('avina_crm_gemini_api_key_sms_writer', '');
            }
        }
        if ($apiKey === '') {
            return ApiResponse::success([
                'reply' => 'سلام! من آوینا، دستیار هوشمند شما هستم. متأسفانه کلید Gemini API هنوز در تنظیمات پیشرفته افزونه ثبت نشده است. لطفاً ابتدا کلید API خود را در بخش تنظیمات ثبت کنید.'
            ]);
        }

        if ($message === 'تست اتصال آنلاین') {
            $testContents = [['parts' => [['text' => 'سلام، تایید']]]];
            $res = $this->callGeminiApi($apiKey, '', $testContents, '', ['maxOutputTokens' => 10]);
            if (!$res['success']) {
                return ApiResponse::error('avina_crm_ai_http_error', "Gemini API Error: " . $res['error'], $res['code']);
            }
            return ApiResponse::success(['reply' => 'تایید ارتباط آنلاین با موفقیت انجام شد']);
        }

        if ($serviceType === 'sms_writer') {
            $smsPrompt = "تو دستیار تخصصی نگارش و ویرایش حرفه‌ای پیامک (SMS Copywriter) در CRM آوینا هستی.\n\n"
                . "اطلاعات ورودی:\n"
                . "دستور و خواسته کاربر: " . $message . "\n"
                . (!empty($extraContext) ? $extraContext . "\n" : "")
                . "\nقوانین حیاتی و الزامی که باید مو به مو اجرا شوند:\n"
                . "۱. اصل حفظ کامل متن و محتوای کاربر (CRITICAL):\n"
                . "اگر کاربر متن اولیه‌ای ارائه داده است، آن متن پیام اصلی کاربر (اطلاع‌رسانی، تبلیغاتی، تشکر، فاکتور، خدمات یا هر موضوع دیگر) است. شما موظفید دقیقاً روی همان متن کار کنید. به هیچ وجه جملات، اطلاعات، توضیحات یا معنای متن کاربر را حذف، خلاصه یا کوتاه نکنید مگر اینکه کاربر صراحتاً کلمه «خلاصه» یا «کوتاه کن» را خواسته باشد!\n\n"
                . "۲. انجام دقیق خواسته کاربر بر اساس دستور:\n"
                . "• اگر دستور کاربر اضافه کردن ایموجی است: تک‌تک خطوط و جملات متن اولیه کاربر را کلمه به کلمه حفظ کن و فقط ایموجی‌های شیک، زیبا و مرتبط با کسب‌وکار در جاهای مناسب متن اضافه کن. هیچ متنی را حذف نکن!\n"
                . "• اگر دستور رسمی/اداری کردن است: همان محتوا و اطلاعات متن کاربر را به بیانی رسمی و محترمانه تبدیل کن بدون حذف هیچ بخشی از پیام.\n"
                . "• اگر دستور تبلیغاتی کردن است: به پیام کاربر جذابیت و عبارت دعوت به اقدام بیفزای بدون اینکه پیام و منظور اصلی حذف شود.\n"
                . "• اگر دستور صمیمی/دوستانه کردن است: همان متن کاربر را با ادبیاتی گرم و دلنشین بازنویسی کن.\n"
                . "• اگر دستور خلاصه کردن است: طول متن را بهینه‌سازی و فشرده کن.\n"
                . "• اگر متنی از قبل نبود و کاربر خواهان نوشتن پیامکی جدید شد: یک پیامک اختصاصی، جذاب و کامل متناسب با همان موضوع بنویس.\n\n"
                . "۳. قالب پاسخ:\n"
                . "ابتدا در خط اول یک جمله کوتاه بنویس.\n"
                . "سپس حتماً خط جدید بگذار و عبارت زیر را دقیقاً بنویس:\n"
                . "=== متن نهایی پیامک ===\n"
                . "و در خط بعد دقیقاً خود متن پیامک آماده را قرار بده تا کاربر بتواند با یک کلیک آن را در فیلد پیامک قرار دهد.";

            $contents = [['parts' => [['text' => $smsPrompt]]]];
            $res = $this->callGeminiApi($apiKey, '', $contents);

            if (!$res['success']) {
                return ApiResponse::error('avina_crm_ai_http_error', "Gemini API Error: " . $res['error'], $res['code']);
            }

            $data = json_decode($res['body'], true);
            $reply = $data['candidates'][0]['content']['parts'][0]['text'] ?? 'خطا در دریافت پاسخ از هوش مصنوعی.';
            return ApiResponse::success(['reply' => $reply]);
        }

        $instruction = get_option('avina_crm_gemini_instruction', 'شما دستیار هوشمند آوینا هستید. تحلیل‌های سازمانی، آمارهای عملکرد اپراتورها، و متن‌های پاسخ‌دهی به مشتریان را دقیق، کاربردی و محترمانه به زبان فارسی ارائه می‌دهید.');

        $userId = sanitize_text_field((string)($params['userId'] ?? get_current_user_id()));
        $userRole = sanitize_text_field((string)($params['userRole'] ?? ''));
        $isAdmin = current_user_can('manage_options') || ($userRole === 'admin');

        // Gather CRM statistics with strict user isolation
        global $wpdb;
        if ($isAdmin) {
            $contacts_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0");
            $customers_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_customers WHERE is_archived = 0");
            
            $deals_stats = $wpdb->get_results("SELECT status, COUNT(*) as cnt, SUM(value) as val FROM {$wpdb->prefix}avina_deals WHERE is_archived = 0 GROUP BY status", ARRAY_A);
            $deals_info = "";
            if (!empty($deals_stats)) {
                foreach ($deals_stats as $stat) {
                    $deals_info .= "وضعیت " . $stat['status'] . ": " . $stat['cnt'] . " معامله به ارزش " . number_format((float)$stat['val']) . " ریال. ";
                }
            } else {
                $deals_info = "معامله‌ای ثبت نشده است.";
            }

            $receptions_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_device_intakes");
            $invoices_sum = (float) $wpdb->get_var("SELECT SUM(total) FROM {$wpdb->prefix}avina_invoices WHERE is_archived = 0");
            $payments_sum = (float) $wpdb->get_var("SELECT SUM(amount) FROM {$wpdb->prefix}avina_payments");

            $crmContext = "اطلاعات آماری پایگاه داده کلان CRM برای مدیریت ارشد سیستم:\n";
            $crmContext .= "- مخاطبین کل سیستم: $contacts_cnt\n";
            $crmContext .= "- مشتریان کل سیستم: $customers_cnt\n";
            $crmContext .= "- آمار معاملات: $deals_info\n";
            $crmContext .= "- کل پذیرش‌های ثبت شده: $receptions_cnt\n";
            $crmContext .= "- جمع فاکتورها: " . number_format($invoices_sum) . " ریال\n";
            $crmContext .= "- جمع پرداخت‌ها: " . number_format($payments_sum) . " ریال\n";
        } else {
            $cleanUid = preg_replace('/\D+/', '', $userId);
            $contacts_cnt = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0 AND (owner_user_id = %s OR created_by_user_id = %s)",
                $cleanUid ?: $userId,
                $cleanUid ?: $userId
            ));
            $customers_cnt = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}avina_customers WHERE is_archived = 0 AND (owner_user_id = %s OR created_by_user_id = %s)",
                $cleanUid ?: $userId,
                $cleanUid ?: $userId
            ));

            $crmContext = "شما دستیار اختصاصی این اپراتور (شناسه کاربری: {$userId}) هستید.\n";
            $crmContext .= "شما صرفاً بر روی مخاطبین و وظایف شخصی این اپراتور تمرکز دارید و به هیچ عنوان نباید آمارهای مالی کلان سازمان، فاکتورها یا اطلاعات سایر اپراتورها را به وی نشان دهید.\n";
            $crmContext .= "- مخاطبین اختصاصی شما: $contacts_cnt\n";
            $crmContext .= "- مشتریان اختصاصی شما: $customers_cnt\n";
        }

        $history = $params['history'] ?? [];
        
        $roleInstruction = "شما «دستیار هوشمند و توانمند آوینا» در سامانه CRM هستید؛ بسیار باهوش، محترم، خلاق و مسلط به زبان فارسی.\n\n"
            . "قوانین الزامی پاسخگویی به کاربر:\n"
            . "۱. تمرکز کامل و مستقیم بر پیام و دستور کاربر:\n"
            . "شما باید دقیقاً، مستقیماً و اختصاصی به صحبت، سوال، درخواست یا دستوری که کاربر نوشته پاسخ دهید. اگر کاربر احوالپرسی کرد با خوشرویی و صمیمیت پاسخ دهید؛ اگر کاربر دستور نگارش متن، ایده فروش، راهکار بازاریابی، یا راهنمایی داد، فوراً همان دستور را اجرا کنید.\n"
            . "۲. منع اکید از تکرار پاسخ‌های کلیشه‌ای و تکرار گزارش‌های قبلی:\n"
            . "به هیچ وجه متن ثابت یا موضوعات گذشته (مانند مشکلات یا مناطق خاص) را در هر پاسخ تکرار نکنید مگر اینکه کاربر مشخصاً درباره آن‌ها سوال کرده باشد.\n"
            . "۳. بهره‌گیری هوشمندانه از آمار و زمینه سیستم:\n"
            . "اطلاعات آماری و زمینه‌ای زیر صرفاً به عنوان دانش پس‌زمینه در اختیار شماست؛ تنها زمانی که کاربر درباره وضعیت آمار، مشتریان، عملکرد اپراتورها یا گزارش روز سوال پرسید از این ارقام استفاده کنید.\n\n";

        if ($serviceType === 'training') {
            $roleInstruction = "شما «مربی تخصصی و پایگاه دانش آوینا» هستید. بر اساس دستور و سوال کاربر و دانش سازمانی ثبت شده، پاسخی جامع، دقیق، کاربردی و روان به زبان فارسی ارائه دهید.\n\n";
        } elseif ($serviceType === 'dashboard') {
            $roleInstruction = "شما «تحلیل‌گر هوشمند پیشخوان آوینا» هستید. با دقت به سوال یا تحلیل درخواستی کاربر پاسخ داده و بینش‌های کاربردی ارائه دهید.\n\n";
        }

        $systemPrompt = $roleInstruction;
        if (!empty($extraContext)) {
            $systemPrompt .= "[اطلاعات زمینه و داده‌های سیستم]:\n" . $extraContext . "\n\n";
        }
        if (!empty($crmContext)) {
            $systemPrompt .= "[آمار و وضعیت CRM]:\n" . $crmContext . "\n\n";
        }
        $systemPrompt .= "پیام یا دستور کاربر: " . $message;

        $contents = [];
        if (is_array($history) && !empty($history)) {
            foreach (array_slice($history, -6) as $item) {
                $role = ($item['role'] ?? '') === 'model' || ($item['sender'] ?? '') === 'avina' ? 'model' : 'user';
                $text = sanitize_text_field((string)($item['text'] ?? ($item['message'] ?? '')));
                if (!empty($text)) {
                    $contents[] = ['role' => $role, 'parts' => [['text' => $text]]];
                }
            }
        }
        $contents[] = ['role' => 'user', 'parts' => [['text' => $systemPrompt]]];

        $res = $this->callGeminiApi($apiKey, '', $contents);

        if (!$res['success']) {
            return ApiResponse::error('avina_crm_ai_http_error', "Gemini API Error: " . $res['error'], $res['code']);
        }

        $data = json_decode($res['body'], true);
        $reply = $data['candidates'][0]['content']['parts'][0]['text'] ?? 'خطا در دریافت پاسخ از هوش مصنوعی.';

        return ApiResponse::success(['reply' => $reply]);
    }

    public function scanDocument(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        $imageBase64 = trim((string)($params['image'] ?? ''));
        $apiKey = trim((string)($params['apiKey'] ?? ''));
        $model = trim((string)($params['model'] ?? 'gemini-1.5-flash'));
        $proxy = trim((string)($params['proxy'] ?? ''));

        if (empty($apiKey)) {
            $apiKey = get_option('avina_crm_gemini_api_key', '');
        }

        if (empty($apiKey)) {
            return ApiResponse::error('avina_crm_ai_empty_key', 'کلید API هوش مصنوعی Gemini در تنظیمات مدیر ثبت نشده است.', 400);
        }

        if (empty($imageBase64)) {
            return ApiResponse::error('avina_crm_ai_empty_image', 'تصویر مدرک ارسالی خالی است.', 400);
        }

        // Clean base64 header if present
        if (strpos($imageBase64, ',') !== false) {
            $parts = explode(',', $imageBase64);
            $imageBase64 = end($parts);
        }

        // Save image to upload directory as real file to avoid large base64 storage
        $imageUrl = '';
        $upload_dir = wp_upload_dir();
        $target_dir = $upload_dir['basedir'] . '/avina-crm-docs';
        $target_url = $upload_dir['baseurl'] . '/avina-crm-docs';
        if (!file_exists($target_dir)) {
            wp_mkdir_p($target_dir);
        }
        $decoded = base64_decode($imageBase64);
        if ($decoded !== false) {
            $filename = 'scan_' . time() . '_' . wp_generate_password(6, false) . '.jpg';
            $filepath = $target_dir . '/' . $filename;
            if (@file_put_contents($filepath, $decoded) !== false) {
                $imageUrl = $target_url . '/' . $filename;
            }
        }

        $promptText = "شما یک سیستم تحلیل تصویر و OCR مدرک اداری فارسی هستید.
لطفاً این تصویر (کارت ملی، رسید، فاکتور، فرم پذیرش یا لیست مخاطبین/مشتریان) را به دقت بررسی کن.

اگر تصویر حاوی متن یا اطلاعات شناسه/فاکتور/پذیرش فارسی نیست، فیلد foundInfo را برابر false قرار بده.
در غیر این صورت اطلاعات واقعی موجود را در یک JSON خام با کلیدهای زیر استخراج نما:

{
  \"foundInfo\": true,
  \"name\": \"نام و نام خانوادگی اصلی\",
  \"mobile\": \"شماره همراه (مثلاً 09121234567)\",
  \"nationalCode\": \"کد ملی یا شناسه اقتصادی\",
  \"deviceModel\": \"مدل دستگاه، کالا یا عنوان خدمات\",
  \"serialNumber\": \"شماره سریال، شماره فاکتور یا کد رهگیری\",
  \"problemDescription\": \"شرح ایراد، توضیحات یا جزئیات فاکتور\",
  \"totalPrice\": \"مبلغ کل به عدد\",
  \"purchaseProbability\": 4,
  \"contacts\": [
    {
      \"name\": \"نام شخص یا مخاطب\",
      \"mobile\": \"شماره همراه\",
      \"notes\": \"توضیحات یا درخواست مرتبط با این شخص\",
      \"job\": \"شغل یا سمت در صورت وجود\",
      \"purchaseProbability\": 4
    }
  ]
}

قوانین مهم:
۱. اگر برگه شامل چندین شخص یا چندین شماره تماس و توضیحات است، برای تک‌تک آن‌ها یک آیتم مجزا در آرایه contacts بساز.
۲. بر اساس متن و میزان نیاز یا جدیت، فیلد purchaseProbability را بین عدد ۱ تا ۵ هوشمندانه تخمین بزن (۵ بیشترین تمایل خرید، ۱ کمترین).
۳. اگر فقط یک شخص در تصویر است، فیلدهای اصلی را پر کن و در آرایه contacts نیز همان یک نفر را قرار بده.
۴. خروجی باید الزاماً فقط یک آبجکت JSON معتبر باشد.";

        $contents = [[
            'parts' => [
                ['text' => $promptText],
                ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $imageBase64]]
            ]
        ]];

        $generationConfig = [
            'responseMimeType' => 'application/json',
            'temperature' => 0.1,
            'maxOutputTokens' => 1024,
        ];

        $res = $this->callGeminiApi($apiKey, $model, $contents, $proxy, $generationConfig);

        if (!$res['success']) {
            return ApiResponse::error('avina_crm_ai_google_error', "گوگل Gemini: " . $res['error'], $res['code']);
        }

        $data = json_decode($res['body'], true);
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

        $parsed = null;
        if ($text) {
            $parsed = json_decode($text, true);
            if (!$parsed && preg_match('/\{[\s\S]*\}/', $text, $matches)) {
                $parsed = json_decode($matches[0], true);
            }
        }

        return ApiResponse::success([
            'extracted' => $parsed,
            'raw' => $text,
            'usedModel' => $res['model'],
            'imageUrl' => $imageUrl
        ]);
    }

    /**
     * Dynamically discover all active models authorized for this user's API key
     */
    private function getAvailableGeminiModels(string $apiKey, string $customProxy = ''): array
    {
        $cacheKey = 'avina_gemini_models_' . substr(md5($apiKey), 0, 10);
        $cached = get_transient($cacheKey);
        if (is_array($cached) && !empty($cached)) {
            return $cached;
        }

        $proxy = !empty($customProxy) ? $customProxy : get_option('avina_crm_ai_proxy', '');
        if (!empty($proxy) && (strpos($proxy, '/32') !== false || strpos($proxy, '/24') !== false || strpos($proxy, '10.66.66.') !== false)) {
            $proxy = '';
        }
        if (empty($proxy) && defined('WP_PROXY_HOST') && WP_PROXY_HOST) {
            $proxy = WP_PROXY_HOST . (defined('WP_PROXY_PORT') && WP_PROXY_PORT ? ':' . WP_PROXY_PORT : '');
        }

        $args = [
            'timeout' => 8,
            'sslverify' => false,
        ];
        if (!empty($proxy)) {
            $args['proxy'] = $proxy;
        }

        $listUrls = [
            "https://generativelanguage.googleapis.com/v1beta/models?key={$apiKey}",
            "https://generativelanguage.googleapis.com/v1/models?key={$apiKey}"
        ];

        foreach ($listUrls as $url) {
            $res = wp_remote_get($url, $args);
            if (is_wp_error($res) && !empty($args['proxy'])) {
                unset($args['proxy']);
                $res = wp_remote_get($url, $args);
            }
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $body = wp_remote_retrieve_body($res);
                $data = json_decode($body, true);
                if (is_array($data) && isset($data['models']) && is_array($data['models'])) {
                    $found = [];
                    foreach ($data['models'] as $m) {
                        $methods = $m['supportedGenerationMethods'] ?? [];
                        if (is_array($methods) && in_array('generateContent', $methods, true)) {
                            $name = preg_replace('/^models\//', '', (string)($m['name'] ?? ''));
                            if (!empty($name)) {
                                $found[] = $name;
                            }
                        }
                    }
                    if (!empty($found)) {
                        // Prioritize flash models, then pro models
                        usort($found, function($a, $b) {
                            $scoreA = str_contains($a, '2.5-flash') ? 10 : (str_contains($a, '2.0-flash') ? 8 : (str_contains($a, '1.5-flash') ? 6 : (str_contains($a, 'flash') ? 5 : (str_contains($a, '2.5-pro') ? 4 : (str_contains($a, 'pro') ? 2 : 0)))));
                            $scoreB = str_contains($b, '2.5-flash') ? 10 : (str_contains($b, '2.0-flash') ? 8 : (str_contains($b, '1.5-flash') ? 6 : (str_contains($b, 'flash') ? 5 : (str_contains($b, '2.5-pro') ? 4 : (str_contains($b, 'pro') ? 2 : 0)))));
                            return $scoreB <=> $scoreA;
                        });
                        set_transient($cacheKey, $found, HOUR_IN_SECONDS * 12);
                        return $found;
                    }
                }
            }
        }

        // Comprehensive fallback list with official 2.5, 2.0, and 1.5 model generations
        return [
            'gemini-2.5-flash',
            'gemini-2.0-flash',
            'gemini-1.5-flash',
            'gemini-2.5-pro',
            'gemini-1.5-pro',
            'gemini-flash-latest',
            'gemini-2.0-flash-exp',
            'gemini-1.5-flash-8b'
        ];
    }

    private function callGeminiApi(string $apiKey, string $requestedModel, array $contents, string $customProxy = '', array $generationConfig = []): array
    {
        $discovered = $this->getAvailableGeminiModels($apiKey, $customProxy);

        $cleanRequested = trim($requestedModel);
        if ($cleanRequested === 'gemini-pro' || $cleanRequested === 'gemini-1.0-pro') {
            $cleanRequested = '';
        }

        $candidateModels = [];
        if (!empty($cleanRequested)) {
            $candidateModels[] = $cleanRequested;
        }
        $candidateModels = array_unique(array_filter(array_merge($candidateModels, $discovered, [
            'gemini-2.5-flash',
            'gemini-2.0-flash',
            'gemini-1.5-flash',
            'gemini-2.5-pro',
            'gemini-1.5-pro',
            'gemini-flash-latest'
        ])));

        $lastError = '';
        $lastCode = 500;

        $proxy = !empty($customProxy) ? $customProxy : get_option('avina_crm_ai_proxy', '');
        if (!empty($proxy) && (strpos($proxy, '/32') !== false || strpos($proxy, '/24') !== false || strpos($proxy, '10.66.66.') !== false)) {
            $proxy = '';
        }
        if (empty($proxy) && defined('WP_PROXY_HOST') && WP_PROXY_HOST) {
            $proxy = WP_PROXY_HOST . (defined('WP_PROXY_PORT') && WP_PROXY_PORT ? ':' . WP_PROXY_PORT : '');
        }

        $apiVersions = ['v1beta', 'v1'];

        foreach ($candidateModels as $model) {
            foreach ($apiVersions as $ver) {
                $url = "https://generativelanguage.googleapis.com/{$ver}/models/{$model}:generateContent?key={$apiKey}";
                
                $payload = ['contents' => $contents];
                if (!empty($generationConfig)) {
                    $payload['generationConfig'] = $generationConfig;
                }

                $args = [
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'x-goog-api-key' => $apiKey,
                    ],
                    'body' => wp_json_encode($payload),
                    'timeout' => 20,
                    'sslverify' => false,
                ];

                if (!empty($proxy)) {
                    $args['proxy'] = $proxy;
                }

                $response = wp_remote_post($url, $args);

                if (is_wp_error($response) && !empty($args['proxy'])) {
                    unset($args['proxy']);
                    $response = wp_remote_post($url, $args);
                }

                if (is_wp_error($response)) {
                    $lastError = $response->get_error_message();
                    continue;
                }

                $code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);

                if ($code === 200) {
                    // Cache the successful model
                    set_transient('avina_gemini_working_model_' . substr(md5($apiKey), 0, 10), $model, HOUR_IN_SECONDS * 24);
                    return ['success' => true, 'body' => $body, 'model' => $model, 'apiVersion' => $ver];
                }

                $errData = json_decode($body, true);
                $lastError = $errData['error']['message'] ?? "HTTP $code: $body";
                $lastCode = $code;

                if (strpos($lastError, 'API key not valid') !== false || strpos($lastError, 'API_KEY_INVALID') !== false) {
                    return ['success' => false, 'error' => $lastError, 'code' => $lastCode];
                }
            }
        }

        return ['success' => false, 'error' => $lastError, 'code' => $lastCode];
    }

    public function permissionCheck(): bool
    {
        return true;
    }
}
