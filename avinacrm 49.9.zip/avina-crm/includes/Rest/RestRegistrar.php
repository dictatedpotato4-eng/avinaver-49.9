<?php

declare(strict_types=1);

namespace AvinaCRM\Rest;

use WP_REST_Request;
use WP_REST_Response;
use AvinaCRM\Rest\Controllers\MeController;
use AvinaCRM\Rest\Controllers\OperatorsController;
use AvinaCRM\Rest\Controllers\SystemController;
use AvinaCRM\Rest\Controllers\TeamsController;
use AvinaCRM\Rest\Controllers\ContactsController;
use AvinaCRM\Rest\Controllers\CustomersController;
use AvinaCRM\Rest\Controllers\PhonebookController;
use AvinaCRM\Rest\Controllers\ReceptionController;
use AvinaCRM\Rest\Controllers\ActivitiesController;
use AvinaCRM\Rest\Controllers\TasksController;
use AvinaCRM\Rest\Controllers\RemindersController;
use AvinaCRM\Rest\Controllers\NotificationsController;
use AvinaCRM\Rest\Controllers\TicketsController;
use AvinaCRM\Rest\Controllers\PipelinesController;
use AvinaCRM\Rest\Controllers\DealsController;
use AvinaCRM\Rest\Controllers\InvoicesController;
use AvinaCRM\Rest\Controllers\PaymentsController;
use AvinaCRM\Rest\Controllers\AnalyticsController;
use AvinaCRM\Rest\Controllers\WebhooksController;
use AvinaCRM\Rest\Controllers\BackupController;
use AvinaCRM\Rest\Controllers\AuditLogController;

/**
 * Every route below sets a real `permission_callback` (WordPress logs a
 * `_doing_it_wrong` notice and treats a missing one as public if
 * omitted — never allowed here). Authentication itself is WordPress's
 * own cookie + nonce mechanism: the REST API automatically requires a
 * valid `X-WP-Nonce` header on any cookie-authenticated mutating request
 * (POST/PUT/PATCH/DELETE) via `rest_cookie_check_errors`, so this class
 * does not need to re-implement nonce verification — it only adds the
 * capability check on top, which nonce verification alone does not
 * provide.
 */
final class RestRegistrar
{
    public const NAMESPACE_V1 = 'avina-crm/v1';

    public function bootstrap(): void
    {
        add_action('rest_api_init', [$this, 'registerRoutes']);

        // 1. Authenticate via persistent X-Avina-Token or fallback to WP auth cookie
        add_filter('determine_current_user', function ($userId) {
            if ($userId) {
                return $userId;
            }
            $token = '';
            if (isset($_SERVER['HTTP_X_AVINA_TOKEN'])) {
                $token = sanitize_text_field((string) $_SERVER['HTTP_X_AVINA_TOKEN']);
            } elseif (isset($_REQUEST['avina_token'])) {
                $token = sanitize_text_field((string) $_REQUEST['avina_token']);
            }
            if (!empty($token)) {
                $tokenUserId = \AvinaCRM\Support\TokenService::validateToken($token);
                if ($tokenUserId > 0) {
                    return $tokenUserId;
                }
            }
            $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
            if ($cookieUserId > 0) {
                return $cookieUserId;
            }
            return $userId;
        }, 20);

        // 2. Prevent rest_cookie_invalid_nonce from failing valid authenticated CRM requests
        add_filter('rest_authentication_errors', function ($result) {
            $uri = $_SERVER['REQUEST_URI'] ?? '';
            if (empty($uri) || strpos($uri, 'avina-crm') === false) {
                return $result;
            }
            if (is_wp_error($result) && $result->get_error_code() === 'rest_cookie_invalid_nonce') {
                $currentId = get_current_user_id();
                if ($currentId > 0) {
                    return true;
                }
                $token = $_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '');
                if (!empty($token)) {
                    $tokenUserId = \AvinaCRM\Support\TokenService::validateToken((string) $token);
                    if ($tokenUserId > 0) {
                        wp_set_current_user($tokenUserId);
                        return true;
                    }
                }
                $cookieUserId = wp_validate_auth_cookie('', 'logged_in');
                if ($cookieUserId > 0) {
                    wp_set_current_user($cookieUserId);
                    return true;
                }
            }
            return $result;
        }, 101);

        add_filter('rest_pre_serve_request', function ($served, $result, $request) {
            if ($request instanceof \WP_REST_Request) {
                $route = $request->get_route();
                if (strpos($route, '/avina-crm/') !== false) {
                    header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
                    header('Pragma: no-cache');
                    header('Expires: 0');
                    if (function_exists('do_action')) {
                        do_action('litespeed_control_set_nocache', 'avina CRM live data');
                    }
                }
            }
            return $served;
        }, 10, 3);
    }

    public function registerRoutes(): void
    {
        register_rest_route(self::NAMESPACE_V1, '/logout', [
            'methods' => ['POST', 'GET'],
            'callback' => function (\WP_REST_Request $request): WP_REST_Response {
                $token = $_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '');
                if (!empty($token)) {
                    \AvinaCRM\Support\TokenService::revokeToken((string) $token);
                }
                wp_clear_auth_cookie();
                wp_logout();
                return ApiResponse::success([
                    'logged_out' => true,
                    'redirect' => esc_url_raw(site_url('/crm-login/')),
                    'redirect_url' => esc_url_raw(site_url('/crm-login/')),
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/public-invoice/save', [
            'methods' => 'POST',
            'callback' => function (\WP_REST_Request $request): WP_REST_Response {
                $params = $request->get_json_params() ?? [];
                if (empty($params) || empty($params['id'])) {
                    return ApiResponse::error('invalid_invoice', 'اطلاعات فاکتور ناقص است.', 400);
                }

                $invoiceId = sanitize_text_field((string)$params['id']);
                $allInvoices = get_option('avina_public_invoices', []);
                if (!is_array($allInvoices)) $allInvoices = [];

                $params['createdAtTimestamp'] = time();
                $found = false;
                foreach ($allInvoices as $idx => $inv) {
                    if (($inv['id'] ?? '') === $invoiceId) {
                        $allInvoices[$idx] = $params;
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    $allInvoices[] = $params;
                }

                // Keep up to 200 recent invoices in option
                if (count($allInvoices) > 200) {
                    $allInvoices = array_slice($allInvoices, -200);
                }

                update_option('avina_public_invoices', $allInvoices);
                return ApiResponse::success(['saved' => true, 'id' => $invoiceId]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/melodify/tracks', [
            'methods' => 'GET',
            'callback' => function (\WP_REST_Request $request): WP_REST_Response {
                $category = sanitize_text_field((string)($request->get_param('category') ?? 'all'));
                $tracks = \AvinaCRM\Support\MelodifyCatalog::getTracks($category);
                return ApiResponse::success([
                    'total' => count($tracks),
                    'tracks' => $tracks
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/melodify/search', [
            'methods' => 'GET',
            'callback' => function (\WP_REST_Request $request): WP_REST_Response {
                $query = sanitize_text_field((string)($request->get_param('q') ?? ''));
                $results = \AvinaCRM\Support\MelodifyCatalog::search($query);
                return ApiResponse::success([
                    'query' => $query,
                    'total' => count($results),
                    'results' => $results
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/melodify/playlists', [
            'methods' => 'GET',
            'callback' => function (): WP_REST_Response {
                return ApiResponse::success([
                    'playlists' => \AvinaCRM\Support\MelodifyCatalog::getPlaylists(),
                    'artists' => \AvinaCRM\Support\MelodifyCatalog::getArtists(),
                    'reels' => \AvinaCRM\Support\MelodifyCatalog::getReels()
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/eitaa/send', [
            'methods' => 'POST',
            'callback' => function (\WP_REST_Request $request): WP_REST_Response {
                try {
                    $params = $request->get_json_params() ?? [];
                    $token = trim((string)($params['token'] ?? ''));
                    $recipient = trim((string)($params['recipient'] ?? ''));
                    $text = trim((string)($params['text'] ?? ''));
                    $imageUrl = trim((string)($params['image_url'] ?? ''));

                    if (empty($token)) {
                        $userId = get_current_user_id();
                        if ($userId > 0) {
                            $savedMeta = get_user_meta($userId, 'avina_crm_messenger_settings', true);
                            if (is_array($savedMeta) && !empty($savedMeta['eitaaToken'])) {
                                $token = trim((string)$savedMeta['eitaaToken']);
                            } else {
                                $savedOpt = get_option('avina_crm_messenger_settings_' . $userId, []);
                                if (is_array($savedOpt) && !empty($savedOpt['eitaaToken'])) {
                                    $token = trim((string)$savedOpt['eitaaToken']);
                                }
                            }
                        }
                    }

                    if (empty($token)) {
                        return ApiResponse::error('eitaa_empty_token', 'توکن ربات ایتا در تنظیمات اپراتور یا فیلد ارسال یافت نشد. لطفاً در بخش تنظیمات > پیام‌رسان‌ها، توکن ایتا را ذخیره نمایید.', 400);
                    }
                    if (empty($recipient)) {
                        return ApiResponse::error('eitaa_empty_recipient', 'شماره یا آیدی گیرنده وارد نشده است.', 400);
                    }
                    if (empty($text) && empty($imageUrl)) {
                        return ApiResponse::error('eitaa_empty_content', 'متن یا تصویر پیام خالی است.', 400);
                    }

                    $chatId = preg_replace('/[^\d@a-zA-Z0-9_]/', '', $recipient);
                    if (substr($chatId, 0, 2) === '09') {
                        $chatId = '0' . substr($chatId, -10);
                    }

                    // Method 1: Eitaayar.ir API (https://eitaayar.ir/api/TOKEN/sendMessage or sendFile)
                    if (!empty($imageUrl)) {
                        $eitaayarUrl = "https://eitaayar.ir/api/{$token}/sendFile";
                        $eitaayarBody = [
                            'chat_id' => $chatId,
                            'url' => $imageUrl,
                            'caption' => $text
                        ];
                    } else {
                        $eitaayarUrl = "https://eitaayar.ir/api/{$token}/sendMessage";
                        $eitaayarBody = [
                            'chat_id' => $chatId,
                            'text' => $text
                        ];
                    }

                    $res = wp_remote_post($eitaayarUrl, [
                        'timeout' => 15,
                        'body' => $eitaayarBody,
                        'sslverify' => false
                    ]);

                    if (!is_wp_error($res)) {
                        $code = wp_remote_retrieve_response_code($res);
                        $bodyStr = wp_remote_retrieve_body($res);
                        $body = json_decode($bodyStr, true);
                        if ($code === 200 && (!isset($body['ok']) || $body['ok'] === true)) {
                            return ApiResponse::success([
                                'sent' => true,
                                'provider' => 'eitaayar',
                                'message' => 'پیام با موفقیت از طریق ربات ایتا (Eitaayar) ارسال گردید.'
                            ]);
                        }
                    }

                    // Method 2: Official Eitaa Bot API (https://eitaa.com/botTOKEN/sendMessage or sendPhoto)
                    $cleanToken = preg_replace('/^bot/i', '', $token);
                    if (!empty($imageUrl)) {
                        $officialUrl = "https://eitaa.com/bot{$cleanToken}/sendPhoto";
                        $officialBody = [
                            'chat_id' => $chatId,
                            'photo' => $imageUrl,
                            'caption' => $text
                        ];
                    } else {
                        $officialUrl = "https://eitaa.com/bot{$cleanToken}/sendMessage";
                        $officialBody = [
                            'chat_id' => $chatId,
                            'text' => $text
                        ];
                    }

                    $resOfficial = wp_remote_post($officialUrl, [
                        'timeout' => 15,
                        'body' => $officialBody,
                        'sslverify' => false
                    ]);

                    if (!is_wp_error($resOfficial)) {
                        $code = wp_remote_retrieve_response_code($resOfficial);
                        $bodyStr = wp_remote_retrieve_body($resOfficial);
                        $body = json_decode($bodyStr, true);
                        if ($code === 200 && (!isset($body['ok']) || $body['ok'] === true)) {
                            return ApiResponse::success([
                                'sent' => true,
                                'provider' => 'eitaa_official',
                                'message' => 'پیام با موفقیت از طریق ربات رسمی ایتا ارسال گردید.'
                            ]);
                        }
                    }

                    $errMsg = 'خطا در ارسال رباتیک ایتا. لطفا از صحت توکن و استارت بودن ربات توسط گیرنده اطمینان حاصل نمایید.';
                    if (!is_wp_error($res)) {
                        $errBody = json_decode(wp_remote_retrieve_body($res), true);
                        if (isset($errBody['description'])) {
                            $errMsg .= ' (' . $errBody['description'] . ')';
                        }
                    }
                    return ApiResponse::error('eitaa_failed', $errMsg, 400);

                } catch (\Throwable $e) {
                    return ApiResponse::error('eitaa_exception', 'خطای سیستم ارسال ایتا: ' . $e->getMessage(), 500);
                }
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/login', [
            'methods' => 'POST',
            'callback' => function (WP_REST_Request $request): WP_REST_Response {
                $params = $request->get_json_params() ?? [];
                $rawUsername = (string) ($params['username'] ?? '');
                $rawPassword = (string) ($params['password'] ?? '');

                $username = sanitize_text_field(\AvinaCRM\Operators\OperatorService::toEnglishDigits(trim($rawUsername)));
                $password = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim($rawPassword));

                if (empty($username) || empty($password)) {
                    return ApiResponse::error('invalid_credentials', 'لطفاً نام کاربری و رمز عبور را وارد کنید.', 400);
                }

                if (!defined('TEST_COOKIE')) {
                    define('TEST_COOKIE', 'testcookie');
                }
                $_COOKIE[TEST_COOKIE] = 'WP Cookie check';

                $user = null;
                $foundUser = get_user_by('login', $username);
                if (!$foundUser && is_email($username)) {
                    $foundUser = get_user_by('email', $username);
                }
                if (!$foundUser) {
                    $mobileUsers = get_users([
                        'meta_key' => 'avina_crm_operator_mobile',
                        'meta_value' => $username,
                        'number' => 1
                    ]);
                    if (!empty($mobileUsers)) {
                        $foundUser = $mobileUsers[0];
                    }
                }

                if ($foundUser instanceof \WP_User) {
                    if (wp_check_password($password, $foundUser->user_pass, $foundUser->ID)) {
                        $user = $foundUser;
                    } else {
                        $checkAuth = wp_authenticate_username_password(null, $foundUser->user_login, $password);
                        if ($checkAuth instanceof \WP_User) {
                            $user = $checkAuth;
                        }
                    }
                }

                if (!$user instanceof \WP_User) {
                    $fallbackAuth = wp_authenticate($username, $password);
                    if ($fallbackAuth instanceof \WP_User) {
                        $user = $fallbackAuth;
                    }
                }

                if (!$user instanceof \WP_User) {
                    return ApiResponse::error('invalid_credentials', 'نام کاربری یا رمز عبور اشتباه است.', 401);
                }

                $remember = !empty($params['remember']);
                wp_clear_auth_cookie();
                wp_set_current_user($user->ID, $user->user_login);
                $isHttps = is_ssl()
                    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
                    || (isset($_SERVER['HTTPS']) && (strtolower((string)$_SERVER['HTTPS']) === 'on' || $_SERVER['HTTPS'] === '1'))
                    || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
                wp_set_auth_cookie($user->ID, $remember, $isHttps);
                do_action('wp_login', $user->user_login, $user);

                $crmToken = \AvinaCRM\Support\TokenService::generateToken($user->ID);
                $is_admin = \AvinaCRM\Support\Scope::isAdmin() || in_array('administrator', (array) $user->roles, true) || user_can($user, 'manage_options');
                $redirect_url = $is_admin ? site_url('/crm-admin/') : site_url('/crm-operator/');

                $permissions = $is_admin
                    ? ['dashboard', 'settings', 'users', 'recruitment', 'accounting', 'inventory', 'customers', 'invoices', 'leads', 'expenses', 'cheques', 'reports', 'phonebook', 'ai-assistant', 'reception', 'tickets', 'tasks']
                    : get_user_meta($user->ID, 'avina_crm_operator_permissions', true);

                if (!is_array($permissions)) {
                    $permissions = ['dashboard', 'leads'];
                }

                update_user_meta($user->ID, 'avina_crm_last_login', current_time('mysql'));

                return ApiResponse::success([
                    'id' => (string) $user->ID,
                    'display_name' => $user->display_name ?: $user->user_login,
                    'name' => $user->display_name ?: $user->user_login,
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'role' => $is_admin ? 'admin' : 'editor',
                    'is_administrator' => $is_admin,
                    'permissions' => $permissions,
                    'crm_token' => $crmToken,
                    'nonce' => wp_create_nonce('wp_rest'),
                    'page_url' => $redirect_url,
                    'redirect_url' => $redirect_url,
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/logout', [
            'methods' => ['POST', 'GET'],
            'callback' => function (): WP_REST_Response {
                $token = $_SERVER['HTTP_X_AVINA_TOKEN'] ?? ($_REQUEST['avina_token'] ?? '');
                if (!empty($token)) {
                    \AvinaCRM\Support\TokenService::revokeToken((string) $token);
                }
                wp_clear_auth_cookie();
                wp_logout();
                return ApiResponse::success([
                    'logged_out' => true,
                    'redirect' => esc_url_raw(site_url('/crm-login/')),
                    'redirect_url' => esc_url_raw(site_url('/crm-login/')),
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        $me = new MeController();
        register_rest_route(self::NAMESPACE_V1, '/me', [
            'methods' => 'GET',
            'callback' => [$me, 'handle'],
            'permission_callback' => [$me, 'permissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/me/messenger', [
            'methods' => 'POST',
            'callback' => [$me, 'saveMessenger'],
            'permission_callback' => [$me, 'permissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/me/profile', [
            'methods' => 'POST',
            'callback' => [$me, 'saveProfile'],
            'permission_callback' => [$me, 'permissionCheck'],
        ]);

        $appData = new \AvinaCRM\Rest\Controllers\AppDataController();
        register_rest_route(self::NAMESPACE_V1, '/app-data', [
            [
                'methods' => 'GET',
                'callback' => [$appData, 'get'],
                'permission_callback' => [$appData, 'permissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$appData, 'save'],
                'permission_callback' => [$appData, 'permissionCheck'],
            ],
        ]);

        $system = new SystemController();
        register_rest_route(self::NAMESPACE_V1, '/system/status', [
            'methods' => 'GET',
            'callback' => [$system, 'handle'],
            'permission_callback' => [$system, 'permissionCheck'],
        ]);

        $operators = new OperatorsController();
        register_rest_route(self::NAMESPACE_V1, '/operators', [
            [
                'methods' => 'GET',
                'callback' => [$operators, 'list'],
                'permission_callback' => [$operators, 'listPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$operators, 'create'],
                'permission_callback' => [$operators, 'createPermissionCheck'],
                'args' => [
                    'full_name' => ['type' => 'string', 'required' => true],
                    'username' => ['type' => 'string', 'required' => true],
                    'email' => ['type' => 'string', 'required' => true, 'format' => 'email'],
                    'create_page' => ['type' => 'boolean', 'required' => false],
                ],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/operators/(?P<id>\d+)', [
            'methods' => ['POST', 'PUT'],
            'callback' => [$operators, 'update'],
            'permission_callback' => [$operators, 'createPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/operators/(?P<id>\d+)/permissions', [
            'methods' => 'POST',
            'callback' => [$operators, 'savePermissions'],
            'permission_callback' => [$operators, 'createPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/operators/(?P<id>\d+)/ensure-page', [
            'methods' => 'POST',
            'callback' => [$operators, 'ensurePage'],
            'permission_callback' => [$operators, 'listPermissionCheck'],
        ]);

        $this->registerTeamsRoutes();
        $this->registerContactsRoutes();
        $this->registerCustomersRoutes();
        $this->registerPhonebookRoutes();
        $this->registerReceptionRoutes();
        $this->registerActivitiesRoutes();
        $this->registerTasksRoutes();
        $this->registerRemindersRoutes();
        $this->registerNotificationsRoutes();
        $this->registerTicketsRoutes();
        $this->registerPipelinesRoutes();
        $this->registerDealsRoutes();
        $this->registerInvoicesRoutes();
        $this->registerPaymentsRoutes();
        $this->registerAnalyticsRoutes();
        $this->registerWebhooksRoutes();
        $this->registerBackupRoutes();
        $this->registerAuditLogRoutes();
        $this->registerCustomFieldsRoutes();
        $this->registerAiRoutes();
        $this->registerSettingsRoutes();
        $this->registerSmsRoutes();
    }

    private function registerAnalyticsRoutes(): void
    {
        $c = new AnalyticsController();

        register_rest_route(self::NAMESPACE_V1, '/analytics/dashboard', [
            'methods' => 'GET',
            'callback' => [$c, 'dashboard'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);
    }

    private function registerWebhooksRoutes(): void
    {
        $c = new WebhooksController();

        register_rest_route(self::NAMESPACE_V1, '/webhooks', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => [
                    'name' => ['type' => 'string', 'required' => true],
                    'target_url' => ['type' => 'string', 'required' => true],
                    'event_types' => ['required' => true],
                ],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/webhooks/(?P<id>\d+)', [
            'methods' => 'PATCH',
            'callback' => [$c, 'toggleActive'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/webhooks/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'deletePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/webhooks/(?P<id>\d+)/logs', [
            'methods' => 'GET',
            'callback' => [$c, 'logs'],
            'permission_callback' => [$c, 'viewPermissionCheck'],
        ]);
    }

    private function registerBackupRoutes(): void
    {
        $c = new BackupController();

        register_rest_route(self::NAMESPACE_V1, '/backup/export/json', [
            'methods' => 'GET',
            'callback' => [$c, 'exportJson'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/backup/export/csv', [
            'methods' => 'GET',
            'callback' => [$c, 'exportCsv'],
            'permission_callback' => [$c, 'permissionCheck'],
            'args' => ['table' => ['type' => 'string', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/backup/local', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'listLocal'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'createLocal'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/backup/local/(?P<filename>[a-zA-Z0-9_\-\.]+json)', [
            [
                'methods' => 'DELETE',
                'callback' => [$c, 'deleteLocal'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
            [
                'methods' => 'GET',
                'callback' => [$c, 'downloadLocal'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);
    }

    private function registerAuditLogRoutes(): void
    {
        $c = new AuditLogController();

        register_rest_route(self::NAMESPACE_V1, '/audit-log', [
            'methods' => 'GET',
            'callback' => [$c, 'list'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);
    }

    private function registerPipelinesRoutes(): void
    {
        $c = new PipelinesController();

        register_rest_route(self::NAMESPACE_V1, '/pipelines', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['name' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/pipelines/(?P<id>\d+)/stages', [
            'methods' => 'POST',
            'callback' => [$c, 'addStage'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['name' => ['type' => 'string', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/pipelines/(?P<id>\d+)/stages/reorder', [
            'methods' => 'POST',
            'callback' => [$c, 'reorderStages'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['stage_ids' => ['required' => true]],
        ]);
    }

    private function registerDealsRoutes(): void
    {
        $c = new DealsController();

        register_rest_route(self::NAMESPACE_V1, '/deals', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => [
                    'title' => ['type' => 'string', 'required' => true],
                    'pipeline_id' => ['type' => 'integer', 'required' => true],
                    'stage_id' => ['type' => 'integer', 'required' => true],
                ],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/deals/board', [
            'methods' => 'GET',
            'callback' => [$c, 'board'],
            'permission_callback' => [$c, 'viewPermissionCheck'],
            'args' => ['pipeline_id' => ['type' => 'integer', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/deals/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'get'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'PATCH',
                'callback' => [$c, 'update'],
                'permission_callback' => [$c, 'updatePermissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/deals/(?P<id>\d+)/stage', [
            'methods' => 'POST',
            'callback' => [$c, 'changeStage'],
            'permission_callback' => [$c, 'changeStagePermissionCheck'],
            'args' => ['stage_id' => ['type' => 'integer', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/deals/(?P<id>\d+)/archive', [
            'methods' => 'POST',
            'callback' => [$c, 'archive'],
            'permission_callback' => [$c, 'archivePermissionCheck'],
        ]);
    }

    private function registerInvoicesRoutes(): void
    {
        $c = new InvoicesController();

        register_rest_route(self::NAMESPACE_V1, '/invoices', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['items' => ['required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/invoices/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$c, 'get'],
            'permission_callback' => [$c, 'viewPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/invoices/(?P<id>\d+)/status', [
            'methods' => 'POST',
            'callback' => [$c, 'changeStatus'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['status' => ['type' => 'string', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/invoices/(?P<id>\d+)/void', [
            'methods' => 'POST',
            'callback' => [$c, 'void'],
            'permission_callback' => [$c, 'voidPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/invoices/(?P<id>\d+)/items', [
            'methods' => 'PUT',
            'callback' => [$c, 'updateItems'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['items' => ['required' => true]],
        ]);
    }

    private function registerPaymentsRoutes(): void
    {
        $c = new PaymentsController();

        register_rest_route(self::NAMESPACE_V1, '/invoices/(?P<id>\d+)/payments', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'record'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['amount' => ['type' => 'number', 'required' => true]],
            ],
        ]);
    }

    private function registerTeamsRoutes(): void
    {
        $c = new TeamsController();

        register_rest_route(self::NAMESPACE_V1, '/teams', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['name' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/teams/(?P<id>\d+)/members', [
            'methods' => 'POST',
            'callback' => [$c, 'addMember'],
            'permission_callback' => [$c, 'manageMembersPermissionCheck'],
            'args' => ['user_id' => ['type' => 'integer', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/teams/(?P<id>\d+)/members/(?P<user_id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$c, 'removeMember'],
            'permission_callback' => [$c, 'manageMembersPermissionCheck'],
        ]);
        register_rest_route(self::NAMESPACE_V1, '/teams/(?P<id>\d+)', [
            'methods' => 'PATCH',
            'callback' => [$c, 'update'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
        ]);
    }

    private function registerContactsRoutes(): void
    {
        $c = new ContactsController();

        register_rest_route(self::NAMESPACE_V1, '/contacts', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['full_name' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/export', [
            'methods' => 'GET',
            'callback' => [$c, 'export'],
            'permission_callback' => [$c, 'exportPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/delete', [
            'methods' => ['POST', 'DELETE', 'GET'],
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'deletePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>[a-zA-Z0-9_\-]+)', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'get'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => ['PATCH', 'POST'],
                'callback' => [$c, 'update'],
                'permission_callback' => [$c, 'updatePermissionCheck'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$c, 'delete'],
                'permission_callback' => [$c, 'deletePermissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>[a-zA-Z0-9_\-]+)/delete', [
            'methods' => ['POST', 'DELETE', 'GET'],
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'deletePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>[a-zA-Z0-9_\-]+)/archive', [
            'methods' => ['POST', 'DELETE', 'GET'],
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'deletePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>\d+)/convert', [
            'methods' => 'POST',
            'callback' => [$c, 'convert'],
            'permission_callback' => [$c, 'convertPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>\d+)/followups', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'getFollowups'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'addFollowup'],
                'permission_callback' => [$c, 'updatePermissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>\d+)/kanban', [
            'methods' => 'POST',
            'callback' => [$c, 'sendToKanban'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/contacts/(?P<id>\d+)/message', [
            'methods' => 'POST',
            'callback' => [$c, 'sendMessage'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
        ]);
    }

    private function registerCustomersRoutes(): void
    {
        $c = new CustomersController();

        register_rest_route(self::NAMESPACE_V1, '/customers', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['full_name' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/customers/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'get'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'PATCH',
                'callback' => [$c, 'update'],
                'permission_callback' => [$c, 'updatePermissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/customers/(?P<id>\d+)/archive', [
            'methods' => 'POST',
            'callback' => [$c, 'archive'],
            'permission_callback' => [$c, 'archivePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/customers/(?P<id>\d+)/notes', [
            'methods' => 'POST',
            'callback' => [$c, 'addNote'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['body' => ['type' => 'string', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/customers/export', [
            'methods' => 'GET',
            'callback' => [$c, 'export'],
            'permission_callback' => [$c, 'exportPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/customers/(?P<id>\d+)/purchase', [
            'methods' => 'POST',
            'callback' => [$c, 'addPurchase'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
        ]);
    }

    private function registerPhonebookRoutes(): void
    {
        $c = new PhonebookController();

        register_rest_route(self::NAMESPACE_V1, '/phonebook', [
            'methods' => 'GET',
            'callback' => [$c, 'search'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);
    }

    private function registerReceptionRoutes(): void
    {
        $c = new ReceptionController();

        register_rest_route(self::NAMESPACE_V1, '/reception', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'checkIn'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['visitor_name' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/reception/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'get'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'PATCH',
                'callback' => [$c, 'update'],
                'permission_callback' => [$c, 'updatePermissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/reception/(?P<id>\d+)/status', [
            'methods' => 'POST',
            'callback' => [$c, 'changeStatus'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['status' => ['type' => 'string', 'required' => true]],
        ]);
    }

    private function registerActivitiesRoutes(): void
    {
        $c = new ActivitiesController();

        register_rest_route(self::NAMESPACE_V1, '/activities', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['subject' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/activities/(?P<id>\d+)/complete', [
            'methods' => 'POST',
            'callback' => [$c, 'complete'],
            'permission_callback' => [$c, 'completePermissionCheck'],
        ]);
    }

    private function registerTasksRoutes(): void
    {
        $c = new TasksController();

        register_rest_route(self::NAMESPACE_V1, '/tasks', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['title' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/tasks/(?P<id>\d+)/status', [
            'methods' => 'POST',
            'callback' => [$c, 'updateStatus'],
            'permission_callback' => [$c, 'updatePermissionCheck'],
            'args' => ['status' => ['type' => 'string', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/tasks/(?P<id>[a-zA-Z0-9_\-]+)/delete', [
            'methods' => ['POST', 'DELETE', 'GET'],
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'deletePermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/tasks/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods' => ['DELETE'],
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'deletePermissionCheck'],
        ]);
    }

    private function registerRemindersRoutes(): void
    {
        $c = new RemindersController();

        register_rest_route(self::NAMESPACE_V1, '/reminders', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['title' => ['type' => 'string', 'required' => true], 'remind_at' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/reminders/(?P<id>\d+)/dismiss', [
            'methods' => 'POST',
            'callback' => [$c, 'dismiss'],
            'permission_callback' => [$c, 'dismissPermissionCheck'],
        ]);
    }

    private function registerNotificationsRoutes(): void
    {
        $c = new NotificationsController();

        register_rest_route(self::NAMESPACE_V1, '/notifications', [
            'methods' => 'GET',
            'callback' => [$c, 'list'],
            'permission_callback' => [$c, 'viewPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/notifications/(?P<id>\d+)/read', [
            'methods' => 'POST',
            'callback' => [$c, 'markRead'],
            'permission_callback' => [$c, 'markReadPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/notifications/read-all', [
            'methods' => 'POST',
            'callback' => [$c, 'markAllRead'],
            'permission_callback' => [$c, 'markReadPermissionCheck'],
        ]);
    }

    private function registerTicketsRoutes(): void
    {
        $c = new TicketsController();

        register_rest_route(self::NAMESPACE_V1, '/tickets', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'viewPermissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'create'],
                'permission_callback' => [$c, 'createPermissionCheck'],
                'args' => ['subject' => ['type' => 'string', 'required' => true], 'body' => ['type' => 'string', 'required' => true]],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/tickets/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$c, 'get'],
            'permission_callback' => [$c, 'viewPermissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/tickets/(?P<id>\d+)/replies', [
            'methods' => 'POST',
            'callback' => [$c, 'reply'],
            'permission_callback' => [$c, 'replyPermissionCheck'],
            'args' => ['body' => ['type' => 'string', 'required' => true]],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/tickets/(?P<id>\d+)/status', [
            'methods' => 'POST',
            'callback' => [$c, 'changeStatus'],
            'permission_callback' => [$c, 'statusPermissionCheck'],
            'args' => ['status' => ['type' => 'string', 'required' => true]],
        ]);
    }

    private function registerCustomFieldsRoutes(): void
    {
        $c = new \AvinaCRM\Rest\Controllers\CustomFieldsController();

        register_rest_route(self::NAMESPACE_V1, '/custom-fields', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'list'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'save'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/custom-fields/(?P<entity>[a-z_]+)/(?P<field_id>[a-z0-9_]+)', [
            'methods' => 'DELETE',
            'callback' => [$c, 'delete'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/form-settings/(?P<entity>[a-z_]+)', [
            'methods' => 'GET',
            'callback' => [$c, 'getFormSettings'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/form-settings', [
            'methods' => 'POST',
            'callback' => [$c, 'saveFormSettings'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);
    }

    private function registerAiRoutes(): void
    {
        $c = new \AvinaCRM\Rest\Controllers\AiController();

        register_rest_route(self::NAMESPACE_V1, '/ai/chat', [
            'methods' => 'POST',
            'callback' => [$c, 'chat'],
            'permission_callback' => [$c, 'permissionCheck'],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/ai/scan-document', [
            'methods' => 'POST',
            'callback' => [$c, 'scanDocument'],
            'permission_callback' => '__return_true',
        ]);
    }

    private function registerSettingsRoutes(): void
    {
        $c = new \AvinaCRM\Rest\Controllers\SettingsController();

        register_rest_route(self::NAMESPACE_V1, '/settings', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'getSettings'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'saveSettings'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/layout', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'getLayout'],
                'permission_callback' => 'is_user_logged_in',
            ],
            [
                'methods' => 'POST',
                'callback' => [$c, 'saveLayout'],
                'permission_callback' => 'is_user_logged_in',
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/kanban/tasks', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'getKanbanTasks'],
                'permission_callback' => 'is_user_logged_in',
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/kanban/tasks/(?P<id>\d+)/stage', [
            [
                'methods' => 'POST',
                'callback' => [$c, 'updateKanbanTaskStage'],
                'permission_callback' => 'is_user_logged_in',
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/products', [
            [
                'methods' => 'POST',
                'callback' => [$c, 'addProduct'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/products/(?P<id>\d+)', [
            [
                'methods' => 'DELETE',
                'callback' => [$c, 'deleteProduct'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/services', [
            [
                'methods' => 'POST',
                'callback' => [$c, 'addService'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/settings/services/(?P<id>\d+)', [
            [
                'methods' => 'DELETE',
                'callback' => [$c, 'deleteService'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);

        register_rest_route(self::NAMESPACE_V1, '/reception/export', [
            [
                'methods' => 'GET',
                'callback' => [$c, 'exportIntakes'],
                'permission_callback' => [$c, 'permissionCheck'],
            ],
        ]);
    }

    private function registerSmsRoutes(): void
    {
        register_rest_route(self::NAMESPACE_V1, '/sms/send', [
            'methods' => 'POST',
            'callback' => function (\WP_REST_Request $request) {
                $params = $request->get_json_params() ?? [];
                $recipientsInput = $params['recipients'] ?? ($params['recipient'] ?? []);
                if (is_string($recipientsInput)) {
                    $recipients = array_map('trim', explode(',', $recipientsInput));
                } elseif (is_array($recipientsInput)) {
                    $recipients = $recipientsInput;
                } else {
                    $recipients = [];
                }

                $message = (string) ($params['message'] ?? ($params['variables']['message'] ?? ''));
                $patternCode = sanitize_text_field((string)($params['pattern_code'] ?? ($params['patternCode'] ?? '')));
                $variables = is_array($params['variables'] ?? null) ? $params['variables'] : [];

                $appData = get_option('avina_crm_app_data', []);
                $smsSettings = $appData['settings']['sms'] ?? [];

                $apiKey = sanitize_text_field((string)($params['apiKey'] ?? ($smsSettings['apiKey'] ?? '')));
                $sender = sanitize_text_field((string)($params['sender'] ?? ($params['senderNumber'] ?? ($smsSettings['senderNumber'] ?? ''))));
                $authMode = sanitize_text_field((string)($params['authMode'] ?? ($smsSettings['authMode'] ?? 'apikey')));
                $username = sanitize_text_field((string)($params['username'] ?? ($smsSettings['username'] ?? '')));
                $password = sanitize_text_field((string)($params['password'] ?? ($smsSettings['password'] ?? '')));
                $sendTime = sanitize_text_field((string)($params['send_time'] ?? ($params['sendTime'] ?? ($params['time'] ?? ''))));
                $source = sanitize_text_field((string)($params['source'] ?? ''));

                $smsService = new \AvinaCRM\SMS\SmsService();
                $actorId = get_current_user_id();

                if (!empty($patternCode) && $patternCode !== 'custom') {
                    $result = $smsService->sendIpPanelPatternSms($apiKey, $sender, (string)(reset($recipients) ?: ''), $patternCode, $variables, $actorId, $authMode, $username, $password);
                } else {
                    $result = $smsService->sendIpPanelSms($apiKey, $sender, $recipients, $message, $actorId, $authMode, $username, $password, $sendTime, $source);
                }
                
                if (!empty($result['success'])) {
                    return ApiResponse::success($result);
                }
                
                $errMsg = !empty($result['error']) ? (string)$result['error'] : 'ارتباط با سامانه IPPanel برقرار نشد.';
                $errCode = !empty($result['code']) && is_numeric($result['code']) && $result['code'] >= 400 && $result['code'] < 600 ? (int)$result['code'] : 400;
                return ApiResponse::error('sms_send_failed', $errMsg, $errCode, $result);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/sms/cancel-scheduled', [
            'methods' => 'POST',
            'callback' => function (\WP_REST_Request $request) {
                $params = $request->get_json_params() ?? [];
                $phone = sanitize_text_field((string)($params['phone'] ?? ($params['mobile'] ?? '')));
                $source = sanitize_text_field((string)($params['source'] ?? ''));

                $smsService = new \AvinaCRM\SMS\SmsService();
                $cancelledCount = $smsService->cancelScheduledSmsByPhone($phone, $source);
                return ApiResponse::success([
                    'cancelled' => $cancelledCount,
                    'message' => 'پیام‌های زمان‌بندی شده با موفقیت لغو شدند.'
                ]);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/sms/add-phonebook-contact', [
            'methods' => 'POST',
            'callback' => function (\WP_REST_Request $request) {
                $params = $request->get_json_params() ?? [];
                $name = sanitize_text_field((string)($params['name'] ?? ($params['first_name'] ?? '')));
                $phone = sanitize_text_field((string)($params['phone'] ?? ($params['mobile'] ?? ($params['number'] ?? ''))));

                $appData = get_option('avina_crm_app_data', []);
                $smsSettings = $appData['settings']['sms'] ?? [];

                $apiKey = sanitize_text_field((string)($params['apiKey'] ?? ($smsSettings['apiKey'] ?? '')));
                $phonebookId = sanitize_text_field((string)($params['phonebookId'] ?? ($params['phonebook_id'] ?? ($smsSettings['phonebookId'] ?? ''))));

                $smsService = new \AvinaCRM\SMS\SmsService();
                $actorId = get_current_user_id();

                $result = $smsService->addPhonebookContact($apiKey, $phonebookId, $name, $phone, $actorId);
                
                if (!empty($result['success'])) {
                    return ApiResponse::success($result);
                }

                $errMsg = !empty($result['error']) ? (string)$result['error'] : 'افزودن مخاطب به دفترچه تلفن IPPanel با خطا مواجه شد.';
                $errCode = !empty($result['code']) && is_numeric($result['code']) && $result['code'] >= 400 && $result['code'] < 600 ? (int)$result['code'] : 400;
                return ApiResponse::error('phonebook_add_failed', $errMsg, $errCode, $result);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/sms/logs', [
            'methods' => 'GET',
            'callback' => function (\WP_REST_Request $request) {
                $smsService = new \AvinaCRM\SMS\SmsService();
                $smsService->processScheduledSmsQueue();
                $logs = $smsService->getSmsLogs(150);
                return ApiResponse::success($logs);
            },
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_V1, '/sms/logs', [
            'methods' => 'DELETE',
            'callback' => function (\WP_REST_Request $request) {
                $params = $request->get_json_params() ?? [];
                $ids = is_array($params['ids'] ?? null) ? $params['ids'] : null;
                $smsService = new \AvinaCRM\SMS\SmsService();
                $deleted = $smsService->deleteSmsLogs($ids);
                return ApiResponse::success(['deleted' => $deleted, 'message' => 'گزارش‌های پیامک با موفقیت پاکسازی شدند.']);
            },
            'permission_callback' => '__return_true',
        ]);
    }
}
