<?php

declare(strict_types=1);

namespace AvinaCRM\Pipelines;

use AvinaCRM\Audit\AuditLogger;
use WP_Error;

final class PipelineService
{
    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function list(bool $includeArchived = false): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipelines';
        $where = $includeArchived ? '1=1' : 'is_archived = 0';

        $pipelines = $wpdb->get_results("SELECT * FROM {$table} WHERE {$where} ORDER BY name ASC", ARRAY_A);

        foreach ($pipelines as &$pipeline) {
            $pipeline['id'] = (int) $pipeline['id'];
            $pipeline['stages'] = $this->stagesOf((int) $pipeline['id']);
        }
        unset($pipeline);

        return $pipelines ?: [];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function stagesOf(int $pipelineId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipeline_stages';

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE pipeline_id = %d AND is_archived = 0 ORDER BY sort_order ASC",
                $pipelineId
            ),
            ARRAY_A
        );

        return array_map(static function (array $row): array {
            $row['id'] = (int) $row['id'];
            $row['pipeline_id'] = (int) $row['pipeline_id'];
            $row['sort_order'] = (int) $row['sort_order'];
            $row['win_probability'] = (int) $row['win_probability'];
            $row['is_won'] = (bool) $row['is_won'];
            $row['is_lost'] = (bool) $row['is_lost'];

            return $row;
        }, $rows ?: []);
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function createPipeline(string $name, int $actorUserId)
    {
        $name = sanitize_text_field($name);

        if ($name === '') {
            return new WP_Error('avina_crm_invalid_pipeline', __('نام پایپ‌لاین الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipelines';

        $wpdb->insert(
            $table,
            [
                'name' => $name,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'pipelines.pipeline.create', 'pipeline', (string) $id, null, ['name' => $name]);

        return ['id' => $id];
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function addStage(int $pipelineId, array $data, int $actorUserId)
    {
        if (!$this->pipelineExists($pipelineId)) {
            return new WP_Error('avina_crm_pipeline_not_found', __('پایپ‌لاین موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $name = sanitize_text_field($data['name'] ?? '');

        if ($name === '') {
            return new WP_Error('avina_crm_invalid_stage', __('نام مرحله الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $winProbability = max(0, min(100, (int) ($data['win_probability'] ?? 0)));
        $color = $this->sanitizeColor($data['color'] ?? '#94a3b8');

        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipeline_stages';

        $maxOrder = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COALESCE(MAX(sort_order), -1) FROM {$table} WHERE pipeline_id = %d", $pipelineId)
        );

        $wpdb->insert(
            $table,
            [
                'pipeline_id' => $pipelineId,
                'name' => $name,
                'sort_order' => $maxOrder + 1,
                'win_probability' => $winProbability,
                'color' => $color,
                'is_won' => !empty($data['is_won']) ? 1 : 0,
                'is_lost' => !empty($data['is_lost']) ? 1 : 0,
                'is_archived' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%d', '%d', '%s', '%d', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'pipelines.stage.create', 'pipeline_stage', (string) $id, null, ['name' => $name, 'pipeline_id' => $pipelineId]);

        return ['id' => $id];
    }

    /**
     * Re-sequences a pipeline's stages to match the given ordered list of
     * stage IDs — used by the Kanban board's column-reordering UI.
     *
     * @param array<int, int> $orderedStageIds
     * @return true|WP_Error
     */
    public function reorderStages(int $pipelineId, array $orderedStageIds, int $actorUserId)
    {
        if (!$this->pipelineExists($pipelineId)) {
            return new WP_Error('avina_crm_pipeline_not_found', __('پایپ‌لاین موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipeline_stages';

        foreach (array_values($orderedStageIds) as $index => $stageId) {
            $wpdb->update(
                $table,
                ['sort_order' => $index, 'updated_at' => current_time('mysql')],
                ['id' => (int) $stageId, 'pipeline_id' => $pipelineId],
                ['%d', '%s'],
                ['%d', '%d']
            );
        }

        $this->audit->record($actorUserId, 'pipelines.stage.reorder', 'pipeline', (string) $pipelineId, null, ['order' => $orderedStageIds]);

        return true;
    }

    public function pipelineExists(int $pipelineId): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipelines';

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE id = %d AND is_archived = 0", $pipelineId)) > 0;
    }

    public function stageExists(int $stageId, ?int $pipelineId = null): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipeline_stages';

        if ($pipelineId !== null) {
            return (int) $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE id = %d AND pipeline_id = %d AND is_archived = 0", $stageId, $pipelineId)
            ) > 0;
        }

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE id = %d AND is_archived = 0", $stageId)) > 0;
    }

    public function findStage(int $stageId): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_pipeline_stages';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $stageId), ARRAY_A);

        return $row ?: null;
    }

    private function sanitizeColor(string $color): string
    {
        $color = sanitize_text_field($color);

        return preg_match('/^#[0-9a-fA-F]{3,8}$/', $color) ? $color : '#94a3b8';
    }
}
