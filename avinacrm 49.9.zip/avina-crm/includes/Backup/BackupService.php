<?php

declare(strict_types=1);

namespace AvinaCRM\Backup;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Support\Csv;

/**
 * Exports CRM business tables only, via an explicit allowlist —
 * deliberately NOT a generic "dump any table" tool. This means the
 * webhooks table (which holds HMAC secrets), wp_options (which may hold
 * the encrypted webhook settings or other secrets), and any WordPress
 * core table (wp_users password hashes, wp_usermeta session tokens) can
 * never be reached through this class no matter what table name is
 * requested — they are simply not in the allowlist, so there is no
 * runtime check to bypass.
 */
final class BackupService
{
    /** @var array<string, string> exportable-key => real table suffix */
    private const EXPORTABLE_TABLES = [
        'contacts' => 'avina_contacts',
        'customers' => 'avina_customers',
        'receptions' => 'avina_receptions',
        'activities' => 'avina_activities',
        'tasks' => 'avina_tasks',
        'reminders' => 'avina_reminders',
        'teams' => 'avina_teams',
        'tickets' => 'avina_tickets',
        'pipelines' => 'avina_pipelines',
        'deals' => 'avina_deals',
        'invoices' => 'avina_invoices',
        'invoice_items' => 'avina_invoice_items',
        'payments' => 'avina_payments',
    ];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public static function exportableTableKeys(): array
    {
        return array_keys(self::EXPORTABLE_TABLES);
    }

    /**
     * @param array<int, string> $tableKeys
     * @return array<string, array<int, array<string, mixed>>>
     */
    public function collect(array $tableKeys, int $actorUserId): array
    {
        global $wpdb;

        $tableKeys = array_values(array_intersect($tableKeys, self::exportableTableKeys()));

        if (empty($tableKeys)) {
            $tableKeys = self::exportableTableKeys();
        }

        $result = [];

        foreach ($tableKeys as $key) {
            $table = $wpdb->prefix . self::EXPORTABLE_TABLES[$key];
            $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE 1=1 LIMIT 50000", ARRAY_A);
            $result[$key] = $rows ?: [];
        }

        $this->audit->record($actorUserId, 'backup.export.download', 'export', null, null, ['tables' => $tableKeys, 'format' => 'json']);

        return $result;
    }

    /**
     * Streams a JSON export directly and exits.
     *
     * @param array<int, string> $tableKeys
     */
    public function streamJson(array $tableKeys, int $actorUserId): void
    {
        $data = $this->collect($tableKeys, $actorUserId);

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="avina-crm-export-' . gmdate('Ymd-His') . '.json"');

        echo wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

    /**
     * Streams a single table as CSV — reuses AvinaCRM\Support\Csv, so
     * formula-injection sanitization applies to every cell exactly as it
     * does for the Contacts CSV export in Stage 3.
     */
    public function streamCsv(string $tableKey, int $actorUserId): void
    {
        if (!in_array($tableKey, self::exportableTableKeys(), true)) {
            wp_die(esc_html__('جدول درخواستی برای خروجی مجاز نیست.', 'avina-crm'));
        }

        $rows = $this->collect([$tableKey], $actorUserId)[$tableKey];

        if (empty($rows)) {
            Csv::streamDownload("avina-crm-{$tableKey}.csv", [], []);
            return;
        }

        $headers = array_keys($rows[0]);
        $csvRows = array_map(static fn (array $row): array => array_values($row), $rows);

        Csv::streamDownload("avina-crm-{$tableKey}.csv", $headers, $csvRows);
    }

    private function getBackupDir(): string
    {
        $dir = AVINA_CRM_DIR . 'backups/';
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
            // Create security files
            file_put_contents($dir . '.htaccess', "Deny from all\n");
            file_put_contents($dir . 'index.html', "");
        }
        return $dir;
    }

    public function listLocalBackups(): array
    {
        $dir = $this->getBackupDir();
        $files = glob($dir . '*.json');
        $backups = [];
        if (is_array($files)) {
            foreach ($files as $file) {
                $backups[] = [
                    'filename' => basename($file),
                    'size' => filesize($file),
                    'created_at' => date('Y-m-d H:i:s', filemtime($file)),
                ];
            }
        }
        usort($backups, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
        return $backups;
    }

    public function createLocalBackup(int $actorUserId): array
    {
        $data = $this->collect([], $actorUserId);
        $filename = 'backup-' . gmdate('Ymd-His') . '.json';
        $dir = $this->getBackupDir();
        $filePath = $dir . $filename;
        file_put_contents($filePath, wp_json_encode($data, JSON_UNESCAPED_UNICODE));
        
        $this->audit->record($actorUserId, 'backup.local.create', 'backup', $filename, null, ['filename' => $filename]);

        return [
            'filename' => $filename,
            'size' => filesize($filePath),
            'created_at' => date('Y-m-d H:i:s', filemtime($filePath)),
        ];
    }

    public function deleteLocalBackup(string $filename, int $actorUserId): bool
    {
        if (!preg_match('/^backup-[0-9]{8}-[0-9]{6}\.json$/', $filename)) {
            return false;
        }
        $dir = $this->getBackupDir();
        $filePath = $dir . $filename;
        if (file_exists($filePath)) {
            unlink($filePath);
            $this->audit->record($actorUserId, 'backup.local.delete', 'backup', $filename, null, ['filename' => $filename]);
            return true;
        }
        return false;
    }

    public function downloadLocalBackup(string $filename, int $actorUserId): void
    {
        if (!preg_match('/^backup-[0-9]{8}-[0-9]{6}\.json$/', $filename)) {
            wp_die(esc_html__('نام فایل نامعتبر است.', 'avina-crm'));
        }
        $dir = $this->getBackupDir();
        $filePath = $dir . $filename;
        if (!file_exists($filePath)) {
            wp_die(esc_html__('فایل موردنظر یافت نشد.', 'avina-crm'));
        }

        $this->audit->record($actorUserId, 'backup.local.download', 'backup', $filename, null, ['filename' => $filename]);

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . esc_attr($filename) . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }
}
