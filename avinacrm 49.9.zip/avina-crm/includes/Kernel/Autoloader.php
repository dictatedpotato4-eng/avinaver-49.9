<?php

declare(strict_types=1);

namespace AvinaCRM\Kernel;

/**
 * Minimal PSR-4-style autoloader. No Composer dependency, so the plugin
 * installs cleanly on shared cPanel hosting with nothing beyond PHP
 * itself. Namespace root `AvinaCRM\` maps to /includes.
 *
 * This mirrors the exact pattern already proven in the legacy
 * application's own bootstrap.php, ported unchanged in spirit.
 */
final class Autoloader
{
    private static bool $registered = false;

    public static function register(): void
    {
        if (self::$registered) {
            return;
        }

        spl_autoload_register(static function (string $class): void {
            $prefix = 'AvinaCRM\\';

            if (strncmp($prefix, $class, strlen($prefix)) !== 0) {
                return;
            }

            $relativeClass = substr($class, strlen($prefix));
            $path = AVINA_CRM_DIR . 'includes' . DIRECTORY_SEPARATOR
                . str_replace('\\', DIRECTORY_SEPARATOR, $relativeClass) . '.php';

            if (is_file($path)) {
                require $path;
            }
        });

        self::$registered = true;
    }
}
