<?php

declare(strict_types=1);

namespace AvinaCRM\Support;

/**
 * Melodify Music Catalog & Streaming Service Provider
 * Provides curated playlists, artists, reels, and track metadata matching the Melodify ecosystem.
 */
final class MelodifyCatalog
{
    /**
     * @return array<int, array<string, mixed>>
     */
    public static function getAllTracks(): array
    {
        return [
            [
                'id' => 'track-0',
                'title' => 'منو داری',
                'artist' => 'ناصر زینلی',
                'genre' => 'پاپ احساسی فارسی',
                'category' => 'pop',
                'duration' => '03:15',
                'durationSec' => 195,
                'tempo' => 88,
                'streamUrl' => 'https://dl.rozmusic.com/Music/1405/06/29/Naser%20Zeynali%20-%20Mano%20Dari%20%28128%29.mp3',
                'coverEmoji' => '🎙️',
                'coverImage' => 'https://rozmusic.com/wp-content/uploads/2026/09/Naser-Zeynali-Mano-Dari-300x300.jpg',
            ],
            [
                'id' => 'track-1',
                'title' => 'قرص قمر',
                'artist' => 'بهنام بانی',
                'genre' => 'پاپ شاد و انرژی‌بخش',
                'category' => 'party',
                'duration' => '03:20',
                'durationSec' => 200,
                'tempo' => 110,
                'streamUrl' => 'https://dl.rozmusic.com/Music/1396/11/15/Behnam%20Bani%20-%20Ghorse%20Ghamar%20(128).mp3',
                'coverEmoji' => '🌙',
                'coverImage' => 'https://rozmusic.com/wp-content/uploads/2018/02/Behnam-Bani-Ghorse-Ghamar.jpg',
            ],
            [
                'id' => 'track-2',
                'title' => 'نصف شب (ریمیکس)',
                'artist' => 'علی یاسینی',
                'genre' => 'پاپ ترند شبکه‌های اجتماعی',
                'category' => 'trending',
                'duration' => '03:30',
                'durationSec' => 210,
                'tempo' => 95,
                'streamUrl' => 'https://dl.rozmusic.com/Music/1402/03/12/Ali%20Yasini%20-%20Nesfe%20Shab%20%28Remix%29%20%28128%29.mp3',
                'coverEmoji' => '🌌',
                'coverImage' => 'https://rozmusic.com/wp-content/uploads/2023/06/Ali-Yasini-Nesfe-Shab-Remix.jpg',
            ],
            [
                'id' => 'track-3',
                'title' => 'گل عشق',
                'artist' => 'رضا بهرام',
                'genre' => 'پاپ تلفیقی و عاشقانه',
                'category' => 'pop',
                'duration' => '03:10',
                'durationSec' => 190,
                'tempo' => 84,
                'streamUrl' => 'https://dl.rozmusic.com/Music/1398/02/08/Reza%20Bahram%20-%20Gole%20Eshgh%20(128).mp3',
                'coverEmoji' => '🌹',
                'coverImage' => 'https://rozmusic.com/wp-content/uploads/2019/04/Reza-Bahram-Gole-Eshgh.jpg',
            ],
            [
                'id' => 'track-4',
                'title' => 'بهت قول میدم',
                'artist' => 'محسن یگانه',
                'genre' => 'نوستالژی پاپ ماندگار',
                'category' => 'nostalgia',
                'duration' => '03:40',
                'durationSec' => 220,
                'tempo' => 80,
                'streamUrl' => 'https://dl.rozmusic.com/Music/1396/01/14/Mohsen%20Yeganeh%20-%20Behet%20Ghol%20Midam%20%28128%29.mp3',
                'coverEmoji' => '🎸',
                'coverImage' => 'https://rozmusic.com/wp-content/uploads/2017/04/Mohsen-Yeganeh-Behet-Ghol-Midam.jpg',
            ],
            [
                'id' => 'track-5',
                'title' => 'ناخدا',
                'artist' => 'ماکان بند',
                'genre' => 'پاپ احساسی و دراماتیک',
                'category' => 'pop',
                'duration' => '03:15',
                'durationSec' => 195,
                'tempo' => 82,
                'streamUrl' => 'https://dl.rozmusic.com/Music/1398/07/10/Macan%20Band%20-%20Nakhoda%20%28128%29.mp3',
                'coverEmoji' => '⛵',
                'coverImage' => 'https://rozmusic.com/wp-content/uploads/2019/10/Macan-Band-Nakhoda.jpg',
            ],
            [
                'id' => 'track-6',
                'title' => 'صدای کافه برای تمرکز کاری',
                'artist' => 'کافه اسپرسو (Ambient Focus)',
                'genre' => 'امبینت کافه و کار عمیق',
                'category' => 'ambient',
                'duration' => '04:15',
                'durationSec' => 255,
                'tempo' => 70,
                'streamUrl' => 'https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg',
                'coverEmoji' => '☕',
                'coverImage' => 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=400&q=80',
            ],
            [
                'id' => 'track-7',
                'title' => 'گیتار آکوستیک ملایم برای مذاکره و فروش',
                'artist' => 'آکوستیک پرو (Gentle Acoustic)',
                'genre' => 'گیتار آکوستیک شرکتی',
                'category' => 'jazz',
                'duration' => '03:40',
                'durationSec' => 220,
                'tempo' => 78,
                'streamUrl' => 'https://stream.zeno.fm/k2k040v4d8uv',
                'coverEmoji' => '🎸',
                'coverImage' => 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=400&q=80',
            ],
            [
                'id' => 'track-8',
                'title' => 'پیانو بلورین و کهکشان آرام',
                'artist' => 'کازمیک استار (Crystal Piano)',
                'genre' => 'پیانو سینماتیک ملایم',
                'category' => 'piano',
                'duration' => '04:25',
                'durationSec' => 265,
                'tempo' => 74,
                'streamUrl' => 'https://stream.zeno.fm/75n2ubd8g8uv',
                'coverEmoji' => '✨',
                'coverImage' => 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=400&q=80',
            ],
            [
                'id' => 'track-9',
                'title' => 'رادیو جوان چیل و کافه لانژ',
                'artist' => 'آوینا لانژ (Chill Lounge)',
                'genre' => 'کافه لانژ و الکترونیک لایت',
                'category' => 'persian',
                'duration' => '04:50',
                'durationSec' => 290,
                'tempo' => 82,
                'streamUrl' => 'https://stream.zeno.fm/5y3y7792kwzuv',
                'coverEmoji' => '🎧',
                'coverImage' => 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&q=80',
            ],
            [
                'id' => 'track-10',
                'title' => 'لوفای شبانه کیبورد رودز',
                'artist' => 'میدنایت کیز (Midnight Rhodes)',
                'genre' => 'لوفای رودز شبانه',
                'category' => 'lofi',
                'duration' => '03:52',
                'durationSec' => 232,
                'tempo' => 75,
                'streamUrl' => 'https://icecast.skyrock.net/s/lofi_aac_64k',
                'coverEmoji' => '🌙',
                'coverImage' => 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&q=80',
            ],
            [
                'id' => 'track-11',
                'title' => 'فرکانس آلفا برای تمرکز هوشمند',
                'artist' => 'برین‌ویو فوکوس (Alpha Waves)',
                'genre' => 'فرکانس مطالعه و یادگیری',
                'category' => 'ambient',
                'duration' => '06:00',
                'durationSec' => 360,
                'tempo' => 65,
                'streamUrl' => 'https://stream.zeno.fm/dbv7u9644hhvv',
                'coverEmoji' => '🧠',
                'coverImage' => 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=400&q=80',
            ],
            [
                'id' => 'track-12',
                'title' => 'عصرانه در کافه سن‌ژرمن',
                'artist' => 'فرنچ بیسترو (Parisian Cafe)',
                'genre' => 'کافه جاز فرانسوی',
                'category' => 'jazz',
                'duration' => '04:15',
                'durationSec' => 255,
                'tempo' => 84,
                'streamUrl' => 'https://stream.zeno.fm/3b0w2e7751zuv',
                'coverEmoji' => '☕',
                'coverImage' => 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=400&q=80',
            ]
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function getTracks(string $category = 'all'): array
    {
        $all = self::getAllTracks();
        if ($category === 'all' || empty($category)) {
            return $all;
        }
        return array_values(array_filter($all, static fn(array $t): bool => ($t['category'] ?? '') === $category));
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function search(string $query): array
    {
        $q = mb_strtolower(trim($query));
        if ($q === '') {
            return self::getAllTracks();
        }
        return array_values(array_filter(self::getAllTracks(), static function (array $t) use ($q): bool {
            $haystack = mb_strtolower(($t['title'] ?? '') . ' ' . ($t['artist'] ?? '') . ' ' . ($t['genre'] ?? ''));
            return str_contains($haystack, $q);
        }));
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function getPlaylists(): array
    {
        return [
            [
                'id' => 'pl-1',
                'title' => 'Instagram & TikTok Trends',
                'description' => 'محبوب‌ترین ترندهای وایرال شبکه‌های اجتماعی',
                'count' => '۱۸۸۹ آهنگ',
                'trackCount' => 1889,
                'cover' => 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&q=80',
                'trackId' => 'track-0',
            ],
            [
                'id' => 'pl-2',
                'title' => 'نوستالژی شاد',
                'description' => 'خاطره‌انگیزترین ترانه‌های انرژی‌بخش فارسی',
                'count' => '۷۳ آهنگ',
                'trackCount' => 73,
                'cover' => 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=300&q=80',
                'trackId' => 'track-4',
            ],
            [
                'id' => 'pl-3',
                'title' => 'Bests Of Global',
                'description' => 'برترین قطعات برگزیده موزیک بی‌کلام بین‌المللی',
                'count' => '۱۴۰۹ آهنگ',
                'trackCount' => 1409,
                'cover' => 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&q=80',
                'trackId' => 'track-1',
            ],
            [
                'id' => 'pl-4',
                'title' => 'کافه پیانو و کار عمیق',
                'description' => 'نوای آرام کلاویه‌ها جهت تمرکز و مطالعه',
                'count' => '۲۵۰ آهنگ',
                'trackCount' => 250,
                'cover' => 'https://images.unsplash.com/photo-1520523839898-507127053c37?w=300&q=80',
                'trackId' => 'track-8',
            ],
            [
                'id' => 'pl-5',
                'title' => 'لوفای بارانی پشت شیشه',
                'description' => 'بیت‌های ریتمیک چیل‌هاپ برای فریلنسرها و دفاتر کار',
                'count' => '۱۸۰ آهنگ',
                'trackCount' => 180,
                'cover' => 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=300&q=80',
                'trackId' => 'track-6',
            ]
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function getArtists(): array
    {
        return [
            ['id' => 'art-1', 'name' => 'ناصر زینلی', 'genre' => 'پاپ احساسی', 'avatar' => 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&q=80', 'tracksCount' => 24, 'trackId' => 'track-0'],
            ['id' => 'art-2', 'name' => 'لودویکو اینائودی', 'genre' => 'پیانو نئوکلاسیک', 'avatar' => 'https://images.unsplash.com/photo-1520523839898-507127053c37?w=300&q=80', 'tracksCount' => 85, 'trackId' => 'track-1'],
            ['id' => 'art-3', 'name' => 'ییروما (Yiruma)', 'genre' => 'پیانو معاصر', 'avatar' => 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=300&q=80', 'tracksCount' => 64, 'trackId' => 'track-8'],
            ['id' => 'art-4', 'name' => 'فریبرز لاچینی', 'genre' => 'پاییز طلایی و سنتی', 'avatar' => 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&q=80', 'tracksCount' => 92, 'trackId' => 'track-4'],
            ['id' => 'art-5', 'name' => 'لوفای گرل (Lofi Girl)', 'genre' => 'بیت‌های مطالعه', 'avatar' => 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=300&q=80', 'tracksCount' => 320, 'trackId' => 'track-2'],
            ['id' => 'art-6', 'name' => 'هانس زیمر', 'genre' => 'موسیقی متن سینما', 'avatar' => 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&q=80', 'tracksCount' => 110, 'trackId' => 'track-7'],
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function getReels(): array
    {
        return [
            ['id' => 'reel-1', 'title' => 'پیانو سینمایی', 'artist' => 'کهکشان آرام', 'cover' => 'https://images.unsplash.com/photo-1520523839898-507127053c37?w=300&q=80', 'trackId' => 'track-1'],
            ['id' => 'reel-2', 'title' => 'کافه بارانی', 'artist' => 'لوفای ملایم', 'cover' => 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=300&q=80', 'trackId' => 'track-6'],
            ['id' => 'reel-3', 'title' => 'جاز عصرگاهی', 'artist' => 'گیتار آکوستیک', 'cover' => 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=300&q=80', 'trackId' => 'track-7'],
            ['id' => 'reel-4', 'title' => 'امبینت اقیانوس', 'artist' => 'نسیم ساحل', 'cover' => 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&q=80', 'trackId' => 'track-5'],
            ['id' => 'reel-5', 'title' => 'سنتی و ارینتال', 'artist' => 'سازهای اصیل', 'cover' => 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&q=80', 'trackId' => 'track-4'],
        ];
    }
}
