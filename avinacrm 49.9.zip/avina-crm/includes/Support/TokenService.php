<?php

declare(strict_types=1);

namespace AvinaCRM\Support;

/**
 * Robust CRM Authentication Token Service.
 *
 * Provides long-lived, server-verified tokens (X-Avina-Token) for SPA
 * interactions, bypassing transient WordPress REST nonce expirations and
 * cross-browser cookie restrictions across Chrome, Safari, and other devices.
 */
final class TokenService
{
    private const OPTION_NAME = 'avina_crm_auth_tokens';
    private const TOKEN_LIFETIME = 30 * DAY_IN_SECONDS; // 30 days

    /**
     * Generate and store a new CRM auth token for the given user.
     */
    public static function generateToken(int $userId): string
    {
        if ($userId <= 0) {
            return '';
        }

        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);

        $tokens = self::getAllTokens();
        $tokens[$tokenHash] = [
            'user_id' => $userId,
            'created_at' => time(),
            'expires_at' => time() + self::TOKEN_LIFETIME,
        ];

        // Maintain token pool size (max 200 active tokens across site)
        if (count($tokens) > 200) {
            $tokens = array_slice($tokens, -200, null, true);
        }

        update_option(self::OPTION_NAME, $tokens, false);
        update_user_meta($userId, 'avina_crm_latest_token', $rawToken);

        return $rawToken;
    }

    /**
     * Retrieve an existing valid token for the user or generate a fresh one.
     */
    public static function getOrGenerateToken(int $userId): string
    {
        if ($userId <= 0) {
            return '';
        }

        $existing = (string) get_user_meta($userId, 'avina_crm_latest_token', true);
        if (!empty($existing) && self::validateToken($existing) === $userId) {
            return $existing;
        }

        return self::generateToken($userId);
    }

    /**
     * Validate a token and return the associated WordPress user ID (>0), or 0 if invalid.
     */
    public static function validateToken(string $rawToken): int
    {
        $rawToken = trim($rawToken);
        if (empty($rawToken) || strlen($rawToken) < 32) {
            return 0;
        }

        $tokenHash = hash('sha256', $rawToken);
        $tokens = self::getAllTokens();

        if (!isset($tokens[$tokenHash])) {
            return 0;
        }

        $data = $tokens[$tokenHash];
        $userId = (int) ($data['user_id'] ?? 0);
        $expiresAt = (int) ($data['expires_at'] ?? 0);

        if ($userId <= 0 || time() > $expiresAt) {
            unset($tokens[$tokenHash]);
            update_option(self::OPTION_NAME, $tokens, false);
            return 0;
        }

        return $userId;
    }

    /**
     * Revoke a token explicitly upon logout.
     */
    public static function revokeToken(string $rawToken): void
    {
        $rawToken = trim($rawToken);
        if (empty($rawToken)) {
            return;
        }

        $tokenHash = hash('sha256', $rawToken);
        $tokens = self::getAllTokens();

        if (isset($tokens[$tokenHash])) {
            unset($tokens[$tokenHash]);
            update_option(self::OPTION_NAME, $tokens, false);
        }
    }

    /**
     * Helper to retrieve all active tokens, purging any expired tokens on read.
     */
    private static function getAllTokens(): array
    {
        $tokens = get_option(self::OPTION_NAME, []);
        if (!is_array($tokens)) {
            $tokens = [];
        }

        $now = time();
        $cleaned = false;
        foreach ($tokens as $hash => $data) {
            if (!is_array($data) || empty($data['expires_at']) || $now > $data['expires_at']) {
                unset($tokens[$hash]);
                $cleaned = true;
            }
        }

        if ($cleaned) {
            update_option(self::OPTION_NAME, $tokens, false);
        }

        return $tokens;
    }
}
