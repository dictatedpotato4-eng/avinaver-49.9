<?php

declare(strict_types=1);

namespace AvinaCRM\Support;

/**
 * Formula-injection prevention: any cell value beginning with =, +, -, @,
 * tab, or carriage return is prefixed with a leading single quote before
 * being written. Spreadsheet applications (Excel, LibreOffice Calc,
 * Google Sheets) treat a leading quote as "this is text, do not
 * evaluate", neutralizing a value like `=cmd|'/c calc'!A1` that a
 * malicious contact name/phone/email could otherwise contain.
 */
final class Csv
{
    private const DANGEROUS_PREFIXES = ['=', '+', '-', '@', "\t", "\r"];

    public static function sanitizeCell($value): string
    {
        $value = (string) $value;

        if ($value === '') {
            return '';
        }

        foreach (self::DANGEROUS_PREFIXES as $prefix) {
            if (str_starts_with($value, $prefix)) {
                return "'" . $value;
            }
        }

        return $value;
    }

    /**
     * Streams a CSV response directly and exits — used from a REST
     * controller's callback right before returning, since a REST
     * response object cannot itself carry raw file bytes/headers in the
     * shape a browser download needs.
     *
     * @param array<int, string> $headers
     * @param array<int, array<int, mixed>> $rows
     */
    public static function streamDownload(string $filename, array $headers, array $rows): void
    {
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . rawurlencode($filename) . '"');

        // UTF-8 BOM so Excel on Windows correctly detects Persian text.
        echo "\xEF\xBB\xBF";

        $out = fopen('php://output', 'w');

        fputcsv($out, array_map([self::class, 'sanitizeCell'], $headers));

        foreach ($rows as $row) {
            fputcsv($out, array_map([self::class, 'sanitizeCell'], $row));
        }

        fclose($out);
    }
}
