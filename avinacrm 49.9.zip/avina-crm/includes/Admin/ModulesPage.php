<?php

declare(strict_types=1);

namespace AvinaCRM\Admin;

final class ModulesPage
{
    public const SLUG = 'avina-crm-modules';

    public function render(): void
    {
        if (!current_user_can('module-manager.module.view')) {
            wp_die(esc_html__('شما اجازه دسترسی به این صفحه را ندارید.', 'avina-crm'));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_modules';
        $modules = $wpdb->get_results("SELECT slug, name_fa, is_core, is_active FROM {$table} ORDER BY sort_order ASC", ARRAY_A);

        echo '<div class="wrap" dir="rtl">';
        echo '<h1>' . esc_html__('ماژول‌های آوینا CRM', 'avina-crm') . '</h1>';
        echo '<p>' . esc_html__('این فهرست، معماری کامل ماژول‌های برنامه‌ریزی‌شده را نشان می‌دهد. پیاده‌سازی هر ماژول در مرحله اختصاصی خود انجام می‌شود و پیش از آن هیچ عملکردی ارائه نمی‌دهد.', 'avina-crm') . '</p>';

        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>' . esc_html__('ماژول', 'avina-crm') . '</th>';
        echo '<th>' . esc_html__('نوع', 'avina-crm') . '</th>';
        echo '<th>' . esc_html__('وضعیت', 'avina-crm') . '</th>';
        echo '</tr></thead><tbody>';

        if (empty($modules)) {
            echo '<tr><td colspan="3">' . esc_html__('ماژولی ثبت نشده است.', 'avina-crm') . '</td></tr>';
        }

        foreach ((array) $modules as $module) {
            $isCore = (int) $module['is_core'] === 1;
            $isActive = (int) $module['is_active'] === 1;

            echo '<tr>';
            echo '<td>' . esc_html($module['name_fa']) . ' <code>' . esc_html($module['slug']) . '</code></td>';
            echo '<td>' . ($isCore ? esc_html__('زیرساختی', 'avina-crm') : esc_html__('کسب‌وکاری', 'avina-crm')) . '</td>';

            if ($isCore) {
                echo '<td><span style="color:#1a7f37;">' . esc_html__('فعال (بخشی از هسته سامانه)', 'avina-crm') . '</span></td>';
            } elseif ($isActive) {
                echo '<td><span style="color:#1a7f37;">' . esc_html__('فعال', 'avina-crm') . '</span></td>';
            } else {
                echo '<td><span style="color:#8a8a8a;">' . esc_html__('در انتظار پیاده‌سازی', 'avina-crm') . '</span></td>';
            }

            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }
}
