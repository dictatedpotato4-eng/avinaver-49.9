<?php

declare(strict_types=1);

namespace AvinaCRM\Admin;

final class FormBuilderPage
{
    public const SLUG = 'avina-crm-form-builder';

    public function render(): void
    {
        if (!current_user_can('platform.admin.access')) {
            wp_die(esc_html__('شما اجازه دسترسی به این صفحه را ندارید.', 'avina-crm'));
        }

        wp_enqueue_script('wp-api'); // Enqueue WordPress REST API client script which provides wpApiSettings.nonce

        ?>
        <div class="wrap" dir="rtl" style="font-family: inherit;">
            <h1 style="margin-bottom: 1.5rem; font-weight: 700; color: #1e293b;"><?php echo esc_html__('فرمساز پویا، دکمه ثبت و وب‌سرویس پیامک آوینا CRM', 'avina-crm'); ?></h1>
            
            <div style="display: flex; gap: 1.5rem; margin-top: 1rem; flex-wrap: wrap; align-items: flex-start;">
                
                <!-- Left Sidebar Forms (Add Field + Settings) -->
                <div style="flex: 1 1 380px; display: flex; flex-direction: column; gap: 1.5rem;">
                    
                    <!-- Card 1: Add Custom Field -->
                    <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                        <h2 style="margin-top: 0; font-size: 1.2rem; font-weight: 600; color: #334155; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.75rem;" id="form-title">
                            <?php echo esc_html__('افزودن فیلد سفارشی جدید', 'avina-crm'); ?>
                        </h2>
                        
                        <form id="field-form" style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
                            <input type="hidden" id="field-action" value="create" />
                            
                            <div>
                                <label for="field-entity" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('موجودیت هدف', 'avina-crm'); ?></label>
                                <select id="field-entity" required style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;">
                                    <option value="contact"><?php echo esc_html__('مخاطب (Contact)', 'avina-crm'); ?></option>
                                    <option value="reception"><?php echo esc_html__('پذیرش (Reception)', 'avina-crm'); ?></option>
                                    <option value="customer"><?php echo esc_html__('مشتری (Customer)', 'avina-crm'); ?></option>
                                    <option value="deal"><?php echo esc_html__('معامله (Deal)', 'avina-crm'); ?></option>
                                </select>
                            </div>

                            <div>
                                <label for="field-id" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('شناسه فیلد (Slug انگلیسی یکتا)', 'avina-crm'); ?></label>
                                <input type="text" id="field-id" required pattern="^[a-z_][a-z0-9_]*$" placeholder="مثال: subscription_code" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem; direction: ltr;" />
                                <small style="color: #64748b; font-size: 0.8rem;"><?php echo esc_html__('فقط حروف کوچک انگلیسی و خط تیره (_). غیر قابل ویرایش بعد از ساخت.', 'avina-crm'); ?></small>
                            </div>

                            <div>
                                <label for="field-label" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('برچسب فیلد (نام فارسی)', 'avina-crm'); ?></label>
                                <input type="text" id="field-label" required placeholder="مثال: کد اشتراک" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;" />
                            </div>

                            <div>
                                <label for="field-type" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('نوع فیلد', 'avina-crm'); ?></label>
                                <select id="field-type" required style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;">
                                    <option value="text"><?php echo esc_html__('متنی (Text)', 'avina-crm'); ?></option>
                                    <option value="number"><?php echo esc_html__('عددی (Number)', 'avina-crm'); ?></option>
                                    <option value="select"><?php echo esc_html__('انتخابی کشویی (Dropdown)', 'avina-crm'); ?></option>
                                    <option value="checkbox"><?php echo esc_html__('چک‌باکس (Checkbox)', 'avina-crm'); ?></option>
                                    <option value="textarea"><?php echo esc_html__('متن طولانی (Textarea)', 'avina-crm'); ?></option>
                                    <option value="file"><?php echo esc_html__('بارگذاری فایل (File Upload)', 'avina-crm'); ?></option>
                                    <option value="date"><?php echo esc_html__('تاریخ شمسی (Shamsi Date)', 'avina-crm'); ?></option>
                                </select>
                            </div>

                            <div id="options-row" style="display: none;">
                                <label for="field-options" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('گزینه‌های انتخاب (هر گزینه در یک سطر)', 'avina-crm'); ?></label>
                                <textarea id="field-options" rows="4" placeholder="گزینه اول&#10;گزینه دوم&#10;گزینه سوم" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;"></textarea>
                            </div>

                            <div>
                                <label for="field-placeholder" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('متن راهنما / نگهدارنده جا (Placeholder)', 'avina-crm'); ?></label>
                                <input type="text" id="field-placeholder" placeholder="مثال: کد اشتراک را وارد کنید" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;" />
                            </div>

                            <div style="display: flex; gap: 1rem;">
                                <div style="flex: 1;">
                                    <label for="field-order" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('ترتیب نمایش', 'avina-crm'); ?></label>
                                    <input type="number" id="field-order" min="0" value="0" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;" />
                                </div>
                                <div style="flex: 1;">
                                    <label for="field-step" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('شماره مرحله (فرم چندمرحله‌ای)', 'avina-crm'); ?></label>
                                    <input type="number" id="field-step" min="1" value="1" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;" />
                                </div>
                            </div>

                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <input type="checkbox" id="field-required" value="1" />
                                <label for="field-required" style="font-weight: 600; color: #475569; cursor: pointer;"><?php echo esc_html__('این فیلد اجباری است (Required)', 'avina-crm'); ?></label>
                            </div>

                            <div style="display: flex; gap: 0.5rem; margin-top: 0.5rem;">
                                <button type="submit" class="button button-primary" style="flex: 1; padding: 0.35rem; height: auto; font-weight: 600; font-size: 0.95rem;"><?php echo esc_html__('ذخیره فیلد', 'avina-crm'); ?></button>
                                <button type="button" id="reset-btn" class="button" style="display: none; padding: 0.35rem; height: auto;"><?php echo esc_html__('انصراف', 'avina-crm'); ?></button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Card 2: Form & SMS Settings -->
                    <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                        <h2 style="margin-top: 0; font-size: 1.2rem; font-weight: 600; color: #334155; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.75rem;">
                            <?php echo esc_html__('تنظیمات عمومی و پیامک فرم', 'avina-crm'); ?>
                        </h2>
                        
                        <form id="settings-form" style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
                            <div>
                                <label for="settings-entity" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('موجودیت هدف', 'avina-crm'); ?></label>
                                <select id="settings-entity" required style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;">
                                    <option value="contact"><?php echo esc_html__('مخاطب (Contact)', 'avina-crm'); ?></option>
                                    <option value="reception"><?php echo esc_html__('پذیرش (Reception)', 'avina-crm'); ?></option>
                                    <option value="customer"><?php echo esc_html__('مشتری (Customer)', 'avina-crm'); ?></option>
                                    <option value="deal"><?php echo esc_html__('معامله (Deal)', 'avina-crm'); ?></option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="settings-submit-label" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('برچسب دکمه ثبت فرم', 'avina-crm'); ?></label>
                                <input type="text" id="settings-submit-label" placeholder="پیش‌فرض: ذخیره" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;" />
                            </div>

                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-top: 0.5rem;">
                                <input type="checkbox" id="settings-sms-enabled" value="1" />
                                <label for="settings-sms-enabled" style="font-weight: 600; color: #475569; cursor: pointer;"><?php echo esc_html__('ارسال پیامک خودکار فعال باشد', 'avina-crm'); ?></label>
                            </div>

                            <div id="sms-fields-wrapper" style="display: none; flex-direction: column; gap: 1rem; border-top: 1px solid #f1f5f9; padding-top: 1rem;">
                                <div>
                                    <label for="settings-sms-provider" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('سامانه پیامک', 'avina-crm'); ?></label>
                                    <select id="settings-sms-provider" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem;">
                                        <option value="ippanel"><?php echo esc_html__('IPPanel / FarazSMS', 'avina-crm'); ?></option>
                                        <option value="sms_ir"><?php echo esc_html__('sms.ir (Saba SMS)', 'avina-crm'); ?></option>
                                    </select>
                                </div>
                                <div>
                                    <label for="settings-sms-api-key" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('کلید API (Access Key)', 'avina-crm'); ?></label>
                                    <input type="text" id="settings-sms-api-key" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem; direction: ltr;" />
                                </div>
                                <div>
                                    <label for="settings-sms-sender" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('خط فرستنده اختصاصی', 'avina-crm'); ?></label>
                                    <input type="text" id="settings-sms-sender" placeholder="مثال: +983000505" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem; direction: ltr;" />
                                </div>
                                <div>
                                    <label for="settings-sms-recipient" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('شماره موبایل گیرنده (ثابت یا متغیر)', 'avina-crm'); ?></label>
                                    <input type="text" id="settings-sms-recipient" placeholder="مثال: [phone] یا [visitor_phone]" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem; direction: ltr;" />
                                    <small style="color: #64748b; font-size: 0.8rem;"><?php echo esc_html__('از متغیرهای فیلدها مانند [phone] یا شماره ثابت مثل 09123456789 استفاده کنید.', 'avina-crm'); ?></small>
                                </div>
                                <div>
                                    <label for="settings-sms-pattern-code" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('کد الگو / شناسه قالب (Pattern ID)', 'avina-crm'); ?></label>
                                    <input type="text" id="settings-sms-pattern-code" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem; direction: ltr;" />
                                </div>
                                <div>
                                    <label for="settings-sms-variables" style="display: block; font-weight: 600; margin-bottom: 0.35rem; color: #475569;"><?php echo esc_html__('نگاشت متغیرها (هر متغیر در یک سطر)', 'avina-crm'); ?></label>
                                    <textarea id="settings-sms-variables" rows="4" placeholder="name = [full_name]&#10;code = [subscription_code]&#10;date = {current_date}" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.5rem; direction: ltr; text-align: left;"></textarea>
                                    <small style="color: #64748b; font-size: 0.8rem;"><?php echo esc_html__('به صورت var_name = [field_name] بنویسید. از {current_date} برای درج تاریخ روز استفاده کنید.', 'avina-crm'); ?></small>
                                </div>
                            </div>

                            <button type="submit" class="button button-primary" style="padding: 0.35rem; height: auto; font-weight: 600; font-size: 0.95rem; margin-top: 0.5rem;">
                                <?php echo esc_html__('ذخیره تنظیمات فرم', 'avina-crm'); ?>
                            </button>
                        </form>
                    </div>

                </div>

                <!-- Main Area Table -->
                <div style="flex: 2 1 600px; background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.75rem; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
                        <h2 style="margin: 0; font-size: 1.2rem; font-weight: 600; color: #334155;"><?php echo esc_html__('لیست فیلدهای سفارشی', 'avina-crm'); ?></h2>
                        <div>
                            <label for="filter-entity" style="font-weight: 600; color: #475569; margin-left: 0.5rem;"><?php echo esc_html__('فیلتر موجودیت:', 'avina-crm'); ?></label>
                            <select id="filter-entity" style="border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.25rem 0.5rem;">
                                <option value="all"><?php echo esc_html__('همه موجودیت‌ها', 'avina-crm'); ?></option>
                                <option value="contact"><?php echo esc_html__('مخاطب (Contact)', 'avina-crm'); ?></option>
                                <option value="reception"><?php echo esc_html__('پذیرش (Reception)', 'avina-crm'); ?></option>
                                <option value="customer"><?php echo esc_html__('مشتری (Customer)', 'avina-crm'); ?></option>
                                <option value="deal"><?php echo esc_html__('معامله (Deal)', 'avina-crm'); ?></option>
                            </select>
                        </div>
                    </div>

                    <div style="overflow-x: auto;">
                        <table class="wp-list-table widefat fixed striped table-view-list" style="border: none; box-shadow: none;">
                            <thead>
                                <tr>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem;"><?php echo esc_html__('برچسب فیلد (نام فارسی)', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem;"><?php echo esc_html__('شناسه یکتا (Slug)', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem;"><?php echo esc_html__('موجودیت', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem;"><?php echo esc_html__('نوع', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem;"><?php echo esc_html__('اجباری', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem; width: 60px;"><?php echo esc_html__('مرحله', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem; width: 60px;"><?php echo esc_html__('ترتیب', 'avina-crm'); ?></th>
                                    <th style="font-weight: 600; color: #475569; padding: 0.75rem; width: 100px;"></th>
                                </tr>
                            </thead>
                            <tbody id="fields-tbody">
                                <tr>
                                    <td colspan="8" style="text-align: center; padding: 2rem; color: #64748b;"><?php echo esc_html__('در حال بارگذاری فیلدها...', 'avina-crm'); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const restUrl = '<?php echo esc_url_raw(rest_url('avina-crm/v1')); ?>';
            const nonce = typeof wpApiSettings !== 'undefined' ? wpApiSettings.nonce : '';

            // Fields Elements
            const entitySelect = document.getElementById('field-entity');
            const idInput = document.getElementById('field-id');
            const labelInput = document.getElementById('field-label');
            const typeSelect = document.getElementById('field-type');
            const optionsRow = document.getElementById('options-row');
            const optionsTextarea = document.getElementById('field-options');
            const placeholderInput = document.getElementById('field-placeholder');
            const orderInput = document.getElementById('field-order');
            const stepInput = document.getElementById('field-step');
            const requiredCheckbox = document.getElementById('field-required');
            const actionInput = document.getElementById('field-action');
            const formTitle = document.getElementById('form-title');
            const resetBtn = document.getElementById('reset-btn');
            const fieldForm = document.getElementById('field-form');
            
            // Filter and List
            const filterEntity = document.getElementById('filter-entity');
            const fieldsTbody = document.getElementById('fields-tbody');
            
            // Settings Elements
            const settingsForm = document.getElementById('settings-form');
            const settingsEntity = document.getElementById('settings-entity');
            const settingsSubmitLabel = document.getElementById('settings-submit-label');
            const settingsSmsEnabled = document.getElementById('settings-sms-enabled');
            const smsFieldsWrapper = document.getElementById('sms-fields-wrapper');
            const settingsSmsProvider = document.getElementById('settings-sms-provider');
            const settingsSmsApiKey = document.getElementById('settings-sms-api-key');
            const settingsSmsSender = document.getElementById('settings-sms-sender');
            const settingsSmsRecipient = document.getElementById('settings-sms-recipient');
            const settingsSmsPatternCode = document.getElementById('settings-sms-pattern-code');
            const settingsSmsVariables = document.getElementById('settings-sms-variables');

            let allCustomFields = {}; // cached grouped fields

            // Toggle options field based on type
            typeSelect.addEventListener('change', function() {
                if (typeSelect.value === 'select') {
                    optionsRow.style.display = 'block';
                } else {
                    optionsRow.style.display = 'none';
                }
            });

            // Toggle SMS fields wrapper
            settingsSmsEnabled.addEventListener('change', function() {
                if (settingsSmsEnabled.checked) {
                    smsFieldsWrapper.style.display = 'flex';
                } else {
                    smsFieldsWrapper.style.display = 'none';
                }
            });

            // Fetch and render fields
            async function fetchFields() {
                try {
                    const response = await fetch(`${restUrl}/custom-fields`, {
                        headers: { 'X-WP-Nonce': nonce }
                    });
                    const res = await response.json();
                    if (res.success) {
                        allCustomFields = res.data;
                        renderTable();
                    } else {
                        fieldsTbody.innerHTML = `<tr><td colspan="8" style="text-align:center;color:red;padding:2rem;">${res.message || 'خطا در دریافت فیلدها'}</td></tr>`;
                    }
                } catch (e) {
                    fieldsTbody.innerHTML = `<tr><td colspan="8" style="text-align:center;color:red;padding:2rem;">خطا در ارتباط با سرور</td></tr>`;
                }
            }

            // Fetch and set form settings
            async function fetchSettings(entity) {
                try {
                    const response = await fetch(`${restUrl}/form-settings/${entity}`, {
                        headers: { 'X-WP-Nonce': nonce }
                    });
                    const res = await response.json();
                    if (res.success) {
                        const data = res.data;
                        settingsSubmitLabel.value = data.submit_button_label || '';
                        settingsSmsEnabled.checked = !!data.sms_enabled;
                        settingsSmsEnabled.dispatchEvent(new Event('change'));
                        
                        settingsSmsProvider.value = data.sms_provider || 'ippanel';
                        settingsSmsApiKey.value = data.sms_api_key || '';
                        settingsSmsSender.value = data.sms_sender || '';
                        settingsSmsRecipient.value = data.sms_recipient || '';
                        settingsSmsPatternCode.value = data.sms_pattern_code || '';
                        settingsSmsVariables.value = data.sms_pattern_variables || '';
                    }
                } catch (e) {
                    console.error("Error fetching settings", e);
                }
            }

            const ENTITY_LABELS = {
                contact: 'مخاطب',
                reception: 'پذیرش',
                customer: 'مشتری',
                deal: 'معامله'
            };

            const TYPE_LABELS = {
                text: 'متنی',
                number: 'عددی',
                select: 'انتخابی کشویی',
                checkbox: 'چک‌باکس',
                textarea: 'متن طولانی',
                file: 'بارگذاری فایل',
                date: 'تاریخ شمسی'
            };

            function renderTable() {
                const selectedFilter = filterEntity.value;
                let html = '';
                let count = 0;

                const entitiesToRender = selectedFilter === 'all' 
                    ? ['contact', 'reception', 'customer', 'deal']
                    : [selectedFilter];

                entitiesToRender.forEach(ent => {
                    const fields = allCustomFields[ent] || [];
                    fields.forEach(field => {
                        count++;
                        html += `
                            <tr data-id="${field.id}" data-entity="${ent}">
                                <td style="padding:0.75rem;font-weight:600;color:#1e293b;">${escapeHtml(field.label)}</td>
                                <td style="padding:0.75rem;direction:ltr;text-align:right;"><code>${escapeHtml(field.id)}</code></td>
                                <td style="padding:0.75rem;"><span class="badge" style="background:#f1f5f9;color:#475569;padding:0.15rem 0.4rem;border-radius:4px;font-size:0.85rem;">${ENTITY_LABELS[ent]}</span></td>
                                <td style="padding:0.75rem;color:#475569;">${TYPE_LABELS[field.type] || field.type}</td>
                                <td style="padding:0.75rem;">${field.required ? '<span style="color:red;font-weight:bold;">بله</span>' : 'خیر'}</td>
                                <td style="padding:0.75rem;text-align:center;">${field.step || 1}</td>
                                <td style="padding:0.75rem;text-align:center;">${field.order || 0}</td>
                                <td style="padding:0.75rem;text-align:left;">
                                    <button type="button" class="button edit-btn" style="margin-left:0.25rem;">ویرایش</button>
                                    <button type="button" class="button delete-btn" style="color:red;border-color:red;">حذف</button>
                                </td>
                            </tr>
                        `;
                    });
                });

                if (count === 0) {
                    html = `<tr><td colspan="8" style="text-align: center; padding: 2rem; color: #64748b;">هیچ فیلد سفارشی یافت نشد.</td></tr>`;
                }

                fieldsTbody.innerHTML = html;
                attachTableEvents();
            }

            function escapeHtml(str) {
                if (!str) return '';
                return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
            }

            function attachTableEvents() {
                // Edit button
                fieldsTbody.querySelectorAll('.edit-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tr = btn.closest('tr');
                        const ent = tr.dataset.entity;
                        const id = tr.dataset.id;
                        
                        const field = allCustomFields[ent].find(f => f.id === id);
                        if (!field) return;

                        // Fill Form
                        entitySelect.value = ent;
                        entitySelect.disabled = true; // cannot change entity on edit
                        idInput.value = field.id;
                        idInput.disabled = true; // cannot change id on edit
                        labelInput.value = field.label;
                        typeSelect.value = field.type;
                        typeSelect.dispatchEvent(new Event('change'));
                        
                        if (field.type === 'select') {
                            optionsTextarea.value = (field.options || []).join('\n');
                        }
                        
                        placeholderInput.value = field.placeholder || '';
                        orderInput.value = field.order || 0;
                        stepInput.value = field.step || 1;
                        requiredCheckbox.checked = !!field.required;
                        
                        actionInput.value = 'edit';
                        formTitle.textContent = 'ویرایش فیلد سفارشی: ' + field.label;
                        resetBtn.style.display = 'inline-block';
                    });
                });

                // Delete button
                fieldsTbody.querySelectorAll('.delete-btn').forEach(btn => {
                    btn.addEventListener('click', async function() {
                        const tr = btn.closest('tr');
                        const ent = tr.dataset.entity;
                        const id = tr.dataset.id;

                        if (!confirm('آیا مطمئن هستید که می‌خواهید این فیلد سفارشی را حذف کنید؟ این عمل مقادیر ذخیره شده کاربران را حذف نخواهد کرد اما این فیلد دیگر در فرم‌ها نمایش داده نمی‌شود.')) {
                            return;
                        }

                        try {
                            const response = await fetch(`${restUrl}/custom-fields/${ent}/${id}`, {
                                method: 'DELETE',
                                headers: { 'X-WP-Nonce': nonce }
                            });
                            const res = await response.json();
                            if (res.success) {
                                fetchFields();
                                resetForm();
                            } else {
                                alert(res.message || 'خطا در حذف فیلد');
                            }
                        } catch (e) {
                            alert('خطا در ارتباط با سرور');
                        }
                    });
                });
            }

            // Reset form
            function resetForm() {
                fieldForm.reset();
                entitySelect.disabled = false;
                idInput.disabled = false;
                actionInput.value = 'create';
                formTitle.textContent = 'افزودن فیلد سفارشی جدید';
                resetBtn.style.display = 'none';
                typeSelect.dispatchEvent(new Event('change'));
            }

            resetBtn.addEventListener('click', resetForm);
            filterEntity.addEventListener('change', renderTable);

            // Submit Custom Field Form
            fieldForm.addEventListener('submit', async function(e) {
                e.preventDefault();

                const options = optionsTextarea.value.split('\n')
                    .map(o => o.trim())
                    .filter(o => o !== '');

                const payload = {
                    entity: entitySelect.value,
                    id: idInput.value,
                    label: labelInput.value,
                    type: typeSelect.value,
                    placeholder: placeholderInput.value,
                    required: requiredCheckbox.checked,
                    order: parseInt(orderInput.value) || 0,
                    step: parseInt(stepInput.value) || 1,
                    options: options
                };

                try {
                    const response = await fetch(`${restUrl}/custom-fields`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': nonce
                        },
                        body: JSON.stringify(payload)
                    });
                    const res = await response.json();
                    if (res.success) {
                        fetchFields();
                        resetForm();
                    } else {
                        alert(res.message || 'خطا در ذخیره فیلد');
                    }
                } catch (e) {
                    alert('خطا در ارتباط با سرور');
                }
            });

            // Change entity in settings form -> fetch settings
            settingsEntity.addEventListener('change', function() {
                fetchSettings(settingsEntity.value);
            });

            // Submit settings form
            settingsForm.addEventListener('submit', async function(e) {
                e.preventDefault();

                const payload = {
                    entity: settingsEntity.value,
                    submit_button_label: settingsSubmitLabel.value,
                    sms_enabled: settingsSmsEnabled.checked,
                    sms_provider: settingsSmsProvider.value,
                    sms_api_key: settingsSmsApiKey.value,
                    sms_sender: settingsSmsSender.value,
                    sms_recipient: settingsSmsRecipient.value,
                    sms_pattern_code: settingsSmsPatternCode.value,
                    sms_pattern_variables: settingsSmsVariables.value
                };

                try {
                    const response = await fetch(`${restUrl}/form-settings`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': nonce
                        },
                        body: JSON.stringify(payload)
                    });
                    const res = await response.json();
                    if (res.success) {
                        alert('تنظیمات فرم با موفقیت ذخیره شد.');
                        fetchSettings(settingsEntity.value);
                    } else {
                        alert(res.message || 'خطا در ذخیره تنظیمات');
                    }
                } catch (e) {
                    alert('خطا در ارتباط با سرور');
                }
            });

            // Init load
            fetchFields();
            fetchSettings(settingsEntity.value);
        });
        </script>
        <?php
    }
}
