<?php

declare(strict_types=1);

namespace AvinaCRM\Uninstall;

/**
 * Stage 1's explicit rule ("no destructive uninstall behavior by
 * default") and Stage 2 decision #5 ("never delete production CRM data
 * automatically"). Uninstalling the plugin through wp-admin, by default,
 * leaves every table, option, role, and capability exactly as it was.
 *
 * The only thing this stage's uninstall path does is remove the
 * transient in-memory registration hook state — there is nothing else
 * safe to do automatically. A future Advanced-settings screen may add an
 * explicit, separately confirmed "Delete all CRM data" action; until
 * that exists, there is no mechanism at all for uninstall to be
 * destructive, by construction — not merely by a checked flag.
 */
final class UninstallHandler
{
    public static function run(): void
    {
        // Intentionally empty. See class docblock: no automatic data,
        // option, role, or capability removal happens on uninstall.
        // Nothing further is safe to do here without an explicit,
        // separately confirmed administrator action, which does not
        // exist yet in this stage.
    }
}
