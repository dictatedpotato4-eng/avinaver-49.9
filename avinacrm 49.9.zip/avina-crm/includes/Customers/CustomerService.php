<?php

declare(strict_types=1);

namespace AvinaCRM\Customers;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Support\Scope;
use WP_Error;

final class CustomerService
{
    public const STATUSES = ['active', 'inactive', 'vip'];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';

        $where = ['is_archived = 0'];

        $visibility = Scope::visibilityClause('customers.customer.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        if ($visibility !== '') {
            $where[] = $visibility;
        }

        if (!empty($filters['search'])) {
            $search = '%' . $wpdb->esc_like(sanitize_text_field($filters['search'])) . '%';
            $where[] = $wpdb->prepare('(full_name LIKE %s OR phone LIKE %s OR email LIKE %s)', $search, $search, $search);
        }

        if (!empty($filters['status']) && in_array($filters['status'], self::STATUSES, true)) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }

        $whereSql = implode(' AND ', $where);

        $perPage = min(10000, max(1, (int) ($filters['per_page'] ?? 20)));
        $page = max(1, (int) ($filters['page'] ?? 1));
        $offset = ($page - 1) * $perPage;

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$whereSql}");

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE {$whereSql} ORDER BY created_at DESC LIMIT %d OFFSET %d", $perPage, $offset),
            ARRAY_A
        );

        return ['items' => array_map([$this, 'decorate'], $rows ?: []), 'total' => $total];
    }

    public function find(int $id): ?array
    {
        $row = $this->rawFind($id);

        if ($row === null || !$this->canView($row)) {
            return null;
        }

        $row = $this->decorate($row);
        $row['notes_list'] = $this->notesFor($id);

        return $row;
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $fullName = sanitize_text_field($data['full_name'] ?? '');

        if ($fullName === '') {
            return new WP_Error('avina_crm_invalid_customer', __('نام مشتری الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $rawOwner = $data['owner_user_id'] ?? ($data['created_by'] ?? ($data['actor_user_id'] ?? ($data['createdBy'] ?? ($data['createdById'] ?? ''))));
        $resolvedOwnerId = 0;
        if (!empty($rawOwner) && $rawOwner !== 'admin') {
            $u = get_user_by('login', (string)$rawOwner);
            if (!$u) $u = get_user_by('email', (string)$rawOwner);
            if ($u) {
                $resolvedOwnerId = (int)$u->ID;
            } elseif (is_numeric($rawOwner) && (int)$rawOwner > 0) {
                $checkUser = get_userdata((int)$rawOwner);
                if ($checkUser) {
                    $resolvedOwnerId = (int)$rawOwner;
                }
            }
        }
        if ($resolvedOwnerId <= 0) {
            $resolvedOwnerId = $actorUserId > 0 ? $actorUserId : get_current_user_id();
        }
        $ownerUserId = $resolvedOwnerId > 0 ? $resolvedOwnerId : 1;
        $actorUserId = $resolvedOwnerId > 0 ? $resolvedOwnerId : ($actorUserId > 0 ? $actorUserId : 1);

        $coreKeys = [
            'contact_id', 'full_name', 'phone', 'email', 'status', 'owner_user_id', 'team_id',
            'conversion_date', 'purchased_products', 'notes', 'purchase_count'
        ];
        $customFields = [];
        $configured = get_option('avina_crm_custom_fields', []);
        $customerConfig = $configured['customer'] ?? [];
        $allowedCustomKeys = array_column($customerConfig, 'id');

        foreach ($data as $key => $val) {
            if (!in_array($key, $coreKeys, true) && in_array($key, $allowedCustomKeys, true)) {
                $customFields[$key] = sanitize_text_field((string)$val);
            }
        }
        $customFieldsJson = !empty($customFields) ? wp_json_encode($customFields, JSON_UNESCAPED_UNICODE) : null;

        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';

        $wpdb->insert(
            $table,
            [
                'contact_id' => !empty($data['contact_id']) ? (int) $data['contact_id'] : null,
                'full_name' => $fullName,
                'phone' => sanitize_text_field($data['phone'] ?? ''),
                'email' => sanitize_email($data['email'] ?? ''),
                'status' => in_array($data['status'] ?? '', self::STATUSES, true) ? $data['status'] : 'active',
                'owner_user_id' => $ownerUserId,
                'team_id' => !empty($data['team_id']) ? (int) $data['team_id'] : null,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'custom_fields' => $customFieldsJson,
                'conversion_date' => !empty($data['conversion_date']) ? sanitize_text_field($data['conversion_date']) : current_time('Y-m-d'),
                'purchased_products' => sanitize_text_field($data['purchased_products'] ?? ''),
                'notes' => sanitize_textarea_field($data['notes'] ?? ''),
                'purchase_count' => (int) ($data['purchase_count'] ?? 1),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'customers.customer.create', 'customer', (string) $id, null, ['full_name' => $fullName]);

        return ['id' => $id];
    }

    /**
     * @return true|WP_Error
     */
    public function update(int $id, array $data, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_customer_not_found', __('مشتری موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canView($existing)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه ویرایش این مشتری را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        $fields = [];
        $formats = [];

        $updatable = [
            'full_name' => '%s',
            'phone' => '%s',
            'email' => '%s',
            'status' => '%s',
            'purchased_products' => '%s',
            'notes' => '%s',
            'purchase_count' => '%d',
            'conversion_date' => '%s'
        ];

        foreach ($updatable as $key => $format) {
            if (isset($data[$key])) {
                if ($key === 'full_name') {
                    $name = sanitize_text_field($data['full_name']);
                    if ($name === '') {
                        return new WP_Error('avina_crm_invalid_customer', __('نام مشتری نمی‌تواند خالی باشد.', 'avina-crm'), ['status' => 400]);
                    }
                    $fields['full_name'] = $name;
                } elseif ($key === 'email') {
                    $fields['email'] = sanitize_email($data['email']);
                } elseif ($key === 'phone') {
                    $fields['phone'] = sanitize_text_field($data['phone']);
                } elseif ($key === 'notes') {
                    $fields['notes'] = sanitize_textarea_field($data['notes']);
                } else {
                    $fields[$key] = $data[$key];
                }
                $formats[] = $format;
            }
        }

        $configured = get_option('avina_crm_custom_fields', []);
        $customerConfig = $configured['customer'] ?? [];
        $allowedCustomKeys = array_column($customerConfig, 'id');
        $customUpdates = [];
        foreach ($data as $key => $val) {
            if (in_array($key, $allowedCustomKeys, true)) {
                $customUpdates[$key] = sanitize_text_field((string)$val);
            }
        }

        if (!empty($customUpdates)) {
            $existingCustomJson = $existing['custom_fields'] ?? '';
            $existingCustom = [];
            if ($existingCustomJson !== '') {
                $existingCustom = json_decode($existingCustomJson, true);
                if (!is_array($existingCustom)) {
                    $existingCustom = [];
                }
            }
            $mergedCustom = array_merge($existingCustom, $customUpdates);
            $fields['custom_fields'] = wp_json_encode($mergedCustom, JSON_UNESCAPED_UNICODE);
            $formats[] = '%s';
        }

        if (empty($fields)) {
            return true;
        }

        $fields['updated_at'] = current_time('mysql');
        $formats[] = '%s';

        global $wpdb;
        $wpdb->update($wpdb->prefix . 'avina_customers', $fields, ['id' => $id], $formats, ['%d']);

        $this->audit->record($actorUserId, 'customers.customer.update', 'customer', (string) $id, $existing, $fields);

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function archive(int $id, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_customer_not_found', __('مشتری موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'avina_customers',
            ['is_archived' => 1, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%d', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'customers.customer.archive', 'customer', (string) $id, $existing, ['is_archived' => 1]);

        return true;
    }

    public function addPurchase(int $customerId, string $product, int $actorUserId)
    {
        global $wpdb;
        $customer = $this->rawFind($customerId);

        if ($customer === null) {
            return new WP_Error('avina_crm_customer_not_found', __('مشتری موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $currentProducts = $customer['purchased_products'] !== '' ? explode(',', $customer['purchased_products']) : [];
        $currentProducts[] = sanitize_text_field($product);
        $newProductsStr = implode(',', array_filter(array_map('trim', $currentProducts)));

        $newCount = ((int) ($customer['purchase_count'] ?? 1)) + 1;

        $wpdb->update(
            $wpdb->prefix . 'avina_customers',
            [
                'purchased_products' => $newProductsStr,
                'purchase_count' => $newCount,
                'updated_at' => current_time('mysql')
            ],
            ['id' => $customerId],
            ['%s', '%d', '%s'],
            ['%d']
        );

        // Record a followup to the contacts history if linked
        if ($customer['contact_id']) {
            $logText = sprintf('ثبت خرید مجدد محصول: %s (مجموع خریدها: %d بار)', $product, $newCount);
            $contactsTable = $wpdb->prefix . 'avina_contact_followups';
            $wpdb->insert(
                $contactsTable,
                [
                    'contact_id' => $customer['contact_id'],
                    'followup_date' => current_time('Y-m-d'),
                    'notes' => $logText,
                    'result' => 'خرید مجدد',
                    'created_by_user_id' => $actorUserId,
                    'created_at' => current_time('mysql')
                ],
                ['%d', '%s', '%s', '%s', '%d', '%s']
            );
        }

        $this->audit->record($actorUserId, 'customers.customer.add_purchase', 'customer', (string) $customerId, null, [
            'product' => $product,
            'purchase_count' => $newCount
        ]);

        return true;
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function addNote(int $customerId, string $body, int $actorUserId)
    {
        $customer = $this->rawFind($customerId);

        if ($customer === null || !$this->canView($customer)) {
            return new WP_Error('avina_crm_customer_not_found', __('مشتری موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $body = sanitize_textarea_field($body);

        if ($body === '') {
            return new WP_Error('avina_crm_invalid_note', __('متن یادداشت نمی‌تواند خالی باشد.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_customer_notes';

        $wpdb->insert(
            $table,
            [
                'customer_id' => $customerId,
                'body' => $body,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%d', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'customers.note.create', 'customer', (string) $customerId, null, ['note_id' => $id]);

        return ['id' => $id];
    }

    public function exportRows(array $filters): array
    {
        $items = $this->list(array_merge($filters, ['per_page' => 10000, 'page' => 1]))['items'];

        $headers = [
            __('نام کامل', 'avina-crm'),
            __('تلفن', 'avina-crm'),
            __('ایمیل', 'avina-crm'),
            __('تاریخ تبدیل', 'avina-crm'),
            __('محصولات خریداری‌شده', 'avina-crm'),
            __('تعداد خریدها', 'avina-crm'),
            __('توضیحات و یادداشت‌ها', 'avina-crm'),
            __('وضعیت', 'avina-crm'),
        ];

        $rows = [];
        foreach ($items as $item) {
            $rows[] = [
                $item['full_name'],
                $item['phone'],
                $item['email'],
                $item['conversion_date'] ?? '—',
                $item['purchased_products'],
                (string) $item['purchase_count'],
                $item['notes'],
                $item['status'] === 'active' ? 'فعال' : ($item['status'] === 'vip' ? 'ویژه' : 'غیرفعال')
            ];
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    private function notesFor(int $customerId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customer_notes';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE customer_id = %d ORDER BY created_at DESC", $customerId),
            ARRAY_A
        );

        return $rows ?: [];
    }

    private function canView(array $row): bool
    {
        if ($this->isManager()) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) ($row['owner_user_id'] ?? 0) === $userId || (int) ($row['created_by_user_id'] ?? 0) === $userId) {
            return true;
        }

        if (!empty($row['team_id']) && Scope::isTeamMember($userId, (int) $row['team_id'])) {
            return true;
        }

        return false;
    }

    private function isManager(): bool
    {
        return current_user_can('manage_options') || current_user_can('users-roles.user.view');
    }

    private function rawFind(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND is_archived = 0", $id), ARRAY_A);

        return $row ?: null;
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['contact_id'] = $row['contact_id'] !== null ? (int) $row['contact_id'] : null;
        $row['owner_user_id'] = $row['owner_user_id'] !== null ? (int) $row['owner_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;
        $row['is_archived'] = (bool) $row['is_archived'];
        $row['custom_fields'] = !empty($row['custom_fields']) ? json_decode($row['custom_fields'], true) : new \stdClass();
        $row['purchase_count'] = (int) ($row['purchase_count'] ?? 1);
        return $row;
    }
}
