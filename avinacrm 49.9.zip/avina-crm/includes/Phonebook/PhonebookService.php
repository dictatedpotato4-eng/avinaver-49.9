<?php

declare(strict_types=1);

namespace AvinaCRM\Phonebook;

use AvinaCRM\Support\Scope;

/**
 * Phonebook is intentionally a read-only projection — it has no table of
 * its own (Stage 1 §3 identified it as a projection concept over
 * contacts/customers, never a real standalone table in the legacy app).
 * It unions contacts and customers, applies the same team/status
 * filtering as those modules, and additionally masks the phone number
 * for anyone who is not the record's owner/creator, a team member, or a
 * capability-holding manager — showing only the last 4 digits, e.g.
 * "•••• 6789", by design (Stage 3 explicit "safe masked phone handling"
 * requirement) rather than the full number.
 */
final class PhonebookService
{
    public function search(array $filters): array
    {
        global $wpdb;

        $contactsTable = $wpdb->prefix . 'avina_contacts';
        $customersTable = $wpdb->prefix . 'avina_customers';

        $search = !empty($filters['search']) ? '%' . $wpdb->esc_like(sanitize_text_field($filters['search'])) . '%' : null;
        $teamId = !empty($filters['team_id']) ? (int) $filters['team_id'] : null;

        $rows = [];

        foreach ([['table' => $contactsTable, 'type' => 'contact'], ['table' => $customersTable, 'type' => 'customer']] as $source) {
            $where = ['is_archived = 0'];

            if ($search !== null) {
                $where[] = $wpdb->prepare('(full_name LIKE %s OR phone LIKE %s)', $search, $search);
            }

            if ($teamId !== null) {
                $where[] = $wpdb->prepare('team_id = %d', $teamId);
            }

            $whereSql = implode(' AND ', $where);

            $sourceRows = $wpdb->get_results(
                "SELECT id, full_name, phone, email, owner_user_id, team_id, created_by_user_id FROM {$source['table']} WHERE {$whereSql} ORDER BY full_name ASC LIMIT 200",
                ARRAY_A
            );

            foreach ((array) $sourceRows as $row) {
                $row['source_type'] = $source['type'];
                $rows[] = $this->decorate($row);
            }
        }

        usort($rows, static fn ($a, $b) => strcmp($a['full_name'], $b['full_name']));

        return $rows;
    }

    private function decorate(array $row): array
    {
        $canSeeFull = $this->canSeeFullNumber($row);

        return [
            'id' => (int) $row['id'],
            'source_type' => $row['source_type'],
            'full_name' => $row['full_name'],
            'phone' => $canSeeFull ? $row['phone'] : $this->maskPhone($row['phone']),
            'phone_masked' => !$canSeeFull,
            'email' => $canSeeFull ? $row['email'] : '',
        ];
    }

    private function canSeeFullNumber(array $row): bool
    {
        if (current_user_can('manage_options') || current_user_can('users-roles.user.view')) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) ($row['owner_user_id'] ?? 0) === $userId || (int) ($row['created_by_user_id'] ?? 0) === $userId) {
            return true;
        }

        if (!empty($row['team_id']) && Scope::isTeamMember($userId, (int) $row['team_id'])) {
            return true;
        }

        return false;
    }

    private function maskPhone(string $phone): string
    {
        $digits = preg_replace('/\D/', '', $phone);

        if (strlen($digits) < 4) {
            return str_repeat('•', max(0, strlen($digits)));
        }

        $lastFour = substr($digits, -4);

        return '•••• ' . $lastFour;
    }
}
