<?php

declare(strict_types=1);

namespace AvinaCRM\Operators;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Capabilities\RoleProvisioner;
use WP_Error;
use WP_User;

/**
 * Operator/user foundation. Wraps native wp_insert_user()/wp_update_user()
 * — WordPress remains the sole identity store; this class never invents
 * its own credential handling. It only adds the `avina_operator` role
 * assignment, an optional dedicated page + shortcode instance (CRM page
 * assignment foundation), and an audit trail entry on top of what
 * WordPress already does.
 */
final class OperatorService
{
    private RoleProvisioner $roles;
    private AuditLogger $audit;

    public function __construct(RoleProvisioner $roles, AuditLogger $audit)
    {
        $this->roles = $roles;
        $this->audit = $audit;
    }

    private function ensureTableExists(): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_operator_pages';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
          user_id BIGINT UNSIGNED NOT NULL,
          page_id BIGINT UNSIGNED NOT NULL,
          is_active TINYINT(1) NOT NULL DEFAULT 1,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          UNIQUE KEY user_id (user_id),
          KEY page_id (page_id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public static function toEnglishDigits(string $str): string
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic  = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        $str = str_replace($persian, $english, trim($str));
        return str_replace($arabic, $english, $str);
    }

    /**
     * @param array{full_name: string, username: string, email: string, password?: string, mobile?: string, permissions?: array, create_page?: bool} $data
     * @return array{user_id: int, page_id: ?int, page_url?: string, success: true}|WP_Error
     */
    public function createOperator(array $data, int $actorUserId)
    {
        $this->roles->ensureOperatorRole();

        $username = sanitize_user(self::toEnglishDigits($data['username'] ?? ''), true);
        $email = sanitize_email(self::toEnglishDigits($data['email'] ?? ''));
        $fullName = sanitize_text_field($data['full_name'] ?? '');
        $mobile = sanitize_text_field(self::toEnglishDigits($data['mobile'] ?? ''));

        if ($username === '' || $email === '' || !is_email($email)) {
            return new WP_Error(
                'avina_crm_invalid_operator',
                __('نام کاربری و ایمیل معتبر برای ایجاد اپراتور الزامی است.', 'avina-crm'),
                ['status' => 400]
            );
        }

        if (username_exists($username) || email_exists($email)) {
            return new WP_Error(
                'avina_crm_operator_exists',
                __('کاربری با این نام کاربری یا ایمیل از قبل وجود دارد.', 'avina-crm'),
                ['status' => 409]
            );
        }

        $rawPass = !empty($data['password']) ? self::toEnglishDigits($data['password']) : wp_generate_password(20, true, true);
        $role = (!empty($data['role']) && $data['role'] === 'admin') ? 'administrator' : RoleProvisioner::ROLE_SLUG;

        $userId = wp_insert_user([
            'user_login' => $username,
            'user_email' => $email,
            'user_pass' => $rawPass,
            'display_name' => $fullName !== '' ? $fullName : $username,
            'role' => $role,
        ]);

        if (is_wp_error($userId)) {
            return $userId;
        }

        if (!empty($mobile)) {
            update_user_meta((int) $userId, 'avina_crm_operator_mobile', $mobile);
        }

        $welcomeCode = sanitize_text_field((string)($data['welcome_pattern_code'] ?? ($data['welcomePatternCode'] ?? '')));
        if ($welcomeCode !== '') {
            update_user_meta((int) $userId, 'avina_crm_welcome_pattern_code', $welcomeCode);
        }

        $followupCode = sanitize_text_field((string)($data['followup_pattern_code'] ?? ($data['followupPatternCode'] ?? '')));
        if ($followupCode !== '') {
            update_user_meta((int) $userId, 'avina_crm_followup_pattern_code', $followupCode);
        }

        $permissions = isset($data['permissions']) && is_array($data['permissions'])
            ? $data['permissions']
            : ['dashboard', 'leads'];

        update_user_meta((int) $userId, 'avina_crm_operator_permissions', $permissions);

        $pageId = $this->createOperatorPage((int) $userId, $fullName !== '' ? $fullName : $username);
        $pageUrl = $pageId > 0 ? get_permalink($pageId) : '';

        $this->audit->record(
            $actorUserId,
            'operators.operator.create',
            'user',
            (string) $userId,
            null,
            ['username' => $username, 'email' => $email, 'page_id' => $pageId]
        );

        return [
            'user_id' => (int) $userId,
            'page_id' => $pageId,
            'page_url' => $pageUrl,
            'success' => true
        ];
    }

    /**
     * @return array<int, array{id: string, name: string, username: string, email: string, mobile: string, role: string, lastLogin: string, permissions: array, pageId: int, pageUrl: string}>
     */
    public function listOperators(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_operator_pages';

        // Check if table exists once using option flag
        if (!get_option('avina_crm_operator_pages_table_created')) {
            $this->ensureTableExists();
            update_option('avina_crm_operator_pages_table_created', '1');
        }

        // Seed default users once only
        if (!get_option('avina_crm_defaults_seeded')) {
            $this->ensureDefaultUsersExist();
        }

        $users = get_users(['number' => 500]);
        $result = [];

        foreach ($users as $user) {
            /** @var WP_User $user */
            $roles = (array) $user->roles;
            $roleLabel = 'viewer';
            if (in_array('administrator', $roles, true)) {
                $roleLabel = 'admin';
            } elseif (in_array('editor', $roles, true) || in_array(RoleProvisioner::ROLE_SLUG, $roles, true)) {
                $roleLabel = 'editor';
            }

            $permissions = get_user_meta($user->ID, 'avina_crm_operator_permissions', true);
            if (!is_array($permissions)) {
                $permissions = ($roleLabel === 'admin')
                    ? ['dashboard', 'settings', 'users', 'recruitment', 'inventory', 'customers', 'invoices', 'leads', 'expenses', 'cheques', 'reports', 'phonebook', 'ai-assistant', 'reception', 'tickets', 'tasks']
                    : ['dashboard', 'leads'];
            }

            $pageUrl = site_url('/crm-admin/?avina_crm_user_id=' . $user->ID);
            $pageId = (int) ($wpdb->get_var($wpdb->prepare("SELECT page_id FROM {$table} WHERE user_id = %d AND is_active = 1", $user->ID)) ?: 0);

            $result[] = [
                'id' => (string) $user->ID,
                'name' => $user->display_name ?: $user->user_login,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'mobile' => get_user_meta($user->ID, 'avina_crm_operator_mobile', true) ?: '',
                'landline' => (string) (get_user_meta($user->ID, 'avina_crm_landline', true) ?: ''),
                'address' => (string) (get_user_meta($user->ID, 'avina_crm_address', true) ?: ''),
                'birthCertImage' => (string) (get_user_meta($user->ID, 'avina_crm_birth_cert_image', true) ?: ''),
                'nationalCardImage' => (string) (get_user_meta($user->ID, 'avina_crm_national_card_image', true) ?: ''),
                'hasBirthCert' => !empty(get_user_meta($user->ID, 'avina_crm_birth_cert_image', true)),
                'hasNationalCard' => !empty(get_user_meta($user->ID, 'avina_crm_national_card_image', true)),
                'locationLat' => get_user_meta($user->ID, 'avina_crm_location_lat', true) ?: '35.6892',
                'locationLng' => get_user_meta($user->ID, 'avina_crm_location_lng', true) ?: '51.3890',
                'role' => $roleLabel,
                'lastLogin' => get_user_meta($user->ID, 'avina_crm_last_login', true) ?: current_time('mysql'),
                'permissions' => $permissions,
                'pageId' => $pageId,
                'pageUrl' => $pageUrl,
                'welcomePatternCode' => get_user_meta($user->ID, 'avina_crm_welcome_pattern_code', true) ?: '',
                'followupPatternCode' => get_user_meta($user->ID, 'avina_crm_followup_pattern_code', true) ?: '',
                'avatarUrl' => get_user_meta($user->ID, 'avina_crm_avatar_url', true) ?: '',
                'theme' => get_user_meta($user->ID, 'avina_crm_theme', true) ?: 'light',
                'operatorThemeConfig' => get_user_meta($user->ID, 'avina_crm_operator_theme_config', true) ?: null,
            ];
        }

        return $result;
    }

    public function ensureDefaultUsersExist(): void
    {
        if (get_option('avina_crm_defaults_seeded') === '1') {
            return;
        }

        $this->roles->ensureOperatorRole();

        // 1. Super Admin: m.fuladi@yahoo.com / 09138996197
        $admin_email = 'm.fuladi@yahoo.com';
        $admin_user = get_user_by('email', $admin_email);
        if (!$admin_user) {
            $admin_user = get_user_by('login', 'm.fuladi@yahoo.com');
        }

        $all_perms = ['dashboard', 'settings', 'users', 'recruitment', 'inventory', 'customers', 'invoices', 'leads', 'expenses', 'cheques', 'reports', 'phonebook', 'ai-assistant', 'reception', 'tickets', 'tasks'];

        if (!$admin_user) {
            $admin_id = wp_insert_user([
                'user_login' => 'm.fuladi@yahoo.com',
                'user_email' => 'm.fuladi@yahoo.com',
                'user_pass' => '09138996197',
                'display_name' => 'محمد فولادی (مدیر کل)',
                'role' => 'administrator',
            ]);
            if (!is_wp_error($admin_id)) {
                update_user_meta((int) $admin_id, 'avina_crm_operator_permissions', $all_perms);
                $this->createOperatorPage((int) $admin_id, 'محمد فولادی (مدیر کل)');
            }
        } else {
            update_user_meta($admin_user->ID, 'avina_crm_operator_permissions', $all_perms);
            $this->createOperatorPage((int) $admin_user->ID, 'محمد فولادی (مدیر کل)');
        }

        // 2. Test Operator: operator_test / operator@example.com / 123456
        $test_email = 'operator@example.com';
        $test_user = get_user_by('email', $test_email);
        if (!$test_user) {
            $test_user = get_user_by('login', 'operator_test');
        }

        if (!$test_user) {
            $test_id = wp_insert_user([
                'user_login' => 'operator_test',
                'user_email' => 'operator@example.com',
                'user_pass' => '123456',
                'display_name' => 'کاربر تست سیستم',
                'role' => RoleProvisioner::ROLE_SLUG,
            ]);
            if (!is_wp_error($test_id)) {
                $op_perms = ['dashboard', 'leads', 'customers', 'reception', 'tasks'];
                update_user_meta((int) $test_id, 'avina_crm_operator_permissions', $op_perms);
                $this->createOperatorPage((int) $test_id, 'کاربر تست سیستم');
            }
        } else {
            $this->createOperatorPage((int) $test_user->ID, $test_user->display_name ?: $test_user->user_login);
        }

        update_option('avina_crm_defaults_seeded', '1');
    }

    /**
     * @param array{full_name?: string, username?: string, email?: string, password?: string, mobile?: string, permissions?: array} $data
     * @return array{user_id: int, success: bool}|WP_Error
     */
    public function updateOperator(int $userId, array $data, int $actorUserId)
    {
        global $wpdb;
        $user = get_userdata($userId);
        if (!$user) {
            return new WP_Error(
                'avina_crm_user_not_found',
                __('کاربر مورد نظر یافت نشد.', 'avina-crm'),
                ['status' => 404]
            );
        }

        // Suppress email notifications during programmatic updates
        add_filter('send_password_change_email', '__return_false', 999);
        add_filter('send_email_change_email', '__return_false', 999);

        // 1. If username was provided and changed, update wp_users table directly
        if (!empty($data['username'])) {
            $newUsername = sanitize_user(self::toEnglishDigits($data['username']), true);
            if ($newUsername !== '' && $newUsername !== $user->user_login) {
                $existingUser = username_exists($newUsername);
                if ($existingUser && (int) $existingUser !== $userId) {
                    return new WP_Error(
                        'avina_crm_username_exists',
                        __('این نام کاربری توسط کاربر دیگری استفاده می‌شود.', 'avina-crm'),
                        ['status' => 409]
                    );
                }
                $wpdb->update(
                    $wpdb->users,
                    ['user_login' => $newUsername, 'user_nicename' => $newUsername],
                    ['ID' => $userId]
                );
                clean_user_cache($userId);
                $user = get_userdata($userId);
            }
        }

        $userdata = ['ID' => $userId];

        if (!empty($data['full_name'])) {
            $userdata['display_name'] = sanitize_text_field($data['full_name']);
            update_user_meta($userId, 'first_name', sanitize_text_field($data['full_name']));
        }
        if (!empty($data['email'])) {
            $email = sanitize_email(self::toEnglishDigits($data['email']));
            if (is_email($email)) {
                $existingEmailUser = email_exists($email);
                if (!$existingEmailUser || (int)$existingEmailUser === $userId) {
                    $userdata['user_email'] = $email;
                }
            }
        }
        if (!empty($data['password'])) {
            $cleanPass = self::toEnglishDigits(trim((string)$data['password']));
            if ($cleanPass !== '') {
                wp_set_password($cleanPass, $userId);
                if ($userId === get_current_user_id() && !headers_sent()) {
                    wp_set_current_user($userId);
                    wp_set_auth_cookie($userId, true);
                }
            }
        }

        // Only run wp_update_user if display_name or email changed (do NOT pass user_pass)
        if (isset($userdata['display_name']) || isset($userdata['user_email'])) {
            $updated = wp_update_user($userdata);
            if (is_wp_error($updated)) {
                if ($updated->get_error_code() === 'empty_user_login') {
                    return $updated;
                }
            }
        }

        if (!empty($data['mobile'])) {
            update_user_meta($userId, 'avina_crm_operator_mobile', sanitize_text_field(self::toEnglishDigits($data['mobile'])));
        }

        if (isset($data['landline'])) {
            update_user_meta($userId, 'avina_crm_landline', sanitize_text_field(self::toEnglishDigits((string)$data['landline'])));
        }

        if (isset($data['address'])) {
            update_user_meta($userId, 'avina_crm_address', sanitize_textarea_field((string)$data['address']));
        }

        $birthCert = $data['birth_cert_image'] ?? ($data['birthCertImage'] ?? null);
        if ($birthCert !== null) {
            update_user_meta($userId, 'avina_crm_birth_cert_image', wp_strip_all_tags((string)$birthCert));
        }

        $nationalCard = $data['national_card_image'] ?? ($data['nationalCardImage'] ?? null);
        if ($nationalCard !== null) {
            update_user_meta($userId, 'avina_crm_national_card_image', wp_strip_all_tags((string)$nationalCard));
        }

        $lat = $data['location_lat'] ?? ($data['locationLat'] ?? null);
        if ($lat !== null) {
            update_user_meta($userId, 'avina_crm_location_lat', sanitize_text_field((string)$lat));
        }

        $lng = $data['location_lng'] ?? ($data['locationLng'] ?? null);
        if ($lng !== null) {
            update_user_meta($userId, 'avina_crm_location_lng', sanitize_text_field((string)$lng));
        }

        if (isset($data['permissions']) && is_array($data['permissions'])) {
            update_user_meta($userId, 'avina_crm_operator_permissions', $data['permissions']);
        }

        $wCode = $data['welcome_pattern_code'] ?? ($data['welcomePatternCode'] ?? null);
        if ($wCode !== null) {
            update_user_meta($userId, 'avina_crm_welcome_pattern_code', sanitize_text_field((string)$wCode));
        }

        $fCode = $data['followup_pattern_code'] ?? ($data['followupPatternCode'] ?? null);
        if ($fCode !== null) {
            update_user_meta($userId, 'avina_crm_followup_pattern_code', sanitize_text_field((string)$fCode));
        }

        if (isset($data['avatarUrl'])) {
            update_user_meta($userId, 'avina_crm_avatar_url', wp_strip_all_tags((string)$data['avatarUrl']));
        }

        if (isset($data['theme']) && in_array($data['theme'], ['light', 'dark', 'gold'], true)) {
            update_user_meta($userId, 'avina_crm_theme', sanitize_text_field((string)$data['theme']));
        }

        if (isset($data['operatorThemeConfig']) && is_array($data['operatorThemeConfig'])) {
            update_user_meta($userId, 'avina_crm_operator_theme_config', $data['operatorThemeConfig']);
        }

        if ($userId === get_current_user_id() && !headers_sent()) {
            wp_set_current_user($userId);
            wp_set_auth_cookie($userId, true);
        }

        if (!\AvinaCRM\Support\Scope::isAdmin($userId)) {
            $this->createOperatorPage($userId, $user->display_name ?: $user->user_login);
        }

        try {
            $this->audit->record(
                $actorUserId,
                'operators.operator.update',
                'user',
                (string) $userId,
                null,
                ['user_id' => $userId]
            );
        } catch (\Throwable $e) {}

        return ['user_id' => $userId, 'success' => true];
    }

    public function createOperatorPage(int $userId, string $displayName): int
    {
        global $wpdb;
        $this->ensureTableExists();

        $table = $wpdb->prefix . 'avina_operator_pages';
        $existingPageId = (int) $wpdb->get_var($wpdb->prepare("SELECT page_id FROM {$table} WHERE user_id = %d AND is_active = 1", $userId));

        if ($existingPageId > 0 && get_post($existingPageId)) {
            return $existingPageId;
        }

        $pageId = wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'private',
            'post_title' => sprintf(
                /* translators: %s: operator display name */
                __('پنل آوینا CRM — %s', 'avina-crm'),
                $displayName
            ),
            'post_content' => sprintf('[avina_crm_user user_id="%d"]', $userId),
        ], true);

        if (is_wp_error($pageId)) {
            return 0;
        }

        $wpdb->replace(
            $table,
            [
                'user_id' => $userId,
                'page_id' => (int) $pageId,
                'is_active' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%d', '%d', '%d', '%s', '%s']
        );

        return (int) $pageId;
    }
}
