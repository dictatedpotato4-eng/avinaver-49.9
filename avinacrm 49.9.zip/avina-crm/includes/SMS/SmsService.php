<?php

declare(strict_types=1);

namespace AvinaCRM\SMS;

use AvinaCRM\Audit\AuditLogger;

final class SmsService
{
    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function sanitizePhone(string $phone): string
    {
        $phone = preg_replace('/\s+/', '', $phone);
        $phone = str_replace(['+98', '0098'], '0', $phone);
        if (preg_match('/^9[0-9]{9}$/', $phone)) {
            $phone = '0' . $phone;
        }
        if (preg_match('/^09[0-9]{9}$/', $phone)) {
            return $phone;
        }
        return '';
    }

    /**
     * Send Single or Bulk SMS via IPPanel.com REST API (with Multi-Strategy Fallback)
     */
    public function sendIpPanelSms(
        string $apiKey,
        string $sender,
        array $recipients,
        string $message,
        int $actorUserId = 0,
        string $authMode = 'apikey',
        string $username = '',
        string $password = '',
        string $sendTime = '',
        string $source = ''
    ): array {
        if (empty($apiKey) && !empty($username) && !empty($password)) {
            $authMode = 'credentials';
        } elseif (!empty($apiKey) && (empty($username) || empty($password))) {
            $authMode = 'apikey';
        }

        if (empty($apiKey) && (empty($username) || empty($password))) {
            return [
                'success' => false,
                'code' => 400,
                'response' => '',
                'error' => 'اطلاعات احراز هویت IPPanel (کلید API یا نام کاربری و رمز عبور) وارد نشده است.'
            ];
        }

        if (empty($message)) {
            return [
                'success' => false,
                'code' => 400,
                'response' => '',
                'error' => 'متن پیامک خالی است.'
            ];
        }

        $cleanedRecipients = [];
        foreach ($recipients as $rec) {
            $cleaned = $this->sanitizePhone((string)$rec);
            if ($cleaned !== '') {
                $cleanedRecipients[] = $cleaned;
            }
        }

        if (empty($cleanedRecipients)) {
            return [
                'success' => false,
                'code' => 400,
                'response' => '',
                'error' => 'شماره همراه معتبری برای دریافت‌کننده یافت نشد.'
            ];
        }

        $chunks = array_chunk($cleanedRecipients, 100);
        $totalSent = 0;
        $lastResult = null;

        foreach ($chunks as $chunkRecipients) {
            $lastResult = $this->sendSingleBatchIpPanelSms(
                $apiKey,
                $sender,
                $chunkRecipients,
                $message,
                $actorUserId,
                $authMode,
                $username,
                $password,
                $sendTime,
                $source
            );
            if (!$lastResult['success']) {
                return $lastResult;
            }
            $totalSent += ($lastResult['sent_count'] ?? count($chunkRecipients));
        }

        return [
            'success' => true,
            'code' => 200,
            'response' => $lastResult['response'] ?? '',
            'error' => '',
            'sent_count' => $totalSent
        ];
    }

    /**
     * Send a single batch of up to 100 recipients via IPPanel.com APIs
     */
    private function sendSingleBatchIpPanelSms(
        string $apiKey,
        string $sender,
        array $cleanedRecipients,
        string $message,
        int $actorUserId = 0,
        string $authMode = 'apikey',
        string $username = '',
        string $password = '',
        string $sendTime = '',
        string $source = ''
    ): array {
        $originator = !empty($sender) ? trim($sender) : '+983000505';
        $originatorsToTry = [$originator];
        $cleanOrig = ltrim($originator, '+');
        if (str_starts_with($cleanOrig, '98') && strlen($cleanOrig) > 5) {
            $raw = substr($cleanOrig, 2);
            $originatorsToTry[] = '+' . $cleanOrig;
            $originatorsToTry[] = $cleanOrig;
            $originatorsToTry[] = $raw;
            $originatorsToTry[] = '0' . $raw;
        } elseif (str_starts_with($cleanOrig, '0') && strlen($cleanOrig) > 5) {
            $raw = substr($cleanOrig, 1);
            $originatorsToTry[] = '+98' . $raw;
            $originatorsToTry[] = '98' . $raw;
            $originatorsToTry[] = $cleanOrig;
            $originatorsToTry[] = $raw;
        } else {
            $originatorsToTry[] = '+98' . $cleanOrig;
            $originatorsToTry[] = '98' . $cleanOrig;
            $originatorsToTry[] = '0' . $cleanOrig;
            $originatorsToTry[] = $cleanOrig;
        }
        $originatorsToTry = array_values(array_unique(array_filter($originatorsToTry)));

        // --- Strategy 1: Credentials via IPPanel Select API (ippanel.com/api/select) ---
        if ($authMode === 'credentials' || (!empty($username) && !empty($password))) {
            $url = 'https://ippanel.com/api/select';
            foreach ($originatorsToTry as $orig) {
                $body = [
                    'op' => 'send',
                    'uname' => trim($username),
                    'pass' => trim($password),
                    'from' => $orig,
                    'to' => $cleanedRecipients,
                    'message' => $message
                ];

                $response = wp_remote_post($url, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'body' => wp_json_encode($body),
                    'timeout' => 15,
                ]);

                if (!is_wp_error($response)) {
                    $code = wp_remote_retrieve_response_code($response);
                    $resBody = wp_remote_retrieve_body($response);
                    $decoded = json_decode($resBody, true);

                    if (is_array($decoded) && isset($decoded[0]) && (is_numeric($decoded[0]) || $decoded[0] > 100)) {
                        if (isset($decoded[1]) && is_string($decoded[1]) && (str_contains(strtolower($decoded[1]), 'error') || str_contains(strtolower($decoded[1]), 'incorrect') || str_contains(strtolower($decoded[1]), 'empty'))) {
                            continue; // Try next originator candidate
                        }

                        $this->audit->record($actorUserId, 'sms.send_success', 'sms', implode(',', $cleanedRecipients), null, ['count' => count($cleanedRecipients), 'source' => $source]);
                        $logType = !empty($source) ? $source : (count($cleanedRecipients) > 1 ? 'bulk' : 'single');
                        $logRec = count($cleanedRecipients) > 1 ? 'ارسال گروهی به ' . count($cleanedRecipients) . ' مخاطب (' . implode(', ', array_slice($cleanedRecipients, 0, 3)) . '...)' : $cleanedRecipients[0];
                        $this->recordSmsLog($actorUserId, $logType, $logRec, $orig, 'custom', $message, true, (int)$code, $resBody);
                        return [
                            'success' => true,
                            'code' => $code,
                            'response' => $resBody,
                            'error' => '',
                            'sent_count' => count($cleanedRecipients)
                        ];
                    }
                }
            }
        }

        if (!empty($apiKey)) {
            // --- Strategy 2: AccessKey via IPPanel REST API (api.ippanel.com/v1/messages and rest.ippanel.com/v1/messages) ---
            $restUrls = [
                'https://api.ippanel.com/v1/messages',
                'https://rest.ippanel.com/v1/messages'
            ];

            foreach ($restUrls as $url1) {
                foreach ($originatorsToTry as $orig) {
                    $body1 = [
                        'originator' => $orig,
                        'recipients' => $cleanedRecipients,
                        'message' => $message
                    ];
                    if (!empty($sendTime)) {
                        $body1['send_time'] = $sendTime;
                    }

                    $response1 = wp_remote_post($url1, [
                        'headers' => [
                            'Authorization' => 'AccessKey ' . trim($apiKey),
                            'Content-Type' => 'application/json'
                        ],
                        'body' => wp_json_encode($body1),
                        'timeout' => 15,
                    ]);

                    if (!is_wp_error($response1)) {
                        $code1 = wp_remote_retrieve_response_code($response1);
                        $resBody1 = wp_remote_retrieve_body($response1);

                        if ($code1 >= 200 && $code1 < 300 && !empty($resBody1) && !str_contains($resBody1, 'Cloudflare') && !str_contains($resBody1, '502 Bad Gateway') && !str_contains($resBody1, '404 Not Found')) {
                            $dec1 = json_decode($resBody1, true);
                            if (is_array($dec1) && isset($dec1['status']) && strtolower((string)$dec1['status']) === 'error') {
                                $lastError = 'خطای IPPanel: ' . ($dec1['error'] ?? $dec1['message'] ?? 'خطا در ارسال');
                                continue;
                            }
                            $this->audit->record($actorUserId, 'sms.send_success', 'sms', implode(',', $cleanedRecipients), null, ['count' => count($cleanedRecipients), 'source' => $source]);
                            $logType = !empty($source) ? $source : (count($cleanedRecipients) > 1 ? 'bulk' : 'single');
                            $logRec = count($cleanedRecipients) > 1 ? 'ارسال گروهی به ' . count($cleanedRecipients) . ' مخاطب (' . implode(', ', array_slice($cleanedRecipients, 0, 3)) . '...)' : $cleanedRecipients[0];
                            $this->recordSmsLog($actorUserId, $logType, $logRec, $orig, 'custom', $message, true, (int)$code1, $resBody1);
                            return [
                                'success' => true,
                                'code' => $code1,
                                'response' => $resBody1,
                                'error' => '',
                                'sent_count' => count($cleanedRecipients)
                            ];
                        }
                    }
                }
            }

            // --- Strategy 3: AccessKey via IPPanel Select API (ippanel.com/api/select) ---
            $url2 = 'https://ippanel.com/api/select';
            foreach ($originatorsToTry as $orig) {
                $body2 = [
                    'op' => 'send',
                    'uname' => 'apikey',
                    'pass' => trim($apiKey),
                    'from' => $orig,
                    'to' => $cleanedRecipients,
                    'message' => $message
                ];
                if (!empty($sendTime)) {
                    $body2['time'] = $sendTime;
                }

                $response2 = wp_remote_post($url2, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'body' => wp_json_encode($body2),
                    'timeout' => 15,
                ]);

                if (!is_wp_error($response2)) {
                    $code2 = wp_remote_retrieve_response_code($response2);
                    $resBody2 = wp_remote_retrieve_body($response2);

                    if ($code2 >= 200 && $code2 < 300) {
                        $decoded = json_decode($resBody2, true);
                        if (is_array($decoded) && isset($decoded[0]) && (is_numeric($decoded[0]) || $decoded[0] > 100)) {
                            if (isset($decoded[1]) && is_string($decoded[1]) && (str_contains(strtolower($decoded[1]), 'error') || str_contains(strtolower($decoded[1]), 'incorrect') || str_contains(strtolower($decoded[1]), 'empty'))) {
                                continue;
                            }

                            $this->audit->record($actorUserId, 'sms.send_success', 'sms', implode(',', $cleanedRecipients), null, ['count' => count($cleanedRecipients)]);
                            $logType = count($cleanedRecipients) > 1 ? 'bulk' : 'single';
                            $logRec = count($cleanedRecipients) > 1 ? 'ارسال گروهی به ' . count($cleanedRecipients) . ' مخاطب (' . implode(', ', array_slice($cleanedRecipients, 0, 3)) . '...)' : $cleanedRecipients[0];
                            $this->recordSmsLog($actorUserId, $logType, $logRec, $orig, 'custom', $message, true, (int)$code2, $resBody2);
                            return [
                                'success' => true,
                                'code' => $code2,
                                'response' => $resBody2,
                                'error' => '',
                                'sent_count' => count($cleanedRecipients)
                            ];
                        }
                    }
                }
            }
        }

        $lastCode = isset($code1) ? $code1 : (isset($code2) ? $code2 : 500);
        $lastBody = isset($resBody1) && !empty($resBody1) ? $resBody1 : (isset($resBody2) ? $resBody2 : 'ارتباط با سامانه IPPanel برقرار نشد.');
        $errorMsg = "خطا در ارسال پیامک از IPPanel (کد: $lastCode): " . strip_tags($lastBody);
        
        $this->audit->record($actorUserId, 'sms.send_failed', 'sms', implode(',', $cleanedRecipients), null, ['error' => $errorMsg]);
        $logType = count($cleanedRecipients) > 1 ? 'bulk' : 'single';
        $logRec = count($cleanedRecipients) > 1 ? 'ارسال گروهی به ' . count($cleanedRecipients) . ' مخاطب' : $cleanedRecipients[0];
        $this->recordSmsLog($actorUserId, $logType, $logRec, $originator, 'custom', $message, false, (int)$lastCode, $lastBody);

        return [
            'success' => false,
            'code' => $lastCode,
            'response' => $lastBody,
            'error' => $errorMsg
        ];
    }

    /**
     * Send Pattern SMS via IPPanel.com REST/Select/URL APIs (with resilient Fallbacks & Originator Normalization)
     */
    public function sendIpPanelPatternSms(
        string $apiKey,
        string $sender,
        string $recipient,
        string $patternCode,
        array $variables,
        int $actorUserId = 0,
        string $authMode = 'apikey',
        string $username = '',
        string $password = ''
    ): array {
        $cleanRecipient = $this->sanitizePhone($recipient);
        if (empty($cleanRecipient)) {
            $this->recordSmsLog($actorUserId, 'pattern', $recipient, $sender, $patternCode, $variables, false, 400, 'شماره همراه معتبری برای دریافت‌کننده یافت نشد.');
            return [
                'success' => false,
                'code' => 400,
                'response' => '',
                'error' => 'شماره همراه معتبری برای دریافت‌کننده یافت نشد.'
            ];
        }

        $originator = !empty($sender) ? trim($sender) : '+983000505';
        $patternCode = trim($patternCode);

        // Ensure string key/value formatting for variables and enrich with case/alias key variants
        // to ensure compatibility with any IPPanel pattern variable name (%code%, %Cod%, %cod%, %name%, etc.)
        $cleanVars = [];
        if (is_array($variables)) {
            foreach ($variables as $k => $v) {
                $strKey = trim((string)$k);
                if ($strKey === '') continue;
                $strVal = is_scalar($v) ? (string)$v : wp_json_encode($v);
                $cleanVars[$strKey] = (string)$strVal;
            }
        }
        $varsPayload = empty($cleanVars) ? (object)[] : $cleanVars;

        $lastError = '';
        $lastCode = 500;
        $lastResponse = '';

        // Prepare list of originator candidates (+983000505, 3000505, 983000505)
        $originatorsToTry = [$originator];
        $cleanOrigP = ltrim($originator, '+');
        if (str_starts_with($cleanOrigP, '98') && strlen($cleanOrigP) > 5) {
            $rawP = substr($cleanOrigP, 2);
            $originatorsToTry[] = '+' . $cleanOrigP;
            $originatorsToTry[] = $cleanOrigP;
            $originatorsToTry[] = $rawP;
        } else {
            $originatorsToTry[] = '+98' . $cleanOrigP;
            $originatorsToTry[] = '98' . $cleanOrigP;
            $originatorsToTry[] = $cleanOrigP;
        }
        $originatorsToTry = array_values(array_unique(array_filter($originatorsToTry)));

        // --- Strategy 1: Credentials via IPPanel Select API (https://ippanel.com/api/select) ---
        if (!empty($username) && !empty($password)) {
            $url = 'https://ippanel.com/api/select';
            foreach ($originatorsToTry as $orig) {
                $body = [
                    'op' => 'pattern',
                    'user' => trim($username),
                    'pass' => trim($password),
                    'fromNum' => $orig,
                    'toNum' => $cleanRecipient,
                    'patternCode' => $patternCode,
                    'inputData' => $varsPayload
                ];

                $response = wp_remote_post($url, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'body' => wp_json_encode($body),
                    'timeout' => 15,
                ]);

                if (!is_wp_error($response)) {
                    $code = wp_remote_retrieve_response_code($response);
                    $resBody = wp_remote_retrieve_body($response);
                    $decoded = json_decode($resBody, true);

                    if (is_numeric($resBody) && (float)$resBody > 100) {
                        $this->audit->record($actorUserId, 'sms.pattern_send_success', 'sms', $cleanRecipient, null, ['pattern' => $patternCode]);
                        $this->recordSmsLog($actorUserId, 'pattern', $cleanRecipient, $orig, $patternCode, $cleanVars, true, (int)$code, $resBody);
                        return [
                            'success' => true,
                            'code' => $code,
                            'response' => $resBody,
                            'error' => '',
                            'sent_count' => 1
                        ];
                    }

                    if (is_array($decoded) && isset($decoded[0])) {
                        $firstVal = $decoded[0];
                        if (is_numeric($firstVal) && (float)$firstVal > 100 && !isset($decoded[1])) {
                            $this->audit->record($actorUserId, 'sms.pattern_send_success', 'sms', $cleanRecipient, null, ['pattern' => $patternCode]);
                            $this->recordSmsLog($actorUserId, 'pattern', $cleanRecipient, $orig, $patternCode, $cleanVars, true, (int)$code, $resBody);
                            return [
                                'success' => true,
                                'code' => $code,
                                'response' => $resBody,
                                'error' => '',
                                'sent_count' => 1
                            ];
                        }

                        if (isset($decoded[1]) && is_string($decoded[1])) {
                            $lastError = 'سامانه الگو IPPanel: ' . $decoded[1] . ' (کد: ' . $firstVal . ')';
                            $lastCode = is_numeric($firstVal) ? (int)$firstVal : $code;
                            $lastResponse = $resBody;
                        }
                    }
                }
            }
        }

        // --- Strategy 2: API Key via IPPanel REST API v1 (https://api.ippanel.com/v1/messages/patterns/send) ---
        if (!empty($apiKey)) {
            $endpoints = [
                'https://api.ippanel.com/v1/messages/patterns/send',
                'https://rest.ippanel.com/v1/messages/patterns/send'
            ];
            foreach ($endpoints as $url1) {
                foreach ($originatorsToTry as $orig) {
                    $body1 = [
                        'pattern_code' => $patternCode,
                        'originator' => $orig,
                        'recipient' => $cleanRecipient,
                        'values' => $varsPayload
                    ];

                    $response1 = wp_remote_post($url1, [
                        'headers' => [
                            'Authorization' => 'AccessKey ' . trim($apiKey),
                            'Content-Type' => 'application/json'
                        ],
                        'body' => wp_json_encode($body1),
                        'timeout' => 15,
                    ]);

                    if (!is_wp_error($response1)) {
                        $code1 = wp_remote_retrieve_response_code($response1);
                        $resBody1 = wp_remote_retrieve_body($response1);

                        if ($code1 >= 200 && $code1 < 300 && !empty($resBody1) && !str_contains($resBody1, 'Cloudflare') && !str_contains($resBody1, '502 Bad Gateway') && !str_contains($resBody1, '404 Not Found')) {
                            $this->audit->record($actorUserId, 'sms.pattern_send_success', 'sms', $cleanRecipient, null, ['pattern' => $patternCode]);
                            $this->recordSmsLog($actorUserId, 'pattern', $cleanRecipient, $orig, $patternCode, $cleanVars, true, (int)$code1, $resBody1);
                            return [
                                'success' => true,
                                'code' => $code1,
                                'response' => $resBody1,
                                'error' => '',
                                'sent_count' => 1
                            ];
                        }

                        if (!empty($resBody1) && !str_contains($resBody1, 'Cloudflare') && !str_contains($resBody1, '502 Bad Gateway')) {
                            $lastError = 'سامانه الگو IPPanel: ' . strip_tags($resBody1);
                            $lastCode = $code1;
                            $lastResponse = $resBody1;
                        }
                    }
                }
            }
        }

        // --- Strategy 3: URL Pattern Endpoint (http://ippanel.com/patterns/pattern) ---
        $authParamUser = !empty($username) ? trim($username) : trim($apiKey);
        $authParamPass = !empty($password) ? trim($password) : trim($apiKey);

        if (!empty($authParamUser) && !empty($authParamPass)) {
            $url3 = 'http://ippanel.com/patterns/pattern';
            foreach ($originatorsToTry as $orig) {
                $queryParams = [
                    'username' => $authParamUser,
                    'password' => $authParamPass,
                    'from' => $orig,
                    'to' => $cleanRecipient,
                    'pid' => $patternCode,
                    'inputData' => wp_json_encode($varsPayload)
                ];
                $url3WithParams = add_query_arg($queryParams, $url3);

                $response3 = wp_remote_get($url3WithParams, ['timeout' => 15]);
                if (!is_wp_error($response3)) {
                    $code3 = wp_remote_retrieve_response_code($response3);
                    $resBody3 = wp_remote_retrieve_body($response3);
                    $decoded3 = json_decode($resBody3, true);

                    if (is_numeric($resBody3) && (float)$resBody3 > 100) {
                        $this->audit->record($actorUserId, 'sms.pattern_send_success', 'sms', $cleanRecipient, null, ['pattern' => $patternCode]);
                        $this->recordSmsLog($actorUserId, 'pattern', $cleanRecipient, $orig, $patternCode, $cleanVars, true, (int)$code3, $resBody3);
                        return [
                            'success' => true,
                            'code' => $code3,
                            'response' => $resBody3,
                            'error' => '',
                            'sent_count' => 1
                        ];
                    }

                    if (is_array($decoded3) && isset($decoded3[0])) {
                        $firstVal = $decoded3[0];
                        if (is_numeric($firstVal) && (float)$firstVal > 100 && !isset($decoded3[1])) {
                            $this->audit->record($actorUserId, 'sms.pattern_send_success', 'sms', $cleanRecipient, null, ['pattern' => $patternCode]);
                            $this->recordSmsLog($actorUserId, 'pattern', $cleanRecipient, $orig, $patternCode, $cleanVars, true, (int)$code3, $resBody3);
                            return [
                                'success' => true,
                                'code' => $code3,
                                'response' => $resBody3,
                                'error' => '',
                                'sent_count' => 1
                            ];
                        }

                        if (isset($decoded3[1]) && is_string($decoded3[1])) {
                            $lastError = 'سامانه الگو IPPanel: ' . $decoded3[1] . ' (کد: ' . $firstVal . ')';
                            $lastCode = is_numeric($firstVal) ? (int)$firstVal : $code3;
                            $lastResponse = $resBody3;
                        }
                    }
                }
            }
        }

        if (empty($lastError)) {
            $lastError = 'ارتباط با سامانه الگو IPPanel برقرار نشد. لطفاً نام کاربری/رمز عبور یا API Key را در تنظیمات پیامک بررسی کنید.';
        }

        $this->audit->record($actorUserId, 'sms.pattern_send_failed', 'sms', $cleanRecipient, null, ['code' => $lastCode, 'response' => $lastResponse]);
        $this->recordSmsLog($actorUserId, 'pattern', $cleanRecipient, $originator, $patternCode, $cleanVars, false, (int)$lastCode, $lastResponse . ' | ' . $lastError);

        return [
            'success' => false,
            'code' => $lastCode,
            'response' => $lastResponse,
            'error' => $lastError
        ];
    }

    /**
     * Automatically save contact name & number into IPPanel phonebook
     */
    public function addPhonebookContact(
        string $apiKey,
        string $phonebookId,
        string $name,
        string $phone,
        int $actorUserId = 0
    ): array {
        if (empty($apiKey) || empty($phonebookId)) {
            return [
                'success' => false,
                'code' => 400,
                'response' => '',
                'error' => 'تنظیمات API Key یا شناسه دفترچه تلفن IPPanel کامل نیست.'
            ];
        }

        $cleanPhone = $this->sanitizePhone($phone);
        if (empty($cleanPhone)) {
            return [
                'success' => false,
                'code' => 400,
                'response' => '',
                'error' => 'شماره همراه معتبر نیست.'
            ];
        }

        $cleanName = trim($name) !== '' ? trim($name) : 'مخاطب جدید';
        $url = 'https://api.ippanel.com/v1/phonebooks/' . rawurlencode($phonebookId) . '/contacts';

        $body = [
            'number' => $cleanPhone,
            'first_name' => $cleanName,
            'last_name' => ''
        ];

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'AccessKey ' . trim($apiKey),
                'Content-Type' => 'application/json'
            ],
            'body' => wp_json_encode($body),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'code' => 500,
                'response' => '',
                'error' => $response->get_error_message()
            ];
        }

        $code = wp_remote_retrieve_response_code($response);
        $resBody = wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            $this->audit->record($actorUserId, 'sms.phonebook_contact_added', 'sms', $cleanPhone, null, ['name' => $cleanName]);
            return [
                'success' => true,
                'code' => $code,
                'response' => $resBody,
                'error' => ''
            ];
        }

        return [
            'success' => false,
            'code' => $code,
            'response' => $resBody,
            'error' => "کد خطا HTTP $code هنگام ذخیره در دفترچه تلفن IPPanel: $resBody"
        ];
    }

    /**
     * Schedule Pattern 2 SMS to be sent 24h later at 9:00 AM
     */
    public function scheduleFollowupPatternSms(
        int $contactId,
        string $phone,
        string $patternCode,
        array $variables,
        int $operatorUserId = 0
    ): void {
        $cleanPhone = $this->sanitizePhone($phone);
        if (empty($cleanPhone) || empty($patternCode)) {
            return;
        }

        // Target time: Exactly 24 hours later
        $targetTime = date('Y-m-d H:i:s', strtotime('+24 hours', current_time('timestamp')));

        $queue = get_option('avina_crm_scheduled_sms_queue', []);
        if (!is_array($queue)) {
            $queue = [];
        }

        $queue[] = [
            'id' => uniqid('sms_'),
            'contact_id' => $contactId,
            'phone' => $cleanPhone,
            'pattern_code' => trim($patternCode),
            'variables' => $variables,
            'operator_user_id' => $operatorUserId,
            'scheduled_at' => $targetTime,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
        ];

        update_option('avina_crm_scheduled_sms_queue', $queue);
    }

    /**
     * Process due scheduled SMS items (invoked by WP Cron)
     */
    public function processScheduledSmsQueue(): void
    {
        $queue = get_option('avina_crm_scheduled_sms_queue', []);
        if (empty($queue) || !is_array($queue)) {
            return;
        }

        $appData = get_option('avina_crm_app_data', []);
        $smsSettings = $appData['settings']['sms'] ?? [];
        $apiKey = sanitize_text_field((string)($smsSettings['apiKey'] ?? ''));
        $sender = sanitize_text_field((string)($smsSettings['senderNumber'] ?? ''));
        $authMode = sanitize_text_field((string)($smsSettings['authMode'] ?? 'apikey'));
        $username = sanitize_text_field((string)($smsSettings['username'] ?? ''));
        $password = sanitize_text_field((string)($smsSettings['password'] ?? ''));

        $now = current_time('mysql');
        $updated = false;

        foreach ($queue as &$item) {
            if (($item['status'] ?? '') === 'pending' && !empty($item['scheduled_at']) && $item['scheduled_at'] <= $now) {
                $phone = (string)($item['phone'] ?? '');
                $patternCode = (string)($item['pattern_code'] ?? '');
                $variables = is_array($item['variables'] ?? null) ? $item['variables'] : [];
                $actorUserId = (int)($item['operator_user_id'] ?? 0);

                $sentSuccess = false;
                $resStr = '';

                // Strictly dispatch pattern code only - no unsolicited text fallback
                if (!empty($patternCode)) {
                    $result = $this->sendIpPanelPatternSms($apiKey, $sender, $phone, $patternCode, $variables, $actorUserId, $authMode, $username, $password);
                    if (!empty($result['success'])) {
                        $sentSuccess = true;
                        $resStr = (string)($result['response'] ?? '');
                    }
                }

                $item['status'] = $sentSuccess ? 'sent' : 'failed';
                $item['processed_at'] = current_time('mysql');
                $item['response'] = $resStr;
                $updated = true;
            }
        }
        unset($item);

        if ($updated) {
            if (count($queue) > 500) {
                $queue = array_slice($queue, -500);
            }
            update_option('avina_crm_scheduled_sms_queue', $queue);
        }
    }

    /**
     * Cancel pending scheduled SMS for a specific recipient mobile number and optional source
     */
    public function cancelScheduledSmsByPhone(string $phone, string $sourcePrefix = ''): int
    {
        $cleanPhone = $this->sanitizePhone($phone);
        if (empty($cleanPhone)) {
            return 0;
        }

        $queue = get_option('avina_crm_scheduled_sms_queue', []);
        if (empty($queue) || !is_array($queue)) {
            return 0;
        }

        $cancelledCount = 0;
        $newQueue = [];

        foreach ($queue as $item) {
            $itemPhone = $this->sanitizePhone((string)($item['phone'] ?? ''));
            $itemSource = (string)($item['source'] ?? '');

            $matchesPhone = ($itemPhone === $cleanPhone);
            $matchesSource = empty($sourcePrefix) || str_starts_with($itemSource, $sourcePrefix);

            if ($matchesPhone && $matchesSource && ($item['status'] ?? '') === 'pending') {
                $cancelledCount++;
                continue;
            }
            $newQueue[] = $item;
        }

        if ($cancelledCount > 0) {
            update_option('avina_crm_scheduled_sms_queue', $newQueue);
        }

        return $cancelledCount;
    }

    public function ensureLogsTableExists(): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_sms_logs';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
          user_id VARCHAR(100) NOT NULL DEFAULT '0',
          sms_type VARCHAR(50) NOT NULL DEFAULT 'pattern',
          recipient VARCHAR(50) NOT NULL,
          sender VARCHAR(50) NOT NULL DEFAULT '',
          pattern_code VARCHAR(100) NOT NULL DEFAULT '',
          content TEXT NULL,
          status VARCHAR(20) NOT NULL DEFAULT 'pending',
          response_code INT NOT NULL DEFAULT 0,
          api_response TEXT NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY user_id (user_id),
          KEY sms_type (sms_type),
          KEY status (status),
          KEY created_at (created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function recordSmsLog(
        $userId,
        string $smsType,
        string $recipient,
        string $sender,
        string $patternCode,
        $content,
        bool $success,
        int $responseCode,
        string $apiResponse
    ): void {
        try {
            global $wpdb;
            $table = $wpdb->prefix . 'avina_sms_logs';
            $this->ensureLogsTableExists();

            $contentStr = is_array($content) || is_object($content) ? wp_json_encode($content, JSON_UNESCAPED_UNICODE) : (string)$content;
            $userIdStr = sanitize_text_field((string)$userId);
            if ($userIdStr === '' || $userIdStr === '0') {
                $userIdStr = (string) get_current_user_id();
            }

            $wpdb->insert($table, [
                'user_id' => $userIdStr,
                'sms_type' => $smsType,
                'recipient' => $recipient,
                'sender' => $sender,
                'pattern_code' => $patternCode,
                'content' => $contentStr,
                'status' => $success ? 'success' : 'failed',
                'response_code' => $responseCode,
                'api_response' => mb_substr($apiResponse, 0, 2000),
                'created_at' => current_time('mysql'),
            ]);
        } catch (\Throwable $e) {
            // Ignore logging errors to prevent SMS failure
        }
    }

    public function getSmsLogs(int $limit = 150): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_sms_logs';
        $this->ensureLogsTableExists();

        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit), ARRAY_A);
        if (!is_array($rows)) {
            return [];
        }

        $appData = get_option('avina_crm_app_data', []);
        $appUsers = $appData['users'] ?? [];

        return array_map(function ($row) use ($appUsers) {
            $uIdStr = trim((string)($row['user_id'] ?? ''));
            $userName = '';

            if (is_array($appUsers)) {
                foreach ($appUsers as $au) {
                    $auId = trim((string)($au['id'] ?? ''));
                    $auUser = trim((string)($au['username'] ?? ''));
                    if ($uIdStr === $auId || $uIdStr === $auUser) {
                        $userName = $au['name'] ?? ($au['username'] ?? '');
                        break;
                    }
                }
            }

            if (empty($userName) && is_numeric($uIdStr) && (int)$uIdStr > 0) {
                $user = get_userdata((int)$uIdStr);
                if ($user) {
                    $userName = $user->display_name ?: $user->user_login;
                }
            }

            if (empty($userName)) {
                $userName = $uIdStr !== '' ? "اپراتور $uIdStr" : 'سیستم آوینا CRM';
            }

            $row['user_name'] = $userName;
            return $row;
        }, $rows);
    }

    public function deleteSmsLogs(?array $ids = null): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_sms_logs';
        $this->ensureLogsTableExists();

        if (empty($ids)) {
            // Delete all logs
            return (bool)$wpdb->query("TRUNCATE TABLE {$table}");
        }

        $cleanIds = array_filter(array_map('intval', $ids));
        if (empty($cleanIds)) {
            return false;
        }

        $idList = implode(',', $cleanIds);
        return (bool)$wpdb->query("DELETE FROM {$table} WHERE id IN ({$idList})");
    }
}
