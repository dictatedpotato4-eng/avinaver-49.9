<?php

declare(strict_types=1);

namespace AvinaCRM\Database;

use AvinaCRM\Modules\ModuleDefinitions;

/**
 * Schema versioning + migration runner.
 *
 * Idempotency: `run()` is safe to call on every `plugins_loaded` (Plugin::init()
 * calls it via maybeMigrate(), which short-circuits unless the stored
 * version option is behind DB_VERSION) and on activation. dbDelta() itself
 * is idempotent for CREATE TABLE (it diffs against the live schema), and
 * table seeding uses INSERT ... ON DUPLICATE KEY UPDATE keyed on a unique
 * column, so re-running never duplicates rows or clobbers data a user has
 * since changed (is_active is only touched on first insert, never on the
 * update branch — see seedModules()).
 *
 * This NEVER drops a table, NEVER deletes a row, and NEVER runs on
 * deactivation — only on activation and on a detected version increase
 * while the plugin is active.
 */
final class Migrator
{
    public const DB_VERSION = '6'; // Stage 6: v3.2 tables.
    public const OPTION_DB_VERSION = 'avina_crm_db_version';

    /** Modules whose real implementation landed in Stage 3. */
    private const STAGE_3_IMPLEMENTED_SLUGS = [
        'teams', 'contacts', 'customers', 'phonebook', 'reception',
        'activities', 'tasks', 'reminders', 'notifications', 'tickets',
    ];

    /** Modules whose real implementation landed in Stage 4. */
    private const STAGE_4_IMPLEMENTED_SLUGS = [
        'kanban', 'deals', 'invoices', 'payments',
    ];

    public function maybeMigrate(): bool
    {
        $current = get_option(self::OPTION_DB_VERSION, '0');

        if (version_compare((string) $current, self::DB_VERSION, '<')) {
            $this->run();
            return true;
        }

        return false;
    }

    public function run(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charsetCollate = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix;

        foreach (Schema::moduleDefinitions($prefix, $charsetCollate) as $sql) {
            dbDelta($sql);
        }

        foreach (Schema::businessDefinitions($prefix, $charsetCollate) as $sql) {
            dbDelta($sql);
        }

        foreach (Schema::salesDefinitions($prefix, $charsetCollate) as $sql) {
            dbDelta($sql);
        }

        foreach (Schema::integrationDefinitions($prefix, $charsetCollate) as $sql) {
            dbDelta($sql);
        }

        $this->seedModules();
        $this->activateImplementedModules();
        $this->seedDefaultData();

        update_option(self::OPTION_DB_VERSION, self::DB_VERSION, true);
    }

    /**
     * Explicitly flips is_active = 1 for the modules Stage 3 actually
     * implemented end-to-end. This is separate from seedModules()'s
     * INSERT ... ON DUPLICATE KEY UPDATE (which deliberately never
     * touches is_active after first insert, so a future administrator
     * toggle is never silently reverted by a routine plugin update) —
     * this runs once, tied to the DB_VERSION bump, and only sets rows
     * that are still at their initial inactive state, never overwriting
     * a value an administrator may have already changed.
     */
    /** Modules whose real implementation landed in Stage 5. */
    private const STAGE_5_IMPLEMENTED_SLUGS = [
        'backup-restore', 'webhooks', 'reports',
    ];

    private function activateImplementedModules(): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_modules';
        $allSlugs = array_merge(self::STAGE_3_IMPLEMENTED_SLUGS, self::STAGE_4_IMPLEMENTED_SLUGS, self::STAGE_5_IMPLEMENTED_SLUGS);
        $placeholders = implode(',', array_fill(0, count($allSlugs), '%s'));

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET is_active = 1, updated_at = NOW() WHERE slug IN ({$placeholders}) AND is_active = 0",
                $allSlugs
            )
        );
    }

    /**
     * Idempotent module-registry seed. INSERT ... ON DUPLICATE KEY UPDATE
     * on the `slug` unique key means: first run inserts the row (inactive,
     * per Stage 2 decision #3 — nothing here is activated automatically);
     * subsequent runs only refresh the display name and sort order, never
     * touching is_active, so an administrator's own future activation
     * choice for a module is never silently reverted by a later plugin
     * update.
     */
    private function seedModules(): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_modules';

        foreach (ModuleDefinitions::all() as $module) {
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$table} (slug, name_fa, is_core, is_active, sort_order, created_at, updated_at)
                     VALUES (%s, %s, %d, 0, %d, NOW(), NOW())
                     ON DUPLICATE KEY UPDATE name_fa = VALUES(name_fa), is_core = VALUES(is_core), sort_order = VALUES(sort_order), updated_at = NOW()",
                    $module['slug'],
                    $module['name_fa'],
                    $module['is_core'] ? 1 : 0,
                    $module['sort_order']
                )
            );
        }
    }

    private function seedDefaultData(): void
    {
        global $wpdb;

        // 1. Seed Contacts - Skipped so no sample demo leads are created
        $tableContacts = $wpdb->prefix . 'avina_contacts';

        // 2. Seed Customers
        $tableCustomers = $wpdb->prefix . 'avina_customers';
        $customersCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableCustomers}");
        if ($customersCount === 0) {
            $wpdb->insert($tableCustomers, [
                'contact_id' => 1,
                'full_name' => 'محمد حسینی',
                'phone' => '09123333333',
                'email' => 'mohammad@example.com',
                'status' => 'active',
                'owner_user_id' => 1,
                'is_archived' => 0,
                'created_by_user_id' => 1,
                'custom_fields' => json_encode(['customer_tier' => 'VIP'], JSON_UNESCAPED_UNICODE),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $wpdb->insert($tableCustomers, [
                'contact_id' => 2,
                'full_name' => 'نرگس کریمی',
                'phone' => '09124444444',
                'email' => 'narges@example.com',
                'status' => 'vip',
                'owner_user_id' => 1,
                'is_archived' => 0,
                'created_by_user_id' => 1,
                'custom_fields' => json_encode(['customer_tier' => 'Platinum'], JSON_UNESCAPED_UNICODE),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
        }

        // 3. Seed Receptions
        $tableReceptions = $wpdb->prefix . 'avina_receptions';
        $receptionsCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableReceptions}");
        if ($receptionsCount === 0) {
            $wpdb->insert($tableReceptions, [
                'visitor_name' => 'رضا طاهری',
                'visitor_phone' => '09125555555',
                'host_user_id' => 1,
                'purpose' => 'جلسه قرارداد فروش کارتخوان',
                'status' => 'checked_in',
                'custom_fields' => json_encode(['how_heard' => 'گوگل'], JSON_UNESCAPED_UNICODE),
                'checked_in_at' => current_time('mysql'),
                'created_by_user_id' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $wpdb->insert($tableReceptions, [
                'visitor_name' => 'مریم شفیعی',
                'visitor_phone' => '09126666666',
                'host_user_id' => 1,
                'purpose' => 'پشتیبانی فنی دستگاه کارتخوان',
                'status' => 'in_meeting',
                'custom_fields' => json_encode(['how_heard' => 'معرفی دوستان'], JSON_UNESCAPED_UNICODE),
                'checked_in_at' => current_time('mysql'),
                'created_by_user_id' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
        }

        // 4. Seed Pipelines & Stages
        $tablePipelines = $wpdb->prefix . 'avina_pipelines';
        $tableStages = $wpdb->prefix . 'avina_pipeline_stages';
        $pipelinesCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tablePipelines}");
        if ($pipelinesCount === 0) {
            $wpdb->insert($tablePipelines, [
                'name' => 'پایپ‌لاین فروش پیشرو ارتباطات',
                'is_archived' => 0,
                'created_by_user_id' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $pipelineId = (int) $wpdb->insert_id;

            $wpdb->insert($tableStages, [
                'pipeline_id' => $pipelineId,
                'name' => 'تماس اولیه / شناسایی نیاز',
                'sort_order' => 10,
                'win_probability' => 20,
                'color' => '#6366f1',
                'is_won' => 0,
                'is_lost' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $wpdb->insert($tableStages, [
                'pipeline_id' => $pipelineId,
                'name' => 'مذاکره مالی / پیش‌فاکتور',
                'sort_order' => 20,
                'win_probability' => 60,
                'color' => '#eab308',
                'is_won' => 0,
                'is_lost' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $wpdb->insert($tableStages, [
                'pipeline_id' => $pipelineId,
                'name' => 'قرارداد نهایی / پرداخت شده',
                'sort_order' => 30,
                'win_probability' => 100,
                'color' => '#22c55e',
                'is_won' => 1,
                'is_lost' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
        }

        // 5. Seed Deals
        $tableDeals = $wpdb->prefix . 'avina_deals';
        $dealsCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableDeals}");
        if ($dealsCount === 0) {
            $pipelineId = (int) $wpdb->get_var("SELECT id FROM {$tablePipelines} LIMIT 1");
            $stageId = (int) $wpdb->get_var("SELECT id FROM {$tableStages} WHERE is_won = 0 LIMIT 1");
            if ($pipelineId > 0 && $stageId > 0) {
                $wpdb->insert($tableDeals, [
                    'title' => 'فروش ۱۰ دستگاه کارتخوان Pax S910',
                    'pipeline_id' => $pipelineId,
                    'stage_id' => $stageId,
                    'contact_id' => 1,
                    'value' => 120000000.00,
                    'currency' => 'IRR',
                    'status' => 'open',
                    'owner_user_id' => 1,
                    'is_archived' => 0,
                    'created_by_user_id' => 1,
                    'custom_fields' => json_encode(['deal_notes' => 'نیاز به هماهنگی مجدد'], JSON_UNESCAPED_UNICODE),
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql'),
                ]);
                $wpdb->insert($tableDeals, [
                    'title' => 'فروش ۵ دستگاه کارتخوان Newland SP600',
                    'pipeline_id' => $pipelineId,
                    'stage_id' => $stageId,
                    'contact_id' => 2,
                    'value' => 75000000.00,
                    'currency' => 'IRR',
                    'status' => 'open',
                    'owner_user_id' => 1,
                    'is_archived' => 0,
                    'created_by_user_id' => 1,
                    'custom_fields' => json_encode(['deal_notes' => 'دریافت تاییدیه حسابداری'], JSON_UNESCAPED_UNICODE),
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql'),
                ]);
            }
        }

        // 6. Seed Tasks
        $tableTasks = $wpdb->prefix . 'avina_tasks';
        $tasksCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableTasks}");
        if ($tasksCount === 0) {
            $wpdb->insert($tableTasks, [
                'title' => 'تماس پیگیری با علیرضا رضایی برای فیش واریزی',
                'description' => 'درخواست شد فیش واریز بیعانه ارسال شود تا فاکتور صادر گردد.',
                'priority' => 'high',
                'status' => 'open',
                'assignee_user_id' => 1,
                'is_archived' => 0,
                'created_by_user_id' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $wpdb->insert($tableTasks, [
                'title' => 'ارسال دستگاه کارتخوان مریم شفیعی به کارگاه تعمیرات',
                'description' => 'باطری دستگاه خراب است و نیاز به تعویض سلول دارد.',
                'priority' => 'normal',
                'status' => 'in_progress',
                'assignee_user_id' => 1,
                'is_archived' => 0,
                'created_by_user_id' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
        }

        // 7. Seed Invoices & Items
        $tableInvoices = $wpdb->prefix . 'avina_invoices';
        $tableInvoiceItems = $wpdb->prefix . 'avina_invoice_items';
        $invoicesCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$tableInvoices}");
        if ($invoicesCount === 0) {
            $wpdb->insert($tableInvoices, [
                'type' => 'invoice',
                'number' => 'INV-1405-001',
                'contact_id' => 1,
                'status' => 'unpaid',
                'subtotal' => 120000000.00,
                'discount_total' => 5000000.00,
                'tax_total' => 10350000.00,
                'total' => 125350000.00,
                'paid_total' => 0.00,
                'currency' => 'IRR',
                'issue_date' => date('Y-m-d'),
                'due_date' => date('Y-m-d', strtotime('+7 days')),
                'owner_user_id' => 1,
                'is_archived' => 0,
                'created_by_user_id' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]);
            $invoiceId = (int) $wpdb->insert_id;

            $wpdb->insert($tableInvoiceItems, [
                'invoice_id' => $invoiceId,
                'description' => 'دستگاه کارتخوان Pax S910 سیار',
                'quantity' => 10.000,
                'unit_price' => 12000000.00,
                'discount_percent' => 0.00,
                'tax_percent' => 9.00,
                'line_total' => 120000000.00,
                'sort_order' => 10,
                'created_at' => current_time('mysql'),
            ]);
        }
    }
}
