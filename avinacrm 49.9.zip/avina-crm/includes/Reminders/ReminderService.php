<?php

declare(strict_types=1);

namespace AvinaCRM\Reminders;

use AvinaCRM\Audit\AuditLogger;
use WP_Error;

final class ReminderService
{
    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    /**
     * Reminders are always self-scoped — even a user holding
     * reminders.reminder.view broader capabilities only ever sees their
     * own reminders through this endpoint, since a reminder is
     * inherently personal (matches the legacy application's own
     * NotificationService::listForUser() self-scoping pattern, reused
     * here for the same category of per-user record).
     */
    public function listForCurrentUser(bool $pendingOnly = true): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_reminders';
        $userId = get_current_user_id();

        $where = $wpdb->prepare('owner_user_id = %d', $userId);

        if ($pendingOnly) {
            $where .= ' AND is_done = 0';
        }

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$where} ORDER BY remind_at ASC LIMIT 200",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $title = sanitize_text_field($data['title'] ?? '');

        if ($title === '') {
            return new WP_Error('avina_crm_invalid_reminder', __('عنوان یادآور الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $remindAt = !empty($data['remind_at']) ? $this->normalizeDatetime($data['remind_at']) : null;

        if ($remindAt === null) {
            return new WP_Error('avina_crm_invalid_reminder', __('زمان یادآوری الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_reminders';

        $wpdb->insert(
            $table,
            [
                'title' => $title,
                'related_type' => sanitize_key($data['related_type'] ?? ''),
                'related_id' => !empty($data['related_id']) ? (int) $data['related_id'] : null,
                'remind_at' => $remindAt,
                'is_done' => 0,
                'owner_user_id' => $actorUserId,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%s', '%d', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'reminders.reminder.create', 'reminder', (string) $id, null, ['title' => $title]);

        return ['id' => $id];
    }

    /**
     * @return true|WP_Error
     */
    public function dismiss(int $id, int $actorUserId)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_reminders';

        $existing = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND owner_user_id = %d", $id, $actorUserId),
            ARRAY_A
        );

        if ($existing === null) {
            return new WP_Error('avina_crm_reminder_not_found', __('یادآور موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $wpdb->update($table, ['is_done' => 1, 'updated_at' => current_time('mysql')], ['id' => $id], ['%d', '%s'], ['%d']);

        $this->audit->record($actorUserId, 'reminders.reminder.dismiss', 'reminder', (string) $id, null, ['is_done' => true]);

        return true;
    }

    private function normalizeDatetime(string $value): ?string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d H:i:s', $timestamp) : null;
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['related_id'] = $row['related_id'] !== null ? (int) $row['related_id'] : null;
        $row['is_done'] = (bool) $row['is_done'];

        return $row;
    }
}
