/**
 * Minimal REST client for the avina-crm/v1 namespace. Ported concept
 * from the legacy application's api-client.js: every call goes through
 * one place, the {ok,data}/{ok:false,error} envelope is handled exactly
 * once. The one real change from the legacy version is authentication:
 * X-WP-Nonce (WordPress's own REST nonce) replaces the old custom
 * X-CSRF-Token, and the browser's own WordPress auth cookie travels
 * automatically via `credentials: 'same-origin'`.
 */

export class ApiRequestError extends Error {
  constructor(code, message, status) {
    super(message);
    this.name = 'ApiRequestError';
    this.code = code;
    this.status = status;
  }
}

const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

export async function apiRequest(path, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const base = (window.AvinaCrmConfig && window.AvinaCrmConfig.restUrl) || '';
  const nonce = (window.AvinaCrmConfig && window.AvinaCrmConfig.nonce) || '';

  const headers = { Accept: 'application/json' };
  let body;

  if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json';
    body = JSON.stringify(options.body);
  }

  if (MUTATING_METHODS.has(method) || nonce) {
    headers['X-WP-Nonce'] = nonce;
  }

  let url = base.replace(/\/$/, '') + path;
  
  if (base.includes('rest_route=')) {
    try {
      // In WordPress plain permalinks mode, base url has ?rest_route=
      const urlObj = new URL(base.replace(/\/$/, ''));
      let restRoute = urlObj.searchParams.get('rest_route') || '';
      
      const pathParts = path.split('?');
      const cleanPath = pathParts[0];
      const pathQuery = pathParts[1] || '';
      
      // Append the clean subpath directly to the rest_route parameter value
      restRoute = (restRoute.replace(/\/$/, '') + cleanPath).replace(/\/+/g, '/');
      urlObj.searchParams.set('rest_route', restRoute);
      
      // Merge path query arguments into the URL search parameters
      if (pathQuery) {
        const pathParams = new URLSearchParams(pathQuery);
        for (const [key, val] of pathParams.entries()) {
          urlObj.searchParams.set(key, val);
        }
      }
      
      url = urlObj.toString();
    } catch (e) {
      console.error('URL parsing failed', e);
    }
  }

  // Remove any accidental trailing question mark
  url = url.replace(/\?$/, '');

  let response;

  try {
    response = await fetch(url, {
      method,
      headers,
      body,
      credentials: 'same-origin',
    });
  } catch (networkError) {
    throw new Error('ارتباط با سرور برقرار نشد.');
  }

  let envelope;

  try {
    envelope = await response.json();
  } catch (parseError) {
    throw new Error('پاسخ نامعتبری از سرور دریافت شد.');
  }

  if (envelope && envelope.ok === true) {
    return envelope.data;
  }

  const code = envelope && envelope.error ? envelope.error.code : 'SERVER_ERROR';
  const message =
    envelope && envelope.error && envelope.error.message
      ? envelope.error.message
      : 'خطای ناشناخته‌ای رخ داد.';

  throw new ApiRequestError(code, message, response.status);
}

export function apiGet(path) {
  return apiRequest(path, { method: 'GET' });
}

export function apiPost(path, body) {
  return apiRequest(path, { method: 'POST', body });
}
