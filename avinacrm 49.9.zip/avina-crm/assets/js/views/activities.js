import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const KIND_LABELS = { call: 'تماس', meeting: 'جلسه', note: 'یادداشت' };

export async function renderActivities(container) {
  let pendingOnly = true;

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      if (pendingOnly) query.set('pending_only', '1');
      const items = await apiGet('/activities?' + query.toString());
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <label><input type="checkbox" id="ac-pending" ${pendingOnly ? 'checked' : ''} /> فقط موارد بازِ در انتظار</label>
        <button class="avina-crm-btn" id="ac-new">فعالیت جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('فعالیتی ثبت نشده است.')}
      </div>
    `;

    container.querySelector('#ac-pending').addEventListener('change', (e) => { pendingOnly = e.target.checked; load(); });
    container.querySelector('#ac-new').addEventListener('click', openCreate);

    container.querySelectorAll('[data-complete]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await apiPost(`/activities/${btn.dataset.complete}/complete`, {});
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  }

  function table(items) {
    const rows = items
      .map(
        (a) => `
      <tr>
        <td>${escapeHtml(KIND_LABELS[a.kind] || a.kind)}</td>
        <td>${escapeHtml(a.subject)}</td>
        <td>${formatDateTime(a.next_action_at)}</td>
        <td>${a.is_completed ? '<span class="avina-crm-status avina-crm-status--done">تکمیل‌شده</span>' : `<button class="avina-crm-btn secondary" data-complete="${a.id}">تکمیل</button>`}</td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>نوع</th><th>موضوع</th><th>اقدام بعدی</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function openCreate() {
    openFormModal({
      title: 'فعالیت جدید',
      fields: [
        { name: 'kind', label: 'نوع', type: 'select', options: Object.entries(KIND_LABELS).map(([value, label]) => ({ value, label })) },
        { name: 'subject', label: 'موضوع', required: true },
        { name: 'body', label: 'توضیحات', type: 'textarea' },
        { name: 'next_action_at', label: 'زمان اقدام بعدی (مثلاً 2026-09-01 10:00)' },
      ],
      onSubmit: async (values) => {
        if (!values.next_action_at) delete values.next_action_at;
        await apiPost('/activities', values);
        load();
      },
    });
  }

  load();
}
