import { escapeHtml } from '../ui.js';
import { apiGet, apiPost, apiRequest } from '../api-client.js';

const TABLE_LABELS = {
  contacts: 'مخاطبین', customers: 'مشتریان', receptions: 'پذیرش‌ها', activities: 'فعالیت‌ها',
  tasks: 'وظایف', reminders: 'یادآورها', teams: 'تیم‌ها', tickets: 'درخواست‌ها',
  pipelines: 'پایپ‌لاین‌ها', deals: 'معاملات', invoices: 'فاکتورها', invoice_items: 'اقلام فاکتور', payments: 'پرداخت‌ها',
};

export async function renderBackup(container) {
  const restUrl = window.AvinaCrmConfig.restUrl;

  async function load() {
    container.innerHTML = `<div style="text-align:center;padding:2rem;color:#64748b;">در حال بارگذاری...</div>`;
    try {
      const localBackups = await apiGet('/backup/local');
      draw(localBackups);
    } catch (err) {
      container.innerHTML = `<div class="avina-crm-error" style="color:red;padding:1rem;">خطا در دریافت لیست بکاپ‌ها: ${escapeHtml(err.message)}</div>`;
    }
  }

  function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  function draw(localBackups) {
    const csvLinks = Object.entries(TABLE_LABELS)
      .map(([key, label]) => `<li><a href="${restUrl}/backup/export/csv?table=${key}" target="_blank" rel="noopener" style="color:#0284c7;text-decoration:underline;">${escapeHtml(label)} (CSV)</a></li>`)
      .join('');

    const backupsRows = localBackups.length 
      ? localBackups.map(b => `
          <tr>
            <td style="padding:0.5rem;font-weight:600;color:#1e293b;direction:ltr;text-align:right;"><code>${escapeHtml(b.filename)}</code></td>
            <td style="padding:0.5rem;">${formatBytes(b.size)}</td>
            <td style="padding:0.5rem;direction:ltr;text-align:right;">${escapeHtml(b.created_at)}</td>
            <td style="padding:0.5rem;text-align:left;">
              <a class="avina-crm-btn secondary" href="${restUrl}/backup/local/${b.filename}" target="_blank" rel="noopener" style="padding:0.25rem 0.5rem;font-size:0.85rem;">دانلود</a>
              <button class="avina-crm-btn secondary delete-backup-btn" data-filename="${b.filename}" style="padding:0.25rem 0.5rem;font-size:0.85rem;color:red;border-color:red;">حذف</button>
            </td>
          </tr>
        `).join('')
      : `<tr><td colspan="4" style="text-align:center;color:#64748b;padding:1.5rem;">هیچ نسخه پشتیبانی روی سرور ذخیره نشده است.</td></tr>`;

    container.innerHTML = `
      <div style="display:flex;gap:1.5rem;flex-wrap:wrap;">
        
        <!-- Left Side: Local Backups -->
        <div style="flex:2 1 500px;display:flex;flex-direction:column;gap:1rem;">
          <div class="avina-crm-glass" style="padding:1.25rem;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;flex-wrap:wrap;gap:0.5rem;">
              <h3 style="margin:0;">نسخه‌های پشتیبان سرور (محلی در پوشه افزونه)</h3>
              <button class="avina-crm-btn" id="create-local-backup-btn">ایجاد نسخه پشتیبان جدید در سرور</button>
            </div>
            
            <table class="avina-crm-table" style="width:100%;">
              <thead>
                <tr>
                  <th style="padding:0.5rem;text-align:right;">نام فایل</th>
                  <th style="padding:0.5rem;text-align:right;">حجم</th>
                  <th style="padding:0.5rem;text-align:right;">تاریخ ایجاد</th>
                  <th style="padding:0.5rem;"></th>
                </tr>
              </thead>
              <tbody>
                ${backupsRows}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Right Side: Downloads -->
        <div style="flex:1 1 300px;display:flex;flex-direction:column;gap:1rem;">
          <div class="avina-crm-glass" style="padding:1.25rem;">
            <h3 style="margin-top:0;">خروجی کامل (دانلود مستقیم JSON)</h3>
            <p class="avina-crm-muted" style="margin-bottom:1rem;">شامل تمام جداول کسب‌وکاری، بدون رمزهای عبور یا کلیدهای مخفی.</p>
            <a class="avina-crm-btn" href="${restUrl}/backup/export/json" target="_blank" rel="noopener" style="display:inline-block;text-align:center;width:100%;">دانلود خروجی JSON</a>
          </div>
          
          <div class="avina-crm-glass" style="padding:1.25rem;">
            <h3 style="margin-top:0;">خروجی هر جدول (CSV)</h3>
            <ul style="padding-right:1.25rem;list-style-type:disc;display:flex;flex-direction:column;gap:0.35rem;">
              ${csvLinks}
            </ul>
          </div>
        </div>

      </div>
    `;

    // Event listeners
    const createBtn = container.querySelector('#create-local-backup-btn');
    if (createBtn) {
      createBtn.addEventListener('click', async () => {
        createBtn.disabled = true;
        createBtn.textContent = 'در حال پشتیبان‌گیری...';
        try {
          await apiPost('/backup/local', {});
          load();
        } catch (err) {
          alert('خطا در ایجاد پشتیبان: ' + err.message);
          createBtn.disabled = false;
          createBtn.textContent = 'ایجاد نسخه پشتیبان جدید در سرور';
        }
      });
    }

    container.querySelectorAll('.delete-backup-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const filename = btn.dataset.filename;
        if (!confirm('آیا مطمئن هستید که می‌خواهید این فایل پشتیبان را از روی سرور حذف کنید؟')) {
          return;
        }
        try {
          await apiRequest(`/backup/local/${filename}`, { method: 'DELETE', body: {} });
          load();
        } catch (err) {
          alert('خطا در حذف فایل پشتیبان: ' + err.message);
        }
      });
    });
  }

  load();
}
