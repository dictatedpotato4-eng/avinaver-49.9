import { apiGet, apiPost, apiRequest } from '../api-client.js';
import { escapeHtml, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

export async function renderTeams(container) {
  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const items = await apiGet('/teams');
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <button class="avina-crm-btn" id="tm-new">تیم جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? items.map(card).join('') : emptyHtml('تیمی ایجاد نشده است.')}
      </div>
    `;

    container.querySelector('#tm-new').addEventListener('click', openCreate);

    container.querySelectorAll('[data-add-member]').forEach((btn) => {
      btn.addEventListener('click', () => openAddMember(btn.dataset.addMember));
    });

    container.querySelectorAll('[data-remove-member]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const [teamId, userId] = btn.dataset.removeMember.split(':');
        try {
          await apiRequest(`/teams/${teamId}/members/${userId}`, { method: 'DELETE' });
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  }

  function card(team) {
    const members = team.members
      .map(
        (m) => `<li>${escapeHtml(m.display_name)} (${escapeHtml(m.role_in_team)})
          <button class="avina-crm-btn secondary" data-remove-member="${team.id}:${m.user_id}" style="padding:.1rem .5rem;font-size:.75rem;">حذف</button></li>`
      )
      .join('');

    return `
      <div style="margin-bottom:1.25rem;padding-bottom:1rem;border-bottom:1px solid var(--avina-border);">
        <h3 style="margin:0 0 .3rem;">${escapeHtml(team.name)}</h3>
        <p class="avina-crm-muted">${escapeHtml(team.description || '')}</p>
        <ul>${members || '<li class="avina-crm-muted">عضوی ندارد.</li>'}</ul>
        <button class="avina-crm-btn secondary" data-add-member="${team.id}">افزودن عضو</button>
      </div>
    `;
  }

  function openCreate() {
    openFormModal({
      title: 'تیم جدید',
      fields: [
        { name: 'name', label: 'نام تیم', required: true },
        { name: 'description', label: 'توضیحات', type: 'textarea' },
      ],
      onSubmit: async (values) => {
        await apiPost('/teams', values);
        load();
      },
    });
  }

  function openAddMember(teamId) {
    openFormModal({
      title: 'افزودن عضو به تیم',
      fields: [
        { name: 'user_id', label: 'شناسه کاربری وردپرس', required: true },
        { name: 'role_in_team', label: 'نقش در تیم (اختیاری)' },
      ],
      onSubmit: async (values) => {
        await apiPost(`/teams/${teamId}/members`, { user_id: Number(values.user_id), role_in_team: values.role_in_team });
        load();
      },
    });
  }

  load();
}
