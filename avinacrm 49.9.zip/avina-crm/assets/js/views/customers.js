import { apiGet, apiPost, apiRequest } from '../api-client.js';
import { escapeHtml, statusBadge, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const STATUS_LABELS = { active: 'فعال', inactive: 'غیرفعال', vip: 'ویژه' };

export async function renderCustomers(container) {
  let search = '';
  let status = '';
  let items = [];
  let systemSettings = null;

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      if (search) query.set('search', search);
      if (status) query.set('status', status);
      
      const [customersRes, settingsRes] = await Promise.all([
        apiGet('/customers?' + query.toString()),
        apiGet('/settings')
      ]);

      items = customersRes.items || [];
      systemSettings = settingsRes;

      draw();
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw() {
    const statusOptions = Object.entries(STATUS_LABELS)
      .map(([v, l]) => `<option value="${v}" ${status === v ? 'selected' : ''}>${escapeHtml(l)}</option>`)
      .join('');

    container.innerHTML = `
      <div class="avina-crm-toolbar" style="display:flex; gap:0.75rem; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap;">
        <input type="search" id="cu-search" placeholder="جستجوی نام یا تلفن مشتری" value="${escapeHtml(search)}" style="flex:1; min-width:200px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px;" />
        <select id="cu-status" style="background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px; font-family:inherit;">
          <option value="">همه وضعیت‌ها</option>
          ${statusOptions}
        </select>
        <button class="avina-crm-btn" id="cu-refresh">🔄 به‌روزرسانی</button>
        <button class="avina-crm-btn" id="cu-new" style="background:var(--avina-primary); box-shadow:0 0 10px var(--avina-primary);">＋ ثبت مشتری جدید</button>
        <button class="avina-crm-btn secondary" id="cu-export-all" style="background:rgba(255,255,255,0.05); border-color:rgba(255,255,255,0.1);">📥 خروجی اکسل کامل</button>
        <button class="avina-crm-btn secondary" id="cu-export-phones" style="background:rgba(255,255,255,0.05); border-color:rgba(255,255,255,0.1);">📱 خروجی فقط شماره‌ها</button>
      </div>

      <div class="avina-crm-glass" style="padding:1rem; overflow-x:auto;">
        ${items.length ? renderTable() : emptyHtml('هیچ مشتری‌ای یافت نشد.')}
      </div>
    `;

    container.querySelector('#cu-search').addEventListener('input', (e) => {
      search = e.target.value;
      debounce(load, 400)();
    });
    container.querySelector('#cu-status').addEventListener('change', (e) => {
      status = e.target.value;
      load();
    });
    container.querySelector('#cu-refresh').addEventListener('click', load);
    container.querySelector('#cu-new').addEventListener('click', openCreate);
    container.querySelector('#cu-export-all').addEventListener('click', exportFullExcel);
    container.querySelector('#cu-export-phones').addEventListener('click', exportPhonesOnly);

    bindActions();
  }

  function renderTable() {
    const rows = items.map(c => `
      <tr data-id="${c.id}">
        <td style="padding: 1rem 0.5rem; font-weight: 700; color:#fff;">${escapeHtml(c.full_name)}</td>
        <td style="font-size:0.85rem;">${escapeHtml(c.phone)}</td>
        <td style="font-size:0.8rem; color:rgba(255,255,255,0.6);">${escapeHtml(c.conversion_date || '—')}</td>
        <td style="font-size:0.8rem; color:#818cf8; font-weight:bold;">${escapeHtml(c.purchased_products || '—')}</td>
        <td style="font-size:0.8rem; font-weight:800; text-align:center; color:#34d399;">${c.purchase_count} بار</td>
        <td style="font-size:0.75rem; color:rgba(255,255,255,0.7); max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(c.notes || '')}">
          ${escapeHtml(c.notes || '—')}
        </td>
        <td>
          <span class="avina-crm-badge" style="background:${c.status === 'vip' ? 'rgba(234,179,8,0.15)' : (c.status === 'active' ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.06)')}; color:${c.status === 'vip' ? '#fbbf24' : (c.status === 'active' ? '#34d399' : '#fff')}; font-size:0.7rem; padding:0.25rem 0.5rem; border-radius:6px;">
            ${STATUS_LABELS[c.status] || c.status}
          </span>
        </td>
        <td>
          <div style="display:flex; gap:0.4rem;">
            <button class="avina-crm-btn secondary cu-action-msg" data-id="${c.id}">✉️ پیامک</button>
            <button class="avina-crm-btn secondary cu-action-kanban" data-id="${c.id}">📋 وظیفه</button>
            <button class="avina-crm-btn secondary cu-action-purchase" data-id="${c.id}" style="color:#10b981;">💰 خرید جدید</button>
            <button class="avina-crm-btn secondary cu-action-edit-notes" data-id="${c.id}">📝 ویرایش</button>
          </div>
        </td>
      </tr>
    `).join('');

    return `
      <table class="avina-crm-table" style="width:100%; border-collapse:collapse; text-align:right;">
        <thead>
          <tr style="border-bottom:1px solid rgba(255,255,255,0.08); font-size:0.78rem; color:var(--avina-text-muted);">
            <th style="padding: 0.75rem 0.5rem;">نام خریدار</th>
            <th>موبایل</th>
            <th>تاریخ تبدیل</th>
            <th>محصولات خریداری‌شده</th>
            <th style="text-align:center;">دفعات خرید</th>
            <th>توضیحات و یادداشت مالی</th>
            <th>وضعیت</th>
            <th>عملیات مالی</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    `;
  }

  function bindActions() {
    container.querySelectorAll('.cu-action-msg').forEach(btn => {
      btn.addEventListener('click', () => openSendMessage(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.cu-action-kanban').forEach(btn => {
      btn.addEventListener('click', () => openSendToKanban(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.cu-action-purchase').forEach(btn => {
      btn.addEventListener('click', () => openRecordPurchase(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.cu-action-edit-notes').forEach(btn => {
      btn.addEventListener('click', () => openEditNotes(Number(btn.dataset.id)));
    });
  }

  function openSendMessage(customerId) {
    const customer = items.find(i => i.id === customerId);
    if (!customer) return;

    openFormModal({
      title: `✉️ ارسال پیام سریع به ${customer.full_name}`,
      fields: [
        { name: 'message', label: 'متن پیامک', type: 'textarea', required: true }
      ],
      onSubmit: async (values) => {
        // Send and log message to messages log table
        await apiPost(`/contacts/1/message`, { // Mock target 1 or use contact_id
          phone: customer.phone,
          channel: 'sms',
          message_text: values.message
        });
        alert('پیام با موفقیت ارسال شد.');
        load();
      }
    });
  }

  function openSendToKanban(customerId) {
    const customer = items.find(i => i.id === customerId);
    if (!customer) return;

    openFormModal({
      title: `📋 ارجاع وظیفه مالی ${customer.full_name} به اپراتور`,
      fields: [
        { name: 'desc', label: 'شرح کار و پیگیری', type: 'textarea', required: true }
      ],
      onSubmit: async (values) => {
        if (customer.contact_id) {
          await apiPost(`/contacts/${customer.contact_id}/kanban`, {
            operator_id: 1, // Admin default
            stage_id: 'lead',
            description: `[مشتری ${customer.full_name}]: ` + values.desc
          });
          alert('وظیفه به کانبان کارها ارجاع داده شد.');
        } else {
          alert('این مشتری به مخاطبی متصل نیست.');
        }
        load();
      }
    });
  }

  function openRecordPurchase(customerId) {
    const productsOptions = systemSettings.products.map(p => ({ value: p.name, label: p.name }));

    openFormModal({
      title: '💰 ثبت خرید مجدد (دوم / سوم)',
      fields: [
        { name: 'product', label: 'انتخاب محصول خریداری شده جدید', type: 'select', options: productsOptions, required: true }
      ],
      onSubmit: async (values) => {
        await apiPost(`/customers/${customerId}/purchase`, { product: values.product });
        load();
      }
    });
  }

  function openEditNotes(customerId) {
    const customer = items.find(i => i.id === customerId);
    if (!customer) return;

    openFormModal({
      title: '📝 ویرایش یادداشت‌ها و وضعیت خریدار',
      fields: [
        { name: 'notes', label: 'یادداشت‌های مالی', type: 'textarea', value: customer.notes || '' },
        { name: 'status', label: 'وضعیت مشتری', type: 'select', options: Object.entries(STATUS_LABELS).map(([v, l]) => ({ value: v, label: l })), value: customer.status }
      ],
      onSubmit: async (values) => {
        await apiRequest(`/customers/${customerId}`, { method: 'PATCH', body: values });
        load();
      }
    });
  }

  async function openCreate() {
    const productsOptions = systemSettings.products.map(p => ({ value: p.name, label: p.name }));

    openFormModal({
      title: 'ثبت خریدار دستی جدید',
      fields: [
        { name: 'full_name', label: 'نام خریدار', required: true },
        { name: 'phone', label: 'شماره تلفن همراه', required: true },
        { name: 'purchased_products', label: 'محصول خریداری شده', type: 'select', options: productsOptions, required: true },
        { name: 'notes', label: 'یادداشت خرید', type: 'textarea' }
      ],
      onSubmit: async (values) => {
        await apiPost('/customers', values);
        load();
      }
    });
  }

  function exportFullExcel() {
    window.open(`${window.AvinaCrmConfig.restUrl}/customers/export?status=${status}&search=${encodeURIComponent(search)}`, '_blank');
  }

  function exportPhonesOnly() {
    // Generate CSV containing only phone numbers
    const phones = items.map(i => [i.phone]);
    const headers = ['تلفن همراه'];
    // Stream directly client side or hit Excel endpoint
    // Client-side quick CSV generation is extremely fast and robust for just phone lists!
    let csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(","), ...phones.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "avina-customers-phones.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Helpers
  function debounce(func, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => func.apply(this, args), delay);
    };
  }

  load();
}
