import { apiGet } from '../api-client.js';
import { escapeHtml, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';

export async function renderAuditLog(container) {
  let filters = { object_type: '', action: '', since: '', until: '' };

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      Object.entries(filters).forEach(([k, v]) => { if (v) query.set(k, v); });
      const result = await apiGet('/audit-log?' + query.toString());
      draw(result.items, result.total);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items, total) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <input type="text" id="al-object-type" placeholder="نوع موجودیت (مثلاً deal)" value="${escapeHtml(filters.object_type)}" />
        <input type="text" id="al-action" placeholder="جستجوی عملیات" value="${escapeHtml(filters.action)}" />
        <input type="date" id="al-since" value="${escapeHtml(filters.since)}" />
        <input type="date" id="al-until" value="${escapeHtml(filters.until)}" />
      </div>
      <p class="avina-crm-muted">${total} رکورد یافت شد.</p>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('رویدادی یافت نشد.')}
      </div>
    `;

    ['object-type', 'action', 'since', 'until'].forEach((key) => {
      container.querySelector(`#al-${key}`).addEventListener('change', (e) => {
        filters[key.replace('-', '_')] = e.target.value;
        load();
      });
    });
  }

  function table(items) {
    const rows = items
      .map(
        (a) => `
      <tr>
        <td>${formatDateTime(a.created_at)}</td>
        <td>${escapeHtml(a.actor_display_name || 'سیستم')}</td>
        <td>${escapeHtml(a.action)}</td>
        <td>${escapeHtml(a.object_type || '—')} ${a.object_id ? '#' + escapeHtml(a.object_id) : ''}</td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>زمان</th><th>کاربر</th><th>عملیات</th><th>موجودیت</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  load();
}
