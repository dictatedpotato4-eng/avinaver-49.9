import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, statusBadge, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';

const STATUS_LABELS = {
  draft: 'پیش‌نویس', sent: 'ارسال‌شده', accepted: 'پذیرفته‌شده',
  partially_paid: 'نیمه‌پرداخت‌شده', paid: 'پرداخت‌شده', void: 'باطل‌شده',
};

export async function renderInvoices(container) {
  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const items = await apiGet('/invoices');
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <button class="avina-crm-btn" id="iv-new">فاکتور جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('فاکتوری ثبت نشده است.')}
      </div>
      <div id="iv-detail"></div>
    `;

    container.querySelector('#iv-new').addEventListener('click', openBuilder);
    container.querySelectorAll('[data-open-invoice]').forEach((el) => {
      el.addEventListener('click', () => openDetail(el.dataset.openInvoice));
    });
  }

  function table(items) {
    const rows = items
      .map(
        (i) => `
      <tr>
        <td><a href="#" data-open-invoice="${i.id}">${escapeHtml(i.number)}</a></td>
        <td>${i.type === 'quote' ? 'پیش‌فاکتور' : 'فاکتور'}</td>
        <td>${statusBadge(i.status, STATUS_LABELS)}</td>
        <td>${Number(i.total).toLocaleString('fa-IR')} ${escapeHtml(i.currency)}</td>
        <td>${Number(i.paid_total).toLocaleString('fa-IR')}</td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>شماره</th><th>نوع</th><th>وضعیت</th><th>مبلغ کل</th><th>پرداخت‌شده</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  async function openDetail(id) {
    const detail = container.querySelector('#iv-detail');
    detail.innerHTML = loadingHtml();

    try {
      const invoice = await apiGet(`/invoices/${id}`);
      drawDetail(detail, invoice);
    } catch (err) {
      detail.innerHTML = errorHtml(err.message);
    }
  }

  function drawDetail(detail, invoice) {
    const itemsRows = invoice.items
      .map(
        (it) => `<tr>
          <td>${escapeHtml(it.description)}</td>
          <td>${Number(it.quantity).toLocaleString('fa-IR')}</td>
          <td>${Number(it.unit_price).toLocaleString('fa-IR')}</td>
          <td>${Number(it.discount_percent)}%</td>
          <td>${Number(it.tax_percent)}%</td>
          <td>${Number(it.line_total).toLocaleString('fa-IR')}</td>
        </tr>`
      )
      .join('');

    const paymentsRows = invoice.payments
      .map((p) => `<li>${Number(p.amount).toLocaleString('fa-IR')} — ${formatDateTime(p.paid_at)} (${escapeHtml(p.method)})</li>`)
      .join('');

    detail.innerHTML = `
      <div class="avina-crm-glass" style="padding:1.25rem;margin-top:1rem;">
        <h3>${escapeHtml(invoice.number)}</h3>
        <table class="avina-crm-table">
          <thead><tr><th>شرح</th><th>تعداد</th><th>قیمت واحد</th><th>تخفیف</th><th>مالیات</th><th>جمع ردیف</th></tr></thead>
          <tbody>${itemsRows}</tbody>
        </table>
        <p>جمع جزء: ${Number(invoice.subtotal).toLocaleString('fa-IR')} | تخفیف: ${Number(invoice.discount_total).toLocaleString('fa-IR')} | مالیات: ${Number(invoice.tax_total).toLocaleString('fa-IR')}</p>
        <p><strong>مبلغ کل: ${Number(invoice.total).toLocaleString('fa-IR')} ${escapeHtml(invoice.currency)}</strong></p>
        <p>پرداخت‌شده: ${Number(invoice.paid_total).toLocaleString('fa-IR')} — باقیمانده: ${Number(invoice.balance_due).toLocaleString('fa-IR')}</p>
        <h4>پرداخت‌ها</h4>
        <ul>${paymentsRows || '<li class="avina-crm-muted">پرداختی ثبت نشده است.</li>'}</ul>
        ${invoice.balance_due > 0 && invoice.status !== 'void' ? `
        <form id="iv-payment-form" class="avina-crm-form-row">
          <label>ثبت پرداخت جدید</label>
          <input type="number" id="iv-payment-amount" step="0.01" max="${invoice.balance_due}" placeholder="مبلغ" required />
          <input type="text" id="iv-payment-reference" placeholder="شماره پیگیری / مرجع (اختیاری)" />
          <button type="submit" class="avina-crm-btn" style="width:fit-content;">ثبت پرداخت</button>
        </form>` : ''}
      </div>
    `;

    const form = detail.querySelector('#iv-payment-form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const amount = Number(detail.querySelector('#iv-payment-amount').value);
        const reference = detail.querySelector('#iv-payment-reference').value;
        try {
          await apiPost(`/invoices/${invoice.id}/payments`, { amount, reference });
          openDetail(invoice.id);
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    }
  }

  function openBuilder() {
    const backdrop = document.createElement('div');
    backdrop.className = 'avina-crm-modal-backdrop';
    backdrop.innerHTML = `
      <div class="avina-crm-modal avina-crm-glass" role="dialog" aria-modal="true">
        <h2>فاکتور جدید</h2>
        <div class="avina-crm-form-row">
          <label>نوع سند</label>
          <select id="ivb-type"><option value="invoice">فاکتور</option><option value="quote">پیش‌فاکتور</option></select>
        </div>
        <div id="ivb-items"></div>
        <button type="button" class="avina-crm-btn secondary" id="ivb-add-item">افزودن ردیف</button>
        <p id="ivb-preview" class="avina-crm-muted"></p>
        <p id="ivb-error" class="avina-crm-error" hidden></p>
        <div style="display:flex;gap:.5rem;margin-top:1rem;">
          <button type="button" class="avina-crm-btn" id="ivb-save">ذخیره فاکتور</button>
          <button type="button" class="avina-crm-btn secondary" id="ivb-cancel">انصراف</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);

    const itemsBox = backdrop.querySelector('#ivb-items');

    function addItemRow() {
      const row = document.createElement('div');
      row.className = 'avina-crm-form-row';
      row.style.cssText = 'flex-direction:row;flex-wrap:wrap;';
      row.innerHTML = `
        <input type="text" placeholder="شرح" class="ivb-desc" style="flex:2;" required />
        <input type="number" placeholder="تعداد" class="ivb-qty" value="1" step="0.001" style="flex:1;" />
        <input type="number" placeholder="قیمت واحد" class="ivb-price" value="0" step="0.01" style="flex:1;" />
        <input type="number" placeholder="تخفیف %" class="ivb-discount" value="0" step="0.01" style="flex:1;" />
        <input type="number" placeholder="مالیات %" class="ivb-tax" value="0" step="0.01" style="flex:1;" />
      `;
      itemsBox.appendChild(row);
      row.querySelectorAll('input').forEach((inp) => inp.addEventListener('input', updatePreview));
    }

    function updatePreview() {
      let total = 0;
      itemsBox.querySelectorAll('.avina-crm-form-row').forEach((row) => {
        const qty = Number(row.querySelector('.ivb-qty').value) || 0;
        const price = Number(row.querySelector('.ivb-price').value) || 0;
        const discount = Number(row.querySelector('.ivb-discount').value) || 0;
        const tax = Number(row.querySelector('.ivb-tax').value) || 0;
        const sub = qty * price;
        const afterDiscount = sub - sub * (discount / 100);
        total += afterDiscount + afterDiscount * (tax / 100);
      });
      backdrop.querySelector('#ivb-preview').textContent =
        'پیش‌نمایش مبلغ کل (تقریبی — محاسبه نهایی در سرور انجام می‌شود): ' + total.toLocaleString('fa-IR');
    }

    addItemRow();
    backdrop.querySelector('#ivb-add-item').addEventListener('click', addItemRow);
    backdrop.querySelector('#ivb-cancel').addEventListener('click', () => backdrop.remove());
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) backdrop.remove(); });

    backdrop.querySelector('#ivb-save').addEventListener('click', async () => {
      const items = Array.from(itemsBox.querySelectorAll('.avina-crm-form-row')).map((row) => ({
        description: row.querySelector('.ivb-desc').value,
        quantity: row.querySelector('.ivb-qty').value,
        unit_price: row.querySelector('.ivb-price').value,
        discount_percent: row.querySelector('.ivb-discount').value,
        tax_percent: row.querySelector('.ivb-tax').value,
      }));

      const errorBox = backdrop.querySelector('#ivb-error');

      try {
        await apiPost('/invoices', { type: backdrop.querySelector('#ivb-type').value, items });
        backdrop.remove();
        load();
      } catch (err) {
        errorBox.hidden = false;
        errorBox.textContent = err.message;
      }
    });
  }

  load();
}
