import { apiGet } from '../api-client.js';
import { escapeHtml, loadingHtml, emptyHtml, errorHtml } from '../ui.js';

export async function renderPhonebook(container) {
  let search = '';

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      if (search) query.set('search', search);
      const items = await apiGet('/phonebook?' + query.toString());
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <input type="search" id="pb-search" placeholder="جستجوی نام یا تلفن" value="${escapeHtml(search)}" />
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('موردی یافت نشد.')}
      </div>
    `;

    container.querySelector('#pb-search').addEventListener('change', (e) => { search = e.target.value; load(); });
  }

  function table(items) {
    const rows = items
      .map(
        (p) => `
      <tr>
        <td>${escapeHtml(p.full_name)}</td>
        <td>${p.source_type === 'customer' ? 'مشتری' : 'مخاطب'}</td>
        <td>${escapeHtml(p.phone)}${p.phone_masked ? ' <span class="avina-crm-muted">(محدود)</span>' : ''}</td>
        <td>${escapeHtml(p.email || '—')}</td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>نام</th><th>نوع</th><th>تلفن</th><th>ایمیل</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  load();
}
