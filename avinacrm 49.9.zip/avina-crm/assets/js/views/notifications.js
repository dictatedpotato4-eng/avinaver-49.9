import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';

export async function renderNotifications(container) {
  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const result = await apiGet('/notifications');
      draw(result.items, result.unread_count);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items, unreadCount) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <span class="avina-crm-muted">${unreadCount} اعلان خوانده‌نشده</span>
        <button class="avina-crm-btn secondary" id="nt-read-all">علامت‌گذاری همه به‌عنوان خوانده‌شده</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? list(items) : emptyHtml('اعلانی وجود ندارد.')}
      </div>
    `;

    container.querySelector('#nt-read-all').addEventListener('click', async () => {
      try {
        await apiPost('/notifications/read-all', {});
        load();
      } catch (err) {
        alert(err.message);
      }
    });

    container.querySelectorAll('[data-read]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await apiPost(`/notifications/${btn.dataset.read}/read`, {});
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  }

  function list(items) {
    return items
      .map(
        (n) => `
      <div class="avina-crm-form-row" style="border-bottom:1px solid var(--avina-border);padding-bottom:.75rem;">
        <strong>${escapeHtml(n.title)}${n.is_read ? '' : ' <span class="avina-crm-status avina-crm-status--open">جدید</span>'}</strong>
        <span class="avina-crm-muted">${escapeHtml(n.body || '')}</span>
        <span class="avina-crm-muted">${formatDateTime(n.created_at)}</span>
        ${n.is_read ? '' : `<button class="avina-crm-btn secondary" data-read="${n.id}" style="width:fit-content;">علامت‌گذاری به‌عنوان خوانده‌شده</button>`}
      </div>`
      )
      .join('');
  }

  load();
}
