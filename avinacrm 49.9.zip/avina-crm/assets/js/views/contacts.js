import { apiGet, apiPost, apiRequest } from '../api-client.js';
import { escapeHtml, statusBadge, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const STAGE_LABELS = {
  lead: 'سرنخ',
  in_progress: 'در حال پیگیری',
  customer: 'مشتری',
  cancelled: 'لغو شده',
};

export async function renderContacts(container) {
  let search = '';
  let lifecycleStage = '';
  let followupRange = '';
  let items = [];
  let operators = [];
  let systemSettings = null;

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      if (search) query.set('search', search);
      if (lifecycleStage) query.set('lifecycle_stage', lifecycleStage);
      if (followupRange) query.set('followup_range', followupRange);

      const [contactsRes, settingsRes, usersRes] = await Promise.all([
        apiGet('/contacts?' + query.toString()),
        apiGet('/settings'),
        apiGet('/users') // assuming /users is the endpoint to load operator list
      ]);

      items = contactsRes.items || [];
      systemSettings = settingsRes;
      operators = usersRes || [
        { id: 1, display_name: 'مدیر کل' },
        { id: 2, display_name: 'اپراتور فروش' },
        { id: 3, display_name: 'اپراتور تعمیرات' }
      ];

      draw();
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw() {
    const stageOptions = Object.entries(STAGE_LABELS)
      .map(([v, l]) => `<option value="${v}" ${lifecycleStage === v ? 'selected' : ''}>${escapeHtml(l)}</option>`)
      .join('');

    const rangeOptions = [
      { v: '', l: 'همه زمان‌ها' },
      { v: 'today', l: 'پیگیری‌های امروز' },
      { v: 'tomorrow', l: 'پیگیری‌های فردا' },
      { v: 'week', l: 'پیگیری‌های هفته جاری' },
      { v: 'month', l: 'پیگیری‌های ماه جاری' }
    ].map(opt => `<option value="${opt.v}" ${followupRange === opt.v ? 'selected' : ''}>${opt.l}</option>`).join('');

    container.innerHTML = `
      <div class="avina-crm-toolbar" style="display:flex; gap:0.75rem; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap;">
        <input type="search" id="c-search" placeholder="جستجوی نام یا تلفن" value="${escapeHtml(search)}" style="flex:1; min-width:200px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px;" />
        <select id="c-stage" style="background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px; font-family:inherit;">
          <option value="">همه مراحل</option>
          ${stageOptions}
        </select>
        <select id="c-followup-range" style="background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px; font-family:inherit;">
          ${rangeOptions}
        </select>
        <button class="avina-crm-btn" id="c-refresh">🔄 به‌روزرسانی</button>
        <button class="avina-crm-btn" id="c-new" style="background:var(--avina-primary); box-shadow:0 0 10px var(--avina-primary);">＋ ثبت مخاطب جدید</button>
        <button class="avina-crm-btn secondary" id="c-export" style="background:rgba(255,255,255,0.05); border-color:rgba(255,255,255,0.1);">📥 خروجی اکسل (CSV)</button>
      </div>

      <div class="avina-crm-glass" style="padding:1rem; overflow-x:auto;">
        ${items.length ? renderTable() : emptyHtml('هیچ مخاطبی یافت نشد.')}
      </div>

      <!-- General modals wrapper -->
      <div id="contacts-modal-container"></div>
    `;

    // Bind event listeners
    container.querySelector('#c-search').addEventListener('input', (e) => {
      search = e.target.value;
      debounce(load, 400)();
    });
    container.querySelector('#c-stage').addEventListener('change', (e) => {
      lifecycleStage = e.target.value;
      load();
    });
    container.querySelector('#c-followup-range').addEventListener('change', (e) => {
      followupRange = e.target.value;
      load();
    });
    container.querySelector('#c-refresh').addEventListener('click', load);
    container.querySelector('#c-new').addEventListener('click', openSteppedNewModal);
    container.querySelector('#c-export').addEventListener('click', openExportOptionsModal);

    // Click handlers for table actions
    bindTableActions();
  }

  function renderTable() {
    const rows = items.map(c => `
      <tr data-id="${c.id}">
        <td style="white-space:nowrap; padding: 1rem 0.5rem;">
          <div style="font-weight:700; color:#fff; font-size:0.85rem;">${escapeHtml(c.full_name)}</div>
          <div style="font-size:0.72rem; color:rgba(255,255,255,0.4); margin-top:0.2rem;">${escapeHtml(c.job || 'شغل نامشخص')}</div>
        </td>
        <td style="font-size:0.82rem;">
          <div>${escapeHtml(c.phone)}</div>
        </td>
        <td style="font-size:0.8rem;">
          <span class="avina-crm-badge" style="background:${c.requirement_type === 'purchase' ? 'rgba(99,102,241,0.1)' : 'rgba(234,179,8,0.1)'}; color:${c.requirement_type === 'purchase' ? '#818cf8' : '#fbbf24'}; padding:0.2rem 0.5rem; border-radius:6px; font-size:0.7rem;">
            ${c.requirement_type === 'purchase' ? 'خرید' : 'خدمات'}
          </span>
        </td>
        <td style="font-size:0.8rem; color:rgba(255,255,255,0.85);">${escapeHtml(c.product_or_service || '—')}</td>
        <td>
          <div class="avina-star-rating" data-id="${c.id}" style="display:flex; gap:0.15rem; cursor:pointer;">
            ${Array.from({ length: 5 }, (_, i) => `
              <span data-value="${i + 1}" style="color:${i < c.buying_probability ? '#eab308' : 'rgba(255,255,255,0.15)'}; font-size:1.1rem; text-shadow:${i < c.buying_probability ? '0 0 5px #eab308' : 'none'};">★</span>
            `).join('')}
          </div>
        </td>
        <td>
          <span class="clickable-followup-date" data-id="${c.id}" style="color:#38bdf8; border-bottom:1px dashed #38bdf8; cursor:pointer; font-size:0.8rem; font-weight:bold;">
            ${escapeHtml(c.followup_date || 'تعیین تاریخ')}
          </span>
        </td>
        <td style="text-align:center; font-weight:bold; font-size:0.8rem; color:#fff;">${c.call_count}</td>
        <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:0.75rem; color:rgba(255,255,255,0.7);" title="${escapeHtml(c.last_call_result || '')}">
          ${escapeHtml(c.last_call_result || '—')}
        </td>
        <td>
          <span class="avina-crm-badge" style="background:${c.lifecycle_stage === 'customer' ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.06)'}; color:${c.lifecycle_stage === 'customer' ? '#34d399' : '#fff'}; font-size:0.7rem; padding:0.25rem 0.5rem; border-radius:6px;">
            ${STAGE_LABELS[c.lifecycle_stage] || c.lifecycle_stage}
          </span>
        </td>
        <td>
          <div style="display:flex; gap:0.4rem;">
            <button class="avina-crm-btn secondary row-action-msg" data-id="${c.id}" style="padding:0.3rem 0.6rem; font-size:0.75rem;">✉️ پیام</button>
            <button class="avina-crm-btn secondary row-action-kanban" data-id="${c.id}" style="padding:0.3rem 0.6rem; font-size:0.75rem;">📋 کار</button>
            <button class="avina-crm-btn secondary row-action-convert" data-id="${c.id}" style="padding:0.3rem 0.6rem; font-size:0.75rem; color:#34d399;">🏆 تبدیل</button>
            <button class="avina-crm-btn secondary row-action-details" data-id="${c.id}" style="padding:0.3rem 0.6rem; font-size:0.75rem;">👁️ تاریخچه</button>
          </div>
        </td>
      </tr>
    `).join('');

    return `
      <table class="avina-crm-table" style="width:100%; border-collapse:collapse; text-align:right;">
        <thead>
          <tr style="border-bottom:1px solid rgba(255,255,255,0.08); font-size:0.78rem; color:var(--avina-text-muted);">
            <th style="padding: 0.75rem 0.5rem;">نام و شغل</th>
            <th>موبایل</th>
            <th>مورد نیاز</th>
            <th>محصول/خدمت</th>
            <th>احتمال خرید</th>
            <th>تاریخ پیگیری</th>
            <th style="text-align:center;">تماس</th>
            <th>آخرین صحبت</th>
            <th>وضعیت</th>
            <th>عملیات</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    `;
  }

  function bindTableActions() {
    // Star rating handler
    container.querySelectorAll('.avina-star-rating span').forEach(star => {
      star.addEventListener('click', async (e) => {
        e.stopPropagation();
        const contactId = Number(star.parentElement.dataset.id);
        const rating = Number(star.dataset.value);
        try {
          await apiRequest(`/contacts/${contactId}`, { method: 'PATCH', body: { buying_probability: rating } });
          load();
        } catch (err) {
          alert('خطا در تغییر رتبه: ' + err.message);
        }
      });
    });

    // Followup date inline editor click
    container.querySelectorAll('.clickable-followup-date').forEach(el => {
      el.addEventListener('click', () => {
        const contactId = Number(el.dataset.id);
        openFollowupDatePopup(contactId);
      });
    });

    // Actions click handlers
    container.querySelectorAll('.row-action-msg').forEach(btn => {
      btn.addEventListener('click', () => openSendMessageModal(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.row-action-kanban').forEach(btn => {
      btn.addEventListener('click', () => openSendToKanbanModal(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.row-action-convert').forEach(btn => {
      btn.addEventListener('click', () => openConvertToCustomerModal(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.row-action-details').forEach(btn => {
      btn.addEventListener('click', () => openContactDetailsDrawer(Number(btn.dataset.id)));
    });
  }

  // Stepped New Contact modal (4 Steps)
  function openSteppedNewModal() {
    let currentStep = 1;
    const products = systemSettings.products || [];
    const services = systemSettings.services || [];

    const modal = document.createElement('div');
    modal.className = 'avina-modal-overlay';
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.65); display:flex; justify-content:center; align-items:center; z-index:99999; backdrop-filter:blur(8px); direction:rtl;';
    
    // Better: keep track of form state in an object
    const formState = {
      full_name: '',
      phone: '',
      email: '',
      job: '',
      requirement_type: 'purchase',
      product_or_service: '',
      buying_probability: 3,
      last_call_result: '',
      followup_date: '',
      send_to_kanban: false,
      kanban_operator_id: 1,
      kanban_stage: 'lead',
      kanban_description: ''
    };

    function saveState() {
      if (currentStep === 1) {
        formState.full_name = modal.querySelector('#step-full-name')?.value.trim() || '';
        formState.phone = modal.querySelector('#step-phone')?.value.trim() || '';
        formState.email = modal.querySelector('#step-email')?.value.trim() || '';
        formState.job = modal.querySelector('#step-job')?.value.trim() || '';
        formState.requirement_type = modal.querySelector('#step-req-type')?.value || 'purchase';
      } else if (currentStep === 2) {
        formState.product_or_service = modal.querySelector('#step-product-service')?.value || '';
        formState.buying_probability = Number(modal.querySelector('#step-prob')?.value || 3);
      } else if (currentStep === 3) {
        formState.last_call_result = modal.querySelector('#step-notes')?.value.trim() || '';
        formState.followup_date = modal.querySelector('#step-followup-date')?.value || '';
      } else if (currentStep === 4) {
        formState.send_to_kanban = modal.querySelector('#step-kanban-toggle')?.checked || false;
        formState.kanban_operator_id = Number(modal.querySelector('#step-kanban-operator')?.value || 1);
        formState.kanban_stage = modal.querySelector('#step-kanban-stage')?.value || 'lead';
        formState.kanban_description = modal.querySelector('#step-kanban-desc')?.value.trim() || '';
      }
    }

    function loadState() {
      if (currentStep === 1) {
        const fnInput = modal.querySelector('#step-full-name');
        if (fnInput) fnInput.value = formState.full_name;
        const phInput = modal.querySelector('#step-phone');
        if (phInput) phInput.value = formState.phone;
        const emInput = modal.querySelector('#step-email');
        if (emInput) emInput.value = formState.email;
        const jbInput = modal.querySelector('#step-job');
        if (jbInput) jbInput.value = formState.job;
        const rtSelect = modal.querySelector('#step-req-type');
        if (rtSelect) rtSelect.value = formState.requirement_type;
      } else if (currentStep === 2) {
        const psSelect = modal.querySelector('#step-product-service');
        if (psSelect) psSelect.value = formState.product_or_service;
        const pbSelect = modal.querySelector('#step-prob');
        if (pbSelect) pbSelect.value = formState.buying_probability;
      } else if (currentStep === 3) {
        const ntText = modal.querySelector('#step-notes');
        if (ntText) ntText.value = formState.last_call_result;
        const fdInput = modal.querySelector('#step-followup-date');
        if (fdInput) fdInput.value = formState.followup_date;
      } else if (currentStep === 4) {
        const kbToggle = modal.querySelector('#step-kanban-toggle');
        if (kbToggle) {
          kbToggle.checked = formState.send_to_kanban;
          modal.querySelector('#step-kanban-fields').style.display = kbToggle.checked ? 'flex' : 'none';
        }
        const kbOp = modal.querySelector('#step-kanban-operator');
        if (kbOp) kbOp.value = formState.kanban_operator_id;
        const kbSt = modal.querySelector('#step-kanban-stage');
        if (kbSt) kbSt.value = formState.kanban_stage;
        const kbDc = modal.querySelector('#step-kanban-desc');
        if (kbDc) kbDc.value = formState.kanban_description;
      }
    }

    // Redefine drawing logic with state saving
    function drawStepWithState() {
      let stepContent = '';
      if (currentStep === 1) {
        stepContent = `
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            <label style="color:#fff; font-size:0.8rem;">نام و نام‌خانوادگی مخاطب (الزامی)</label>
            <input type="text" id="step-full-name" placeholder="مثال: علی رضایی" style="padding:0.55rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px;" />
            
            <label style="color:#fff; font-size:0.8rem;">تلفن همراه اول (الزامی)</label>
            <input type="tel" id="step-phone" placeholder="مثال: 09121234567" style="padding:0.55rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px;" />
            
            <label style="color:#fff; font-size:0.8rem;">تلفن همراه دوم (اختیاری)</label>
            <input type="tel" id="step-email" placeholder="موبایل دوم یا ایمیل" style="padding:0.55rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px;" />
            
            <label style="color:#fff; font-size:0.8rem;">شغل</label>
            <input type="text" id="step-job" placeholder="مثال: فروشنده، پزشک" style="padding:0.55rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px;" />
            
            <label style="color:#fff; font-size:0.8rem;">نوع نیاز</label>
            <select id="step-req-type" style="padding:0.55rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px; font-family:inherit;">
              <option value="purchase">خرید محصول</option>
              <option value="service">دریافت خدمات</option>
            </select>
          </div>
        `;
      } else if (currentStep === 2) {
        const selectOptions = formState.requirement_type === 'purchase'
          ? products.map(p => `<option value="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('')
          : services.map(s => `<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`).join('');

        stepContent = `
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            <label style="color:#fff; font-size:0.8rem;">انتخاب محصول یا خدمت موردنیاز</label>
            <select id="step-product-service" style="padding:0.55rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px; font-family:inherit; width:100%;">
              <option value="">-- انتخاب کنید --</option>
              ${selectOptions}
            </select>
            
            <label style="color:#fff; font-size:0.8rem; margin-top:0.5rem;">احتمال خرید (امتیاز ستاره)</label>
            <select id="step-prob" style="padding:0.55rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px; font-family:inherit;">
              <option value="1">۱ ستاره (بسیار پایین)</option>
              <option value="2">۲ ستاره (پایین)</option>
              <option value="3">۳ ستاره (متوسط)</option>
              <option value="4">۴ ستاره (بالا)</option>
              <option value="5">۵ ستاره (بسیار بالا)</option>
            </select>
          </div>
        `;
      } else if (currentStep === 3) {
        stepContent = `
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            <label style="color:#fff; font-size:0.8rem;">خلاصه صحبت اولیه / یادداشت صحبت (الزامی)</label>
            <textarea id="step-notes" rows="4" placeholder="مشتری درخواست فلان محصول را داشت..." style="padding:0.55rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px; font-family:inherit;" required></textarea>
            
            <label style="color:#fff; font-size:0.8rem;">تاریخ پیگیری بعدی (الزامی - فرمت YYYY-MM-DD)</label>
            <input type="date" id="step-followup-date" style="padding:0.55rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:10px;" required />
          </div>
        `;
      } else if (currentStep === 4) {
        const operatorsOptions = operators.map(o => `<option value="${o.id}">${escapeHtml(o.display_name)}</option>`).join('');
        const stagesOptions = systemSettings.kanban_settings.stages.map(st => `<option value="${st.id}">${escapeHtml(st.name)}</option>`).join('');

        stepContent = `
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            <label style="display:flex; align-items:center; gap:0.5rem; color:#fff; font-size:0.85rem; cursor:pointer; background:rgba(255,255,255,0.02); padding:0.5rem; border-radius:8px;">
              <input type="checkbox" id="step-kanban-toggle" style="width:18px; height:18px;">
              ارسال مستقیم به بورد کانبان کارها
            </label>
            
            <div id="step-kanban-fields" style="display:none; flex-direction:column; gap:0.6rem; background:rgba(255,255,255,0.01); padding:0.75rem; border-radius:10px; border:1px solid rgba(255,255,255,0.05);">
              <label style="color:#fff; font-size:0.75rem;">ارجاع به اپراتور مسئول</label>
              <select id="step-kanban-operator" style="padding:0.45rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
                ${operatorsOptions}
              </select>
              <label style="color:#fff; font-size:0.75rem;">مرحله اولیه بورد</label>
              <select id="step-kanban-stage" style="padding:0.45rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
                ${stagesOptions}
              </select>
              <label style="color:#fff; font-size:0.75rem;">شرح وظیفه واگذار شده</label>
              <textarea id="step-kanban-desc" rows="2" placeholder="توضیحات کار برای اپراتور..." style="padding:0.45rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;"></textarea>
            </div>
          </div>
        `;
      }

      modal.innerHTML = `
        <div class="avina-crm-glass" style="width:420px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem; box-shadow: 0 15px 35px rgba(0,0,0,0.4);">
          <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:0.5rem;">
            <h3 style="margin:0; font-size:1rem; font-weight:800; color:#fff;">ثبت مخاطب جدید (مرحله ${currentStep} از ۴)</h3>
            <span style="font-size:0.75rem; color:#6366f1; font-weight:bold;">${currentStep * 25}%</span>
          </div>

          <div style="min-height:230px;" id="step-body-container">
            ${stepContent}
          </div>

          <div style="display:flex; gap:0.5rem; margin-top:0.5rem;">
            ${currentStep > 1 ? `<button class="avina-crm-btn" id="modal-prev-btn" style="flex:1; background:rgba(255,255,255,0.08); border-color:rgba(255,255,255,0.12);">مرحله قبل</button>` : ''}
            <button class="avina-crm-btn" id="modal-next-btn" style="flex:2; background:var(--avina-primary);">${currentStep === 4 ? 'ثبت و نهایی‌سازی مخاطب' : 'مرحله بعد'}</button>
            <button class="avina-crm-btn" id="modal-cancel-btn" style="flex:1; background:rgba(255,68,68,0.12); border-color:rgba(255,68,68,0.2); color:#fca5a5;">انصراف</button>
          </div>
        </div>
      `;

      // Load previously entered values into inputs
      loadState();

      // Setup actions
      modal.querySelector('#modal-cancel-btn').addEventListener('click', () => modal.remove());

      if (currentStep > 1) {
        modal.querySelector('#modal-prev-btn').addEventListener('click', () => {
          saveState();
          currentStep--;
          drawStepWithState();
        });
      }

      if (currentStep === 4) {
        const kbToggle = modal.querySelector('#step-kanban-toggle');
        const kbFields = modal.querySelector('#step-kanban-fields');
        kbToggle.addEventListener('change', () => {
          kbFields.style.display = kbToggle.checked ? 'flex' : 'none';
        });
      }

      modal.querySelector('#modal-next-btn').addEventListener('click', async () => {
        saveState();
        if (currentStep === 1) {
          if (!formState.full_name || !formState.phone) {
            alert('پر کردن نام کامل و تلفن همراه اول الزامی است.');
            return;
          }
          currentStep = 2;
          drawStepWithState();
        } else if (currentStep === 2) {
          currentStep = 3;
          drawStepWithState();
        } else if (currentStep === 3) {
          if (!formState.last_call_result || !formState.followup_date) {
            alert('پر کردن صحبت اولیه و تعیین تاریخ پیگیری الزامی است.');
            return;
          }
          currentStep = 4;
          drawStepWithState();
        } else if (currentStep === 4) {
          // Final Submit
          modal.innerHTML = loadingHtml();
          try {
            const res = await apiPost('/contacts', {
              full_name: formState.full_name,
              phone: formState.phone,
              email: formState.email,
              job: formState.job,
              requirement_type: formState.requirement_type,
              product_or_service: formState.product_or_service,
              buying_probability: formState.buying_probability,
              last_call_result: formState.last_call_result,
              followup_date: formState.followup_date
            });

            if (formState.send_to_kanban && res.id) {
              await apiPost(`/contacts/${res.id}/kanban`, {
                operator_id: formState.kanban_operator_id,
                stage_id: formState.kanban_stage,
                description: formState.kanban_description || formState.last_call_result
              });
            }

            modal.remove();
            load();
          } catch (err) {
            alert('خطا در ثبت مخاطب: ' + err.message);
            modal.remove();
            load();
          }
        }
      });
    }

    document.body.appendChild(modal);
    drawStepWithState();
  }

  // Followup date calendar popup
  function openFollowupDatePopup(contactId) {
    const modal = document.createElement('div');
    modal.className = 'avina-modal-overlay';
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.6); display:flex; justify-content:center; align-items:center; z-index:99999; backdrop-filter:blur(8px); direction:rtl;';
    
    modal.innerHTML = `
      <div class="avina-crm-glass" style="width:360px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem;">
        <h3 style="margin:0; font-size:0.95rem; font-weight:800; color:#fff; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:0.5rem;">📅 ویرایش تاریخ پیگیری و ثبت صحبت</h3>
        
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          <label style="color:#fff; font-size:0.8rem;">تاریخ پیگیری بعدی (فرمت YYYY-MM-DD)</label>
          <input type="date" id="pop-date" value="${current_date_input()}" style="padding:0.5rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px;" required />
          
          <label style="color:#fff; font-size:0.8rem;">یادداشت صحبت‌های امروز (صحبت جدید)</label>
          <textarea id="pop-notes" rows="3" placeholder="جزئیات تماس یا صحبت‌های انجام شده با مخاطب..." style="padding:0.5rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;" required></textarea>
        </div>

        <div style="display:flex; gap:0.5rem; margin-top:0.5rem;">
          <button class="avina-crm-btn" id="pop-save-btn" style="flex:2; background:var(--avina-primary);">ثبت و ذخیره تغییرات</button>
          <button class="avina-crm-btn" id="pop-cancel-btn" style="flex:1; background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.15);">انصراف</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#pop-cancel-btn').addEventListener('click', () => modal.remove());
    modal.querySelector('#pop-save-btn').addEventListener('click', async () => {
      const date = modal.querySelector('#pop-date').value;
      const notes = modal.querySelector('#pop-notes').value.trim();

      if (!date || !notes) {
        alert('پر کردن تاریخ و یادداشت صحبت الزامی است.');
        return;
      }

      modal.innerHTML = loadingHtml();
      try {
        await apiPost(`/contacts/${contactId}/followups`, {
          followup_date: date,
          notes: notes,
          result: 'پیگیری ثبت شده'
        });
        modal.remove();
        load();
      } catch (err) {
        alert('خطا در ثبت تغییرات: ' + err.message);
        modal.remove();
        load();
      }
    });
  }

  // Send Message popup (templates)
  function openSendMessageModal(contactId) {
    const contact = items.find(i => i.id === contactId);
    if (!contact) return;

    const modal = document.createElement('div');
    modal.className = 'avina-modal-overlay';
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.6); display:flex; justify-content:center; align-items:center; z-index:99999; backdrop-filter:blur(8px); direction:rtl;';

    const t = systemSettings.message_templates;
    const templateButtons = [
      { id: 'template_1', label: 'آدرس دفتر' },
      { id: 'template_2', label: 'پیگیری حضور' },
      { id: 'template_3', label: 'تبریک خرید' },
      { id: 'template_4', label: 'منتظر حضور' },
      { id: 'template_5', label: 'دیگر محصولات' }
    ].map(btn => `
      <button class="avina-crm-btn secondary msg-tpl-btn" data-text="${escapeHtml(t[btn.id] || '')}" style="padding:0.35rem; font-size:0.7rem; flex:1; min-width:80px; text-align:center;">
        ${escapeHtml(btn.label)}
      </button>
    `).join('');

    modal.innerHTML = `
      <div class="avina-crm-glass" style="width:400px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem;">
        <h3 style="margin:0; font-size:0.95rem; font-weight:800; color:#fff; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:0.5rem;">✉️ ارسال پیام به ${escapeHtml(contact.full_name)}</h3>
        
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          <label style="color:#fff; font-size:0.8rem;">شماره گیرنده</label>
          <input type="text" id="msg-phone" value="${escapeHtml(contact.phone)}" style="padding:0.5rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px;" />
          
          <label style="color:#fff; font-size:0.8rem;">کانال ارتباطی</label>
          <select id="msg-channel" style="padding:0.5rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
            <option value="sms">پیامک (SMS)</option>
            <option value="eitaa">پیام‌رسان ایتا</option>
            <option value="whatsapp">واتساپ</option>
          </select>

          <label style="color:#fff; font-size:0.8rem;">انتخاب سریع قالب پیام</label>
          <div style="display:flex; flex-wrap:wrap; gap:0.4rem;" id="quick-templates-wrapper">
            ${templateButtons}
          </div>

          <label style="color:#fff; font-size:0.8rem;">متن پیام ارسالی</label>
          <textarea id="msg-text" rows="4" placeholder="متن پیام خود را بنویسید..." style="padding:0.5rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;" required></textarea>
        </div>

        <div style="display:flex; gap:0.5rem; margin-top:0.5rem;">
          <button class="avina-crm-btn" id="msg-send-btn" style="flex:2; background:var(--avina-primary);">ارسال پیام</button>
          <button class="avina-crm-btn" id="msg-cancel-btn" style="flex:1; background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.15);">انصراف</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelectorAll('.msg-tpl-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        let text = btn.dataset.text;
        // Simple replace tags if exists
        text = text.replace('[date]', current_date_input());
        modal.querySelector('#msg-text').value = text;
      });
    });

    modal.querySelector('#msg-cancel-btn').addEventListener('click', () => modal.remove());
    modal.querySelector('#msg-send-btn').addEventListener('click', async () => {
      const phone = modal.querySelector('#msg-phone').value;
      const channel = modal.querySelector('#msg-channel').value;
      const text = modal.querySelector('#msg-text').value.trim();

      if (!text) {
        alert('متن پیام الزامی است.');
        return;
      }

      modal.innerHTML = loadingHtml();
      try {
        await apiPost(`/contacts/${contactId}/message`, {
          phone: phone,
          channel: channel,
          message_text: text
        });
        modal.remove();
        load();
      } catch (err) {
        alert('خطا در ارسال پیام: ' + err.message);
        modal.remove();
        load();
      }
    });
  }

  // Send to Kanban operator modal
  function openSendToKanbanModal(contactId) {
    const contact = items.find(i => i.id === contactId);
    if (!contact) return;

    const modal = document.createElement('div');
    modal.className = 'avina-modal-overlay';
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.6); display:flex; justify-content:center; align-items:center; z-index:99999; backdrop-filter:blur(8px); direction:rtl;';

    const operatorsOptions = operators.map(o => `<option value="${o.id}">${escapeHtml(o.display_name)}</option>`).join('');
    const stagesOptions = systemSettings.kanban_settings.stages.map(st => `<option value="${st.id}">${escapeHtml(st.name)}</option>`).join('');

    modal.innerHTML = `
      <div class="avina-crm-glass" style="width:380px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem;">
        <h3 style="margin:0; font-size:0.95rem; font-weight:800; color:#fff; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:0.5rem;">📋 ارجاع وظیفه به کانبان پرسنل</h3>
        
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          <label style="color:#fff; font-size:0.8rem;">ارجاع به اپراتور</label>
          <select id="kb-operator" style="padding:0.5rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
            ${operatorsOptions}
          </select>
          
          <label style="color:#fff; font-size:0.8rem;">مرحله اولیه وظیفه</label>
          <select id="kb-stage" style="padding:0.5rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
            ${stagesOptions}
          </select>

          <label style="color:#fff; font-size:0.8rem;">شرح وظیفه واگذار شده</label>
          <textarea id="kb-desc" rows="3" placeholder="شرح وظیفه برای اپراتور..." style="padding:0.5rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;" required>${escapeHtml(contact.last_call_result || '')}</textarea>
        </div>

        <div style="display:flex; gap:0.5rem; margin-top:0.5rem;">
          <button class="avina-crm-btn" id="kb-save-btn" style="flex:2; background:var(--avina-primary);">ارجاع و ثبت در کانبان</button>
          <button class="avina-crm-btn" id="kb-cancel-btn" style="flex:1; background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.15);">انصراف</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#kb-cancel-btn').addEventListener('click', () => modal.remove());
    modal.querySelector('#kb-save-btn').addEventListener('click', async () => {
      const opId = Number(modal.querySelector('#kb-operator').value);
      const stId = modal.querySelector('#kb-stage').value;
      const desc = modal.querySelector('#kb-desc').value.trim();

      if (!desc) {
        alert('شرح کار الزامی است.');
        return;
      }

      modal.innerHTML = loadingHtml();
      try {
        await apiPost(`/contacts/${contactId}/kanban`, {
          operator_id: opId,
          stage_id: stId,
          description: desc
        });
        modal.remove();
        load();
      } catch (err) {
        alert('خطا در ارجاع به کانبان: ' + err.message);
        modal.remove();
        load();
      }
    });
  }

  // Convert to Customer modal
  function openConvertToCustomerModal(contactId) {
    const contact = items.find(i => i.id === contactId);
    if (!contact) return;

    const modal = document.createElement('div');
    modal.className = 'avina-modal-overlay';
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.6); display:flex; justify-content:center; align-items:center; z-index:99999; backdrop-filter:blur(8px); direction:rtl;';

    const productsOptions = systemSettings.products.map(p => `<option value="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('');

    modal.innerHTML = `
      <div class="avina-crm-glass" style="width:380px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem;">
        <h3 style="margin:0; font-size:0.95rem; font-weight:800; color:#fff; border-bottom:1px solid rgba(16,185,129,0.2); padding-bottom:0.5rem; color:#10b981;">🏆 تبدیل به مشتری و ثبت خرید</h3>
        
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          <label style="color:#fff; font-size:0.8rem;">نام کامل</label>
          <div style="color:rgba(255,255,255,0.7); font-size:0.85rem; font-weight:bold;">${escapeHtml(contact.full_name)}</div>

          <label style="color:#fff; font-size:0.8rem;">انتخاب محصول خریداری شده</label>
          <select id="conv-product" style="padding:0.5rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
            <option value="">-- انتخاب کنید --</option>
            ${productsOptions}
          </select>
          
          <label style="color:#fff; font-size:0.8rem;">توضیحات و یادداشت خرید</label>
          <textarea id="conv-notes" rows="3" placeholder="یادداشت‌های مالی یا شرایط خرید..." style="padding:0.5rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;"></textarea>
        </div>

        <div style="display:flex; gap:0.5rem; margin-top:0.5rem;">
          <button class="avina-crm-btn" id="conv-save-btn" style="flex:2; background:#10b981; border-color:#059669; box-shadow:0 0 10px rgba(16,185,129,0.35);">ثبت و انتقال به مشتریان</button>
          <button class="avina-crm-btn" id="conv-cancel-btn" style="flex:1; background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.15);">انصراف</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#conv-cancel-btn').addEventListener('click', () => modal.remove());
    modal.querySelector('#conv-save-btn').addEventListener('click', async () => {
      const product = modal.querySelector('#conv-product').value;
      const notes = modal.querySelector('#conv-notes').value.trim();

      if (!product) {
        alert('انتخاب محصول خریداری شده الزامی است.');
        return;
      }

      modal.innerHTML = loadingHtml();
      try {
        await apiPost(`/contacts/${contactId}/convert`, {
          purchased_products: product,
          notes: notes
        });
        modal.remove();
        load();
      } catch (err) {
        alert('خطا در تبدیل مخاطب: ' + err.message);
        modal.remove();
        load();
      }
    });
  }

  // Contact details drawer
  async function openContactDetailsDrawer(contactId) {
    const contact = items.find(i => i.id === contactId);
    if (!contact) return;

    const drawer = document.createElement('div');
    drawer.style.cssText = 'position:fixed; top:0; left:0; bottom:0; width:450px; background:rgba(20,20,30,0.85); border-right:1px solid rgba(255,255,255,0.12); box-shadow: 10px 0 35px rgba(0,0,0,0.65); backdrop-filter:blur(25px); z-index:99999; display:flex; flex-direction:column; padding:1.5rem; transition:transform 0.3s ease; transform:translateX(-100%); direction:rtl;';
    
    drawer.innerHTML = loadingHtml();
    document.body.appendChild(drawer);

    // Slide in animation
    setTimeout(() => {
      drawer.style.transform = 'translateX(0)';
    }, 50);

    try {
      const history = await apiGet(`/contacts/${contactId}/followups`);
      
      const historyRows = history.map(h => `
        <div style="border-right:2px solid #6366f1; padding-right:0.75rem; position:relative; margin-bottom:1rem; padding-bottom:0.5rem;">
          <span style="position:absolute; right:-6px; top:3px; width:10px; height:10px; border-radius:50%; background:#6366f1; box-shadow:0 0 6px #6366f1;"></span>
          <div style="display:flex; justify-content:space-between; font-size:0.73rem; color:rgba(255,255,255,0.45); margin-bottom:0.25rem;">
            <span>تاریخ اقدام: ${escapeHtml(h.followup_date)}</span>
            <span>نتیجه: ${escapeHtml(h.result || 'پیگیری')}</span>
          </div>
          <div style="font-size:0.78rem; color:#fff; line-height:1.5;">${escapeHtml(h.notes)}</div>
        </div>
      `).join('');

      drawer.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:0.75rem; margin-bottom:1rem;">
          <h3 style="margin:0; font-size:1.1rem; color:#fff; font-weight:800;">📋 پرونده و تاریخچه پیگیری‌ها</h3>
          <button class="avina-crm-btn" id="close-drawer" style="padding:0.25rem 0.5rem; font-size:0.75rem; background:rgba(255,68,68,0.15); border-color:rgba(255,68,68,0.3); color:#fca5a5;">بستن پرونده</button>
        </div>

        <div style="display:flex; flex-direction:column; gap:0.5rem; background:rgba(255,255,255,0.02); padding:0.75rem; border-radius:10px; margin-bottom:1rem; border:1px solid rgba(255,255,255,0.04);">
          <div style="font-size:0.9rem; font-weight:bold; color:#fff;">${escapeHtml(contact.full_name)}</div>
          <div style="font-size:0.78rem; color:var(--avina-text-muted);">موبایل: ${escapeHtml(contact.phone)}</div>
          <div style="font-size:0.78rem; color:var(--avina-text-muted);">شغل: ${escapeHtml(contact.job || '—')}</div>
          <div style="font-size:0.78rem; color:var(--avina-text-muted);">محصول/خدمت انتخابی: ${escapeHtml(contact.product_or_service || '—')}</div>
        </div>

        <h4 style="margin:0 0 0.75rem 0; font-size:0.85rem; color:#fff; font-weight:bold;">📜 تاریخچه صحبت‌های ضبط‌شده:</h4>
        
        <div style="flex:1; overflow-y:auto; padding-left:0.5rem; margin-bottom:1rem;">
          ${historyRows || '<div style="color:rgba(255,255,255,0.35); text-align:center; font-size:0.8rem; margin-top:2rem;">هیچ تماسی در تاریخچه ثبت نشده است.</div>'}
        </div>
      `;

      drawer.querySelector('#close-drawer').addEventListener('click', () => {
        drawer.style.transform = 'translateX(-100%)';
        setTimeout(() => drawer.remove(), 300);
      });
    } catch (err) {
      drawer.innerHTML = errorHtml(err.message);
    }
  }

  // Export options modal
  function openExportOptionsModal() {
    const modal = document.createElement('div');
    modal.className = 'avina-modal-overlay';
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.6); display:flex; justify-content:center; align-items:center; z-index:99999; backdrop-filter:blur(8px); direction:rtl;';

    modal.innerHTML = `
      <div class="avina-crm-glass" style="width:360px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem;">
        <h3 style="margin:0; font-size:0.95rem; font-weight:800; color:#fff; text-align:center;">📥 خروجی گرفتن از اطلاعات مخاطبین</h3>
        
        <div style="display:flex; flex-direction:column; gap:0.5rem;">
          <label style="color:#fff; font-size:0.8rem; margin-bottom:0.25rem;">تعداد رکوردهای خروجی</label>
          <select id="exp-count" style="padding:0.5rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-family:inherit;">
            <option value="50">۵۰ رکورد اول</option>
            <option value="100">۱۰۰ رکورد اول</option>
            <option value="1000">۱,۰۰۰ رکورد اول</option>
            <option value="10000">۱۰,۰۰۰ رکورد (خروجی کامل)</option>
          </select>
        </div>

        <div style="display:flex; gap:0.5rem; margin-top:0.5rem;">
          <button class="avina-crm-btn" id="exp-download-btn" style="flex:2; background:var(--avina-primary);">دانلود فایل اکسل</button>
          <button class="avina-crm-btn" id="exp-cancel-btn" style="flex:1; background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.15);">انصراف</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#exp-cancel-btn').addEventListener('click', () => modal.remove());
    modal.querySelector('#exp-download-btn').addEventListener('click', () => {
      const limit = modal.querySelector('#exp-count').value;
      const downloadUrl = `${window.AvinaCrmConfig.restUrl}/contacts/export?per_page=${limit}&lifecycle_stage=${lifecycleStage}&search=${encodeURIComponent(search)}&followup_range=${followupRange}`;
      window.open(downloadUrl, '_blank');
      modal.remove();
    });
  }

  // Helpers
  function debounce(func, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => func.apply(this, args), delay);
    };
  }

  function current_date_input() {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  }

  load();
}
