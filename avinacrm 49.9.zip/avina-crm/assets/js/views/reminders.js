import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

export async function renderReminders(container) {
  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const items = await apiGet('/reminders?pending_only=1');
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <button class="avina-crm-btn" id="rm-new">یادآور جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('یادآوری در انتظار وجود ندارد.')}
      </div>
    `;

    container.querySelector('#rm-new').addEventListener('click', openCreate);

    container.querySelectorAll('[data-dismiss]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await apiPost(`/reminders/${btn.dataset.dismiss}/dismiss`, {});
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  }

  function table(items) {
    const rows = items
      .map(
        (r) => `
      <tr>
        <td>${escapeHtml(r.title)}</td>
        <td>${formatDateTime(r.remind_at)}</td>
        <td><button class="avina-crm-btn secondary" data-dismiss="${r.id}">تکمیل / حذف</button></td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>عنوان</th><th>زمان یادآوری</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function openCreate() {
    openFormModal({
      title: 'یادآور جدید',
      fields: [
        { name: 'title', label: 'عنوان', required: true },
        { name: 'remind_at', label: 'زمان یادآوری (مثلاً 2026-09-01 10:00)', required: true },
      ],
      onSubmit: async (values) => {
        await apiPost('/reminders', values);
        load();
      },
    });
  }

  load();
}
