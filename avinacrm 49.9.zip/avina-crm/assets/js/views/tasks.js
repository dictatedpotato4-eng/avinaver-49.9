import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, statusBadge, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const STATUS_LABELS = { open: 'باز', in_progress: 'در حال انجام', done: 'انجام‌شده', cancelled: 'لغوشده' };
const PRIORITY_LABELS = { low: 'کم', normal: 'عادی', high: 'بالا', urgent: 'فوری' };

export async function renderTasks(container) {
  let status = '';

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      if (status) query.set('status', status);
      const items = await apiGet('/tasks?' + query.toString());
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    const statusOptions = Object.entries(STATUS_LABELS)
      .map(([v, l]) => `<option value="${v}" ${status === v ? 'selected' : ''}>${escapeHtml(l)}</option>`)
      .join('');

    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <select id="tk-status"><option value="">همه وضعیت‌ها</option>${statusOptions}</select>
        <button class="avina-crm-btn" id="tk-new">وظیفه جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('وظیفه‌ای ثبت نشده است.')}
      </div>
    `;

    container.querySelector('#tk-status').addEventListener('change', (e) => { status = e.target.value; load(); });
    container.querySelector('#tk-new').addEventListener('click', openCreate);

    container.querySelectorAll('[data-next-status]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await apiPost(`/tasks/${btn.dataset.id}/status`, { status: btn.dataset.nextStatus });
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });
  }

  function actionsFor(t) {
    if (t.status === 'open') {
      return `<button class="avina-crm-btn secondary" data-id="${t.id}" data-next-status="in_progress">شروع</button>`;
    }
    if (t.status === 'in_progress') {
      return `<button class="avina-crm-btn secondary" data-id="${t.id}" data-next-status="done">اتمام</button>`;
    }
    return '';
  }

  function table(items) {
    const rows = items
      .map(
        (t) => `
      <tr>
        <td>${escapeHtml(t.title)}</td>
        <td>${statusBadge(t.priority, PRIORITY_LABELS)}</td>
        <td>${statusBadge(t.status, STATUS_LABELS)}</td>
        <td>${formatDateTime(t.due_at)}</td>
        <td>${actionsFor(t)}</td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>عنوان</th><th>اولویت</th><th>وضعیت</th><th>سررسید</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function openCreate() {
    openFormModal({
      title: 'وظیفه جدید',
      fields: [
        { name: 'title', label: 'عنوان', required: true },
        { name: 'description', label: 'توضیحات', type: 'textarea' },
        { name: 'priority', label: 'اولویت', type: 'select', options: Object.entries(PRIORITY_LABELS).map(([value, label]) => ({ value, label })) },
        { name: 'due_at', label: 'سررسید (مثلاً 2026-09-01 10:00)' },
        { name: 'assignee_user_id', label: 'شناسه کاربری مسئول (اختیاری — واگذاری به دیگران نیاز به مجوز دارد)' },
      ],
      onSubmit: async (values) => {
        if (!values.due_at) delete values.due_at;
        if (values.assignee_user_id) values.assignee_user_id = Number(values.assignee_user_id);
        else delete values.assignee_user_id;
        await apiPost('/tasks', values);
        load();
      },
    });
  }

  load();
}
