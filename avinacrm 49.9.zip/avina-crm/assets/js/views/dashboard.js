import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, loadingHtml, errorHtml, apply3dTiltEffect } from '../ui.js';

function loadChartJs() {
  return new Promise((resolve) => {
    if (window.Chart) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
    script.onload = () => resolve();
    document.head.appendChild(script);
  });
}

export async function renderDashboard(container) {
  let range = '30d';
  let layout = null;
  let dashboardData = null;
  let kanbanTasks = [];
  let systemSettings = null;

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      await loadChartJs();
      // Fetch Layout, Settings, Widgets statistics and Kanban tasks in parallel
      const [layoutRes, settingsRes, dataRes, tasksRes] = await Promise.all([
        apiGet('/settings/layout'),
        apiGet('/settings'),
        apiGet(`/analytics/dashboard?range=${range}`),
        apiGet('/settings/kanban/tasks')
      ]);

      layout = layoutRes;
      systemSettings = settingsRes;
      dashboardData = dataRes;
      kanbanTasks = tasksRes;

      draw();
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw() {
    // Generate dashboard header and toolbars
    const selectOptions = [
      { v: '7d', l: '۷ روز اخیر' },
      { v: '30d', l: '۳۰ روز اخیر' },
      { v: '90d', l: '۹۰ روز اخیر' }
    ].map(opt => `<option value="${opt.v}" ${range === opt.v ? 'selected' : ''}>${opt.l}</option>`).join('');

    const widgetDefs = {
      contacts_today: { label: 'مخاطبین امروز', value: dashboardData.widgets_data.contacts_today, sub: 'کل مخاطبین ثبت‌شده امروز', color: '#6366f1', icon: '👤' },
      buying_prob_today: { label: 'احتمال خرید بالا', value: dashboardData.widgets_data.buying_prob_today, sub: 'مخاطبین با احتمال خرید بالا', color: '#eab308', icon: '⭐' },
      followups_today: { label: 'پیگیری‌های امروز', value: dashboardData.widgets_data.followups_today, sub: 'پیگیری‌های زمان‌بندی شده امروز', color: '#10b981', icon: '📞' },
      interactions_today: { label: 'تعاملات امروز', value: dashboardData.widgets_data.interactions_today, sub: 'پیام‌های ارسال شده موفق امروز', color: '#ec4899', icon: '💬' }
    };

    // Sort widgets based on saved layout preference
    const sortedWidgets = [...layout.widgets];
    sortedWidgets.sort((a, b) => (a.order || 0) - (b.order || 0));

    const widgetsHtml = sortedWidgets.map(widgetPref => {
      const widget = widgetDefs[widgetPref.id];
      if (!widget || !widgetPref.visible) return '';
      return `
        <div class="avina-kpi-card-premium avina-draggable-widget" draggable="true" data-widget-id="${widgetPref.id}">
          <div class="avina-kpi-glow" style="background: ${widget.color};"></div>
          <div style="display:flex;align-items:center;justify-content:space-between;width:100%;">
            <div class="avina-kpi-icon-wrapper" style="box-shadow: 0 0 15px ${widget.color}40; border-color: ${widget.color}20; color: ${widget.color};">
              ${widget.icon}
            </div>
            <span class="avina-kpi-label" style="font-size: 0.82rem;">${escapeHtml(widget.label)}</span>
          </div>
          <div class="avina-kpi-content" style="margin-top: 1rem;">
            <div class="avina-kpi-value" style="font-size: 1.8rem; font-weight: 800; font-family: inherit;">${escapeHtml(String(widget.value))}</div>
            <div class="avina-kpi-sub" style="font-size: 0.7rem; opacity: 0.6; margin-top: 0.2rem;">${escapeHtml(widget.sub)}</div>
          </div>
        </div>
      `;
    }).join('');

    // Draw main framework wrapper
    container.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:1.5rem; width:100%;">
        <!-- Toolbar -->
        <div class="avina-crm-toolbar" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
          <h2 style="margin:0; font-size:1.3rem; font-weight:800; color:#fff; display:flex; align-items:center; gap:0.5rem;">
            <span style="font-size:1.5rem;">⚡</span> پیشخوان اختصاصی آوینا
          </h2>
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <select id="db-range" style="font-size:0.8rem; padding:0.4rem 1rem; border-radius:10px;">
              ${selectOptions}
            </select>
            <button class="avina-crm-btn" id="customize-widgets-btn" style="padding:0.4rem 0.8rem; font-size:0.75rem; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12);">
              ⚙️ مدیریت ویجت‌ها
            </button>
          </div>
        </div>

        <!-- 4 Widgets Grid -->
        <div class="avina-kpi-grid" id="dashboard-widgets-container" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:1rem; position:relative;">
          ${widgetsHtml || '<div class="avina-crm-glass" style="padding:1.5rem; text-align:center; grid-column: 1 / -1;">تمام ویجت‌های آماری خاموش هستند.</div>'}
        </div>

        <!-- Charts Section -->
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:1.25rem;">
          <!-- Chart 1: Lifecycle -->
          <div class="avina-crm-glass" style="padding:1.5rem; height:320px; display:flex; flex-direction:column; position:relative;">
            <h3 style="margin:0 0 1rem 0; font-size:0.9rem; font-weight:bold; color:#fff; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:0.5rem;">توزیع مراحل چرخه عمر مخاطبین</h3>
            <div style="flex:1; position:relative; width:100%; height:100%;">
              <canvas id="lifecycle-chart"></canvas>
            </div>
          </div>
          <!-- Chart 2: POS Intakes -->
          <div class="avina-crm-glass" style="padding:1.5rem; height:320px; display:flex; flex-direction:column; position:relative;">
            <h3 style="margin:0 0 1rem 0; font-size:0.9rem; font-weight:bold; color:#fff; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:0.5rem;">پذیرش دستگاه‌های کارتخوان</h3>
            <div style="flex:1; position:relative; width:100%; height:100%;">
              <canvas id="intakes-chart"></canvas>
            </div>
          </div>
        </div>

        <!-- Kanban Tasks Board Section -->
        ${dashboardData.kanban_enabled ? `
        <div class="avina-crm-glass" style="padding:1.5rem; display:flex; flex-direction:column; gap:1rem;">
          <h3 style="margin:0; font-size:0.95rem; font-weight:800; color:#fff; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:0.5rem; display:flex; align-items:center; gap:0.4rem;">
            📋 بورد تعاملی وظایف اپراتور
          </h3>
          <div class="avina-kanban-board" style="display:grid; grid-template-columns: repeat(5, minmax(200px, 1fr)); gap:0.75rem; overflow-x:auto; padding-bottom:0.5rem;">
            ${drawKanbanBoardColumns()}
          </div>
        </div>
        ` : ''}
      </div>

      <!-- Widgets customizer modal (Glassmorphic dialog) -->
      <div class="avina-modal-overlay" id="widget-customizer-modal" style="display:none; justify-content:center; align-items:center; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:99999; backdrop-filter:blur(8px);">
        <div class="avina-crm-glass" style="width:360px; padding:1.5rem; display:flex; flex-direction:column; gap:1.25rem;">
          <h3 style="margin:0; font-size:1rem; font-weight:bold; color:#fff; text-align:center;">تنظیمات نمایش ویجت‌ها</h3>
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            ${sortedWidgets.map(w => {
              const info = widgetDefs[w.id];
              return `
                <label style="display:flex; justify-content:space-between; align-items:center; color:#fff; font-size:0.85rem; cursor:pointer; background:rgba(255,255,255,0.02); padding:0.5rem; border-radius:8px;">
                  <span>${escapeHtml(info.label)}</span>
                  <input type="checkbox" class="widget-toggle-checkbox" data-widget-id="${w.id}" ${w.visible ? 'checked' : ''} style="cursor:pointer; width:18px; height:18px;">
                </label>
              `;
            }).join('')}
          </div>
          <div style="display:flex; gap:0.5rem;">
            <button class="avina-crm-btn" id="save-widget-customizer-btn" style="flex:1;">ذخیره تنظیمات</button>
            <button class="avina-crm-btn" id="close-widget-customizer-btn" style="flex:1; background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.15);">انصراف</button>
          </div>
        </div>
      </div>
    `;

    // Initialize event listeners
    container.querySelector('#db-range').addEventListener('change', (e) => {
      range = e.target.value;
      load();
    });

    container.querySelector('#customize-widgets-btn').addEventListener('click', () => {
      container.querySelector('#widget-customizer-modal').style.display = 'flex';
    });

    container.querySelector('#close-widget-customizer-btn').addEventListener('click', () => {
      container.querySelector('#widget-customizer-modal').style.display = 'none';
    });

    container.querySelector('#save-widget-customizer-btn').addEventListener('click', async () => {
      const checkboxes = container.querySelectorAll('.widget-toggle-checkbox');
      checkboxes.forEach(chk => {
        const id = chk.dataset.widgetId;
        const target = layout.widgets.find(w => w.id === id);
        if (target) target.visible = chk.checked;
      });
      container.querySelector('#widget-customizer-modal').style.display = 'none';
      container.innerHTML = loadingHtml();
      try {
        await apiPost('/settings/layout', layout);
        load();
      } catch (err) {
        alert('خطا در ذخیره‌سازی: ' + err.message);
        load();
      }
    });

    // Render Charts
    renderLifecycleChart();
    renderIntakesChart();

    // Wire Widgets Drag & Drop sorting
    wireWidgetsDragAndDrop();

    // Wire Kanban Drag & Drop if enabled
    if (dashboardData.kanban_enabled) {
      wireKanbanDragAndDrop();
    }

    // Apply premium visual effects
    container.querySelectorAll('.avina-kpi-card-premium').forEach(apply3dTiltEffect);
  }

  function drawKanbanBoardColumns() {
    const stages = systemSettings.kanban_settings.stages;

    return stages.map(stage => {
      const stageTasks = kanbanTasks.filter(t => t.stage_id === stage.id);
      return `
        <div class="avina-kanban-column" style="display:flex; flex-direction:column; gap:0.6rem; background:rgba(255,255,255,0.01); border:1px solid rgba(255,255,255,0.03); border-radius:12px; padding:0.5rem; min-height:220px;">
          <div style="display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.04); padding-bottom:0.4rem; margin-bottom:0.2rem;">
            <span style="font-size:0.75rem; font-weight:800; color:#fff; display:flex; align-items:center; gap:0.35rem;">
              <span style="width:7px; height:7px; border-radius:50%; background:${stage.color}; box-shadow:0 0 6px ${stage.color};"></span>
              ${escapeHtml(stage.name)}
            </span>
            <span style="font-size:0.65rem; color:var(--avina-text-muted); background:rgba(255,255,255,0.03); padding:0.15rem 0.4rem; border-radius:6px;">${stageTasks.length}</span>
          </div>
          <div style="flex:1; display:flex; flex-direction:column; gap:0.5rem;" class="avina-kanban-dropzone" data-stage-id="${stage.id}">
            ${stageTasks.map(task => `
              <div class="avina-kanban-card avina-crm-glass" draggable="true" data-task-id="${task.id}" style="--card-color:${stage.color}; --card-color-glow:rgba(255,255,255,0.05); padding:0.6rem; border-radius:10px; border-right:3px solid ${stage.color}; cursor:grab; position:relative; transition:transform 0.2s ease;">
                <strong style="font-size:0.78rem; color:#fff; display:block; margin-bottom:0.25rem; line-height:1.4;">${escapeHtml(task.title)}</strong>
                <p style="font-size:0.68rem; color:var(--avina-text-muted); margin:0 0 0.5rem 0; line-height:1.45;">${escapeHtml(task.description || '')}</p>
                <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.75rem; border-top:1px solid rgba(255,255,255,0.03); padding-top:0.35rem; margin-top:0.35rem;">
                  <span style="font-size:0.6rem; color:rgba(255,255,255,0.4);">دستگاه کارتخوان</span>
                  <div style="display:flex; align-items:center; gap:0.4rem;">
                    ${task.contact_phone ? `
                      <a href="tel:${task.contact_phone}" style="text-decoration:none;" title="تماس سریع">📞</a>
                      <a href="https://wa.me/${task.contact_phone.replace(/^0/, '98')}" target="_blank" style="text-decoration:none;" title="ارسال واتساپ">🟢</a>
                      <a href="https://eitaa.com" target="_blank" style="text-decoration:none;" title="پیام ایتا">🔵</a>
                    ` : '—'}
                  </div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    }).join('');
  }

  function renderLifecycleChart() {
    const canvas = container.querySelector('#lifecycle-chart');
    if (!canvas) return;

    const data = dashboardData.charts_data.lifecycle;
    const labels = data.map(d => {
      if (d.lifecycle_stage === 'lead') return 'سرنخ';
      if (d.lifecycle_stage === 'in_progress') return 'در حال پیگیری';
      if (d.lifecycle_stage === 'customer') return 'مشتری';
      if (d.lifecycle_stage === 'cancelled') return 'لغو شده';
      return d.lifecycle_stage;
    });
    const counts = data.map(d => Number(d.cnt));

    new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: counts,
          backgroundColor: ['#6366f1', '#eab308', '#10b981', '#ef4444'],
          borderColor: 'rgba(255,255,255,0.05)',
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: '#fff', font: { family: 'inherit', size: 10 } }
          }
        }
      }
    });
  }

  function renderIntakesChart() {
    const canvas = container.querySelector('#intakes-chart');
    if (!canvas) return;

    const data = dashboardData.charts_data.intakes;
    const labels = data.map(d => {
      if (d.status === 'pending') return 'پذیرش شده';
      if (d.status === 'inspecting') return 'در حال عیب‌یابی';
      if (d.status === 'repaired') return 'تعمیر شده';
      if (d.status === 'delivered') return 'تحویل شده';
      if (d.status === 'cancelled') return 'لغو شده';
      return d.status;
    });
    const counts = data.map(d => Number(d.cnt));

    new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'تعداد پذیرش',
          data: counts,
          backgroundColor: 'rgba(99, 102, 241, 0.4)',
          borderColor: '#6366f1',
          borderWidth: 1,
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#a0aec0', font: { size: 9 } } },
          x: { grid: { display: false }, ticks: { color: '#a0aec0', font: { size: 9, family: 'inherit' } } }
        }
      }
    });
  }

  function wireWidgetsDragAndDrop() {
    let draggedWidgetId = null;

    container.querySelectorAll('.avina-draggable-widget').forEach(widget => {
      widget.addEventListener('dragstart', () => {
        draggedWidgetId = widget.dataset.widgetId;
        widget.classList.add('is-dragging');
      });

      widget.addEventListener('dragend', () => {
        widget.classList.remove('is-dragging');
      });
    });

    const grid = container.querySelector('#dashboard-widgets-container');
    if (!grid) return;

    grid.addEventListener('dragover', (e) => {
      e.preventDefault();
      const dragging = grid.querySelector('.is-dragging');
      const siblings = [...grid.querySelectorAll('.avina-draggable-widget:not(.is-dragging)')];
      const nextSibling = siblings.find(sibling => {
        const rect = sibling.getBoundingClientRect();
        return e.clientX <= rect.left + rect.width / 2;
      });

      if (nextSibling) {
        grid.insertBefore(dragging, nextSibling);
      } else {
        grid.appendChild(dragging);
      }
    });

    grid.addEventListener('drop', async (e) => {
      e.preventDefault();
      const finalWidgets = [...grid.querySelectorAll('.avina-draggable-widget')];
      
      // Update order in layout state
      finalWidgets.forEach((fw, index) => {
        const id = fw.dataset.widgetId;
        const target = layout.widgets.find(w => w.id === id);
        if (target) target.order = index + 1;
      });

      try {
        await apiPost('/settings/layout', layout);
      } catch (err) {
        console.error('Failed to save layout order:', err);
      }
    });
  }

  function wireKanbanDragAndDrop() {
    let draggedTaskId = null;

    container.querySelectorAll('.avina-kanban-card').forEach(card => {
      card.addEventListener('dragstart', () => {
        draggedTaskId = card.dataset.taskId;
        card.style.opacity = '0.4';
      });

      card.addEventListener('dragend', () => {
        card.style.opacity = '1';
      });
    });

    container.querySelectorAll('.avina-kanban-dropzone').forEach(zone => {
      zone.addEventListener('dragover', (e) => {
        e.preventDefault();
        zone.style.background = 'rgba(255,255,255,0.03)';
      });

      zone.addEventListener('dragleave', () => {
        zone.style.background = 'transparent';
      });

      zone.addEventListener('drop', async (e) => {
        e.preventDefault();
        zone.style.background = 'transparent';
        const newStageId = zone.dataset.stageId;

        if (!draggedTaskId) return;

        try {
          await apiPost(`/settings/kanban/tasks/${draggedTaskId}/stage`, { stage_id: newStageId });
          // Fetch updated task lists
          const tasksRes = await apiGet('/settings/kanban/tasks');
          kanbanTasks = tasksRes;
          // Re-draw only Kanban columns content
          const board = container.querySelector('.avina-kanban-board');
          if (board) {
            board.innerHTML = drawKanbanBoardColumns();
            wireKanbanDragAndDrop();
          }
        } catch (err) {
          alert('خطا در جا‌به‌جایی: ' + err.message);
        }
      });
    });
  }

  load();
}
