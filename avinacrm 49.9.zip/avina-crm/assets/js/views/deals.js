import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

export async function renderDeals(container) {
  let pipelines = [];
  let customDefs = [];

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      try {
        const res = await apiGet('/custom-fields?entity=deal');
        customDefs = res.fields || [];
      } catch (e) {
        console.error("Failed to load custom field definitions", e);
      }
      pipelines = await apiGet('/pipelines');
      const items = await apiGet('/deals');
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function stageLabel(deal) {
    const pipeline = pipelines.find((p) => p.id === deal.pipeline_id);
    const stage = pipeline ? pipeline.stages.find((s) => s.id === deal.stage_id) : null;
    return stage ? stage.name : '—';
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <button class="avina-crm-btn" id="dl-new">معامله جدید</button>
        <button class="avina-crm-btn secondary" id="dl-kanban">مشاهده کانبان</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('معامله‌ای ثبت نشده است.')}
      </div>
    `;

    container.querySelector('#dl-new').addEventListener('click', openCreate);
    container.querySelector('#dl-kanban').addEventListener('click', () => {
      window.location.hash = '#/kanban';
    });
  }

  function table(items) {
    const rows = items
      .map(
        (d) => {
          const customHtml = Object.entries(d.custom_fields || {})
            .map(([k, v]) => {
              if (!v) return '';
              const def = customDefs.find((defField) => defField.id === k);
              const label = def ? def.label : k;
              if (def && def.type === 'file' && typeof v === 'string' && v.startsWith('http')) {
                return `<div style="margin-top:0.25rem;"><strong>${escapeHtml(label)}:</strong> <a href="${escapeHtml(v)}" target="_blank" rel="noopener" style="color:#0284c7;text-decoration:underline;">دانلود فایل</a></div>`;
              }
              return `<div style="margin-top:0.25rem;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(String(v))}</div>`;
            })
            .join('');

          return `
      <tr>
        <td>
          <div style="font-weight:600;">${escapeHtml(d.title)}</div>
          <div style="font-size:0.8rem;color:#64748b;margin-top:0.25rem;display:flex;flex-direction:column;gap:0.15rem;">
            ${customHtml}
          </div>
        </td>
        <td>${stageLabel(d)}</td>
        <td>${escapeHtml(Number(d.value).toLocaleString('fa-IR'))} ${escapeHtml(d.currency)}</td>
        <td>${d.expected_close_date ? escapeHtml(d.expected_close_date) : '—'}</td>
        <td><span class="avina-crm-status avina-crm-status--${escapeHtml(d.status)}">${d.status === 'won' ? 'برنده' : d.status === 'lost' ? 'بازنده' : 'باز'}</span></td>
      </tr>`;
        }
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>عنوان</th><th>مرحله</th><th>ارزش</th><th>تاریخ بستن</th><th>وضعیت</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  async function openCreate() {
    if (!pipelines.length) {
      alert('ابتدا باید یک پایپ‌لاین ایجاد شود.');
      return;
    }

    let customFields = [];
    let submitLabel = 'ذخیره';
    try {
      const res = await apiGet('/custom-fields?entity=deal');
      customFields = res.fields || [];
      submitLabel = res.submit_button_label || 'ذخیره';
    } catch (e) {
      console.error(e);
    }

    const mappedCustomFields = customFields.map((cf) => ({
      name: cf.id,
      label: cf.label,
      type: cf.type,
      options: cf.options ? cf.options.map((opt) => ({ value: opt, label: opt })) : [],
      required: cf.required,
      placeholder: cf.placeholder || '',
      step: cf.step || 1,
    }));

    const pipelineOptions = pipelines.map((p) => ({ value: String(p.id), label: p.name }));
    const firstPipeline = pipelines[0];
    const stageOptions = firstPipeline.stages.map((s) => ({ value: String(s.id), label: s.name }));

    const fields = [
      { name: 'title', label: 'عنوان معامله', required: true, step: 1 },
      { name: 'pipeline_id', label: 'پایپ‌لاین', type: 'select', options: pipelineOptions, step: 1 },
      { name: 'stage_id', label: 'مرحله', type: 'select', options: stageOptions, step: 1 },
      { name: 'value', label: 'ارزش معامله', type: 'number', step: 1 },
      { name: 'expected_close_date', label: 'تاریخ تخمینی بستن (مثلاً 2026-09-01)', step: 1 },
      ...mappedCustomFields,
    ];

    openFormModal({
      title: 'معامله جدید',
      fields: fields,
      submitLabel: submitLabel,
      onSubmit: async (values) => {
        values.pipeline_id = Number(values.pipeline_id);
        values.stage_id = Number(values.stage_id);
        if (!values.expected_close_date) delete values.expected_close_date;
        await apiPost('/deals', values);
        load();
      },
    });
  }

  load();
}
