export function escapeHtml(value) {
  const div = document.createElement('div');
  div.textContent = value === null || value === undefined ? '' : String(value);
  return div.innerHTML;
}

export function statusBadge(status, labelMap = {}) {
  const label = labelMap[status] || status || '';
  return `<span class="avina-crm-status avina-crm-status--${escapeHtml(status)}">${escapeHtml(label)}</span>`;
}

export function formatDateTime(value) {
  if (!value) {
    return '—';
  }
  try {
    const date = new Date(value.replace(' ', 'T') + 'Z');
    return new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
  } catch (e) {
    return value;
  }
}

export function loadingHtml(message) {
  return `<div class="avina-crm-loading">${escapeHtml(message || 'در حال بارگذاری...')}</div>`;
}

export function emptyHtml(message) {
  return `<div class="avina-crm-empty">${escapeHtml(message || 'موردی برای نمایش وجود ندارد.')}</div>`;
}

export function errorHtml(message) {
  return `<div class="avina-crm-error">${escapeHtml(message || 'خطایی رخ داد.')}</div>`;
}

export function el(selector) {
  return document.querySelector(selector);
}

export function apply3dTiltEffect(element) {
  if (!element) return;
  element.classList.add('avina-3d-card');
  
  element.addEventListener('mousemove', (e) => {
    const rect = element.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const px = (x / rect.width) - 0.5;
    const py = (y / rect.height) - 0.5;
    
    const rx = -py * 12; 
    const ry = px * 12;
    
    element.style.setProperty('--rx', `${rx}deg`);
    element.style.setProperty('--ry', `${ry}deg`);
  });
  
  element.addEventListener('mouseleave', () => {
    element.style.setProperty('--rx', '0deg');
    element.style.setProperty('--ry', '0deg');
  });
}

export function initJalaliDatePicker(input) {
  if (!input) return;
  input.setAttribute('readonly', 'true');
  input.style.cursor = 'pointer';

  input.addEventListener('click', (e) => {
    e.stopPropagation();
    
    const existing = document.getElementById('avina-datepicker-popover');
    if (existing) existing.remove();

    const rect = input.getBoundingClientRect();
    const popover = document.createElement('div');
    popover.id = 'avina-datepicker-popover';
    popover.style.cssText = `
      position: fixed;
      top: ${rect.bottom + window.scrollY + 5}px;
      left: ${rect.left + window.scrollX}px;
      width: 280px;
      padding: 0.75rem;
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.15);
      box-shadow: 0 10px 30px rgba(0,0,0,0.4);
      z-index: 100000;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      direction: rtl;
    `;

    popover.className = 'avina-crm-modal';

    let year = 1405;
    let month = 6;
    let day = 1;

    const val = input.value;
    if (val && val.includes('/')) {
      const parts = val.split('/');
      if (parts.length === 3) {
        year = parseInt(parts[0]) || 1405;
        month = parseInt(parts[1]) || 6;
        day = parseInt(parts[2]) || 1;
      }
    }

    const months = [
      'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
      'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    popover.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,0.08);padding-bottom:0.4rem;margin-bottom:0.25rem;">
        <span style="font-size:0.8rem;font-weight:700;color:#fff;">انتخاب تاریخ جلالی</span>
        <button type="button" class="avina-datepicker-close" style="background:none;border:none;color:#fff;cursor:pointer;font-size:1rem;">×</button>
      </div>
      
      <div style="display:flex;gap:0.5rem;justify-content:space-between;height:120px;overflow:hidden;position:relative;z-index:2;">
        <!-- Day Select -->
        <div style="flex:1;overflow-y:auto;text-align:center;scrollbar-width:none;-ms-overflow-style:none;" class="avina-datepicker-col" id="col-day">
          ${Array.from({length: 31}, (_, i) => i + 1).map(d => `
            <div data-val="${d}" class="avina-dp-item ${d === day ? 'active' : ''}" style="padding:0.25rem;font-size:0.8rem;cursor:pointer;border-radius:4px;color:${d === day ? '#fff' : 'rgba(255,255,255,0.6)'};background:${d === day ? 'var(--avina-primary)' : 'none'};">${d}</div>
          `).join('')}
        </div>
        
        <!-- Month Select -->
        <div style="flex:2;overflow-y:auto;text-align:center;scrollbar-width:none;-ms-overflow-style:none;" class="avina-datepicker-col" id="col-month">
          ${months.map((m, idx) => `
            <div data-val="${idx + 1}" class="avina-dp-item ${idx + 1 === month ? 'active' : ''}" style="padding:0.25rem;font-size:0.8rem;cursor:pointer;border-radius:4px;color:${idx + 1 === month ? '#fff' : 'rgba(255,255,255,0.6)'};background:${idx + 1 === month ? 'var(--avina-primary)' : 'none'};">${m}</div>
          `).join('')}
        </div>
        
        <!-- Year Select -->
        <div style="flex:1.5;overflow-y:auto;text-align:center;scrollbar-width:none;-ms-overflow-style:none;" class="avina-datepicker-col" id="col-year">
          ${Array.from({length: 11}, (_, i) => 1400 + i).map(y => `
            <div data-val="${y}" class="avina-dp-item ${y === year ? 'active' : ''}" style="padding:0.25rem;font-size:0.8rem;cursor:pointer;border-radius:4px;color:${y === year ? '#fff' : 'rgba(255,255,255,0.6)'};background:${y === year ? 'var(--avina-primary)' : 'none'};">${y}</div>
          `).join('')}
        </div>
      </div>
      
      <button type="button" class="avina-crm-btn" id="avina-dp-confirm-btn" style="width:100%;padding:0.35rem;font-size:0.8rem;position:relative;z-index:2;">تایید و ثبت تاریخ</button>
    `;

    document.body.appendChild(popover);

    // Scroll active items into view
    ['col-day', 'col-month', 'col-year'].forEach(id => {
      const col = popover.querySelector(`#${id}`);
      const active = col.querySelector('.active');
      if (active) {
        col.scrollTop = active.offsetTop - col.offsetTop - 40;
      }
    });

    popover.querySelector('.avina-datepicker-close').addEventListener('click', () => popover.remove());

    popover.querySelectorAll('.avina-datepicker-col').forEach(col => {
      col.addEventListener('click', (ev) => {
        const item = ev.target.closest('.avina-dp-item');
        if (!item) return;

        col.querySelectorAll('.avina-dp-item').forEach(i => {
          i.classList.remove('active');
          i.style.background = 'none';
          i.style.color = 'rgba(255,255,255,0.6)';
        });

        item.classList.add('active');
        item.style.background = 'var(--avina-primary)';
        item.style.color = '#fff';

        const val = parseInt(item.getAttribute('data-val'));
        if (col.id === 'col-day') day = val;
        if (col.id === 'col-month') month = val;
        if (col.id === 'col-year') year = val;
      });
    });

    popover.querySelector('#avina-dp-confirm-btn').addEventListener('click', () => {
      const formattedMonth = month < 10 ? `0${month}` : `${month}`;
      const formattedDay = day < 10 ? `0${day}` : `${day}`;
      input.value = `${year}/${formattedMonth}/${formattedDay}`;
      input.dispatchEvent(new Event('change'));
      popover.remove();
    });

    const outsideClick = (ev) => {
      if (!popover.contains(ev.target) && ev.target !== input) {
        popover.remove();
        document.removeEventListener('click', outsideClick);
      }
    };
    document.addEventListener('click', outsideClick);
  });
}
