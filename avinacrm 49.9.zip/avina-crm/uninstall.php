<?php
/**
 * Fires only when the plugin is deleted from the Plugins screen.
 * Non-destructive by default: production CRM data is preserved.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clear scheduled background cron jobs
if (function_exists('wp_clear_scheduled_hook')) {
    wp_clear_scheduled_hook('avina_crm_daily_sms_cron');
}

// Flush rewrite rules cleanly
if (function_exists('flush_rewrite_rules')) {
    flush_rewrite_rules(false);
}

